"use strict";
// Pintado del chat. El HTML se escapa. Las fórmulas las dibuja KaTeX, ya incluido.
// No se toca el interior de un bloque de código.

function escapar(texto) {
  return String(texto ?? "").replace(/[&<>"]/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;",
  }[c]));
}

function pintarMate(src, display) {
  if (typeof katex === "undefined" || !katex.renderToString) return escapar(src);
  try {
    return katex.renderToString(src, { throwOnError: false, displayMode: !!display });
  } catch (e) {
    return escapar(src);
  }
}

function dolarAbre(bruto, i) {
  if (bruto[i] !== "$" || bruto[i + 1] === "$") return false;
  const sig = bruto[i + 1];
  if (!sig || sig === " " || sig === "\n" || sig === "\t") return false;
  if (i > 0 && bruto[i - 1] === "\\") return false;
  if (i > 0 && /\d/.test(bruto[i - 1])) return false;
  return true;
}

function dolarValido(src) {
  if (!src || /^\s/.test(src) || /\s$/.test(src)) return false;
  if (/^\d+(?:[.,]\d+)?$/.test(src)) return false;
  return true;
}

function abrirMate(bruto, i) {
  if (bruto.startsWith("\\[", i)) return { abre: "\\[", cierra: "\\]", display: true };
  if (bruto.startsWith("\\(", i)) return { abre: "\\(", cierra: "\\)", display: false };
  if (bruto.startsWith("$$", i)) return { abre: "$$", cierra: "$$", display: true };
  if (dolarAbre(bruto, i)) return { abre: "$", cierra: "$", display: false, dolar: true };
  return null;
}

function proteger(bruto, guardar) {
  let i = 0;
  let out = "";
  while (i < bruto.length) {
    if (bruto.startsWith("```", i)) {
      const fin = bruto.indexOf("```", i + 3);
      const cuerpo = fin < 0 ? bruto.slice(i + 3) : bruto.slice(i + 3, fin);
      const salto = cuerpo.indexOf("\n");
      const codigo = salto < 0 ? (fin < 0 ? "" : cuerpo) : cuerpo.slice(salto + 1);
      const lengua = salto < 0 ? (fin < 0 ? cuerpo : "") : cuerpo.slice(0, salto);
      out += guardar(cajaCodigo(codigo.replace(/\n$/, ""), lengua));
      if (fin < 0) break;
      i = fin + 3;
      continue;
    }
    const mate = abrirMate(bruto, i);
    if (mate) {
      const desde = i + mate.abre.length;
      const fin = bruto.indexOf(mate.cierra, desde);
      if (fin >= 0) {
        const src = bruto.slice(desde, fin);
        if (mate.dolar && !dolarValido(src)) {
          out += bruto[i];
          i += 1;
          continue;
        }
        out += guardar(pintarMate(src, mate.display));
        i = fin + mate.cierra.length;
        continue;
      }
    }
    out += bruto[i];
    i += 1;
  }
  return out;
}

// Cada bloque de código va en su caja: cabecera con «Copiar» y el código con scroll
// horizontal dentro de la caja (el chat no se mueve de lado). Sin saltos de línea entre
// etiquetas: el mensaje se pinta con white-space: pre-wrap.
function cajaCodigo(codigo, lengua) {
  const nombre = String(lengua || "").trim().split(/\s+/)[0].slice(0, 24);
  return '<div class="caja-codigo"><div class="caja-codigo-cabeza"><span>' + escapar(nombre || "código")
    + '</span><button type="button" class="copiar">Copiar</button></div><pre><code>'
    + escapar(codigo) + "</code></pre></div>";
}

function restaurar(html, huecos) {
  return html.replace(/\uE000SOPA(\d+)\uE000/g, (_, n) => huecos[Number(n)] || "");
}

function esSep(linea) {
  return /^\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(String(linea).trim());
}

function esFila(linea) {
  const t = String(linea).trim();
  return t.includes("|") && !esSep(t);
}

function celdas(linea) {
  let t = String(linea).trim();
  if (t.startsWith("|")) t = t.slice(1);
  if (t.endsWith("|")) t = t.slice(0, -1);
  return t.split("|").map((c) => c.trim());
}

function tablas(html) {
  const lineas = String(html).split("\n");
  const salida = [];
  for (let i = 0; i < lineas.length; i++) {
    if (esFila(lineas[i]) && i + 1 < lineas.length && esSep(lineas[i + 1])) {
      const cabeza = celdas(lineas[i]);
      const cuerpo = [];
      i += 2;
      while (i < lineas.length && esFila(lineas[i])) {
        cuerpo.push(celdas(lineas[i]));
        i += 1;
      }
      i -= 1;
      const th = cabeza.map((c) => "<th>" + c + "</th>").join("");
      const trs = cuerpo.map((fila) => "<tr>" + fila.map((c) => "<td>" + c + "</td>").join("") + "</tr>").join("");
      // La tabla ancha se desplaza dentro de su caja, nunca el chat entero.
      salida.push('<div class="caja-tabla"><table><thead><tr>' + th + "</tr></thead><tbody>" + trs + "</tbody></table></div>");
    } else {
      salida.push(lineas[i]);
    }
  }
  return salida.join("\n");
}

function markdownSeguro(texto) {
  const bruto = String(texto ?? "").replace(/\r\n/g, "\n");
  const huecos = [];
  const guardar = (html) => {
    const marca = "\uE000SOPA" + huecos.length + "\uE000";
    huecos.push(html);
    return marca;
  };
  let html = escapar(proteger(bruto, guardar));
  html = html.replace(/`([^`\n]+)`/g, "<code>$1</code>");
  html = html.replace(/^### (.+)$/gm, "<h3>$1</h3>");
  html = html.replace(/^## (.+)$/gm, "<h2>$1</h2>");
  html = html.replace(/^# (.+)$/gm, "<h1>$1</h1>");
  html = html.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  html = html.replace(/\*\*([^*]+)$/g, "<strong>$1</strong>");
  html = tablas(html);
  html = html.replace(/^---[ \t]*$/gm, "<hr>");
  html = listasSeguras(html);
  // Con pre-wrap, la línea en blanco antes de una lista se pintaba como un hueco de más.
  html = html.replace(/\n{2,}(?=<(?:ul|ol)>)/g, "\n");
  // Y tras la lista, el párrafo siguiente empieza sin línea en blanco (el margen de la lista ya separa).
  html = html.replace(/(<\/(?:ul|ol)>)\n+(?=[^\n])/g, "$1");
  html = html.replace(/[ \t]{2,}(?=\n|$)/g, "");
  return restaurar(html, huecos);
}

// Párrafos para el móvil: el HTML de markdownSeguro deja los saltos tal cual (el escritorio
// los pinta con pre-wrap). Aquí una línea en blanco abre párrafo, un salto suelto es <br>
// y las listas, títulos, tablas y cajas de código van solas, sin líneas de más alrededor.
// El interior de <pre> no se toca.
const BLOQUE_HTML = /^<(?:ul|ol|h[1-6]|hr|div|table|blockquote|details|p)[\s>]|^<span class="katex-display"/;
function parrafos(html) {
  const pres = [];
  let t = String(html ?? "").replace(/<pre>[\s\S]*?<\/pre>/g, (m) => { pres.push(m); return "\uE001" + (pres.length - 1) + "\uE001"; });
  t = t.replace(/(<\/(?:ul|ol)>)(?=[^\n])/g, "$1\n");
  const salida = [];
  for (const trozo of t.split(/\n[ \t]*\n+/)) {
    let texto = [];
    const soltar = () => {
      const limpio = texto.join("<br>").trim();
      if (limpio) salida.push("<p>" + limpio + "</p>");
      texto = [];
    };
    for (const linea of trozo.split("\n")) {
      const l = linea.trim();
      if (!l) continue;
      if (BLOQUE_HTML.test(l)) { soltar(); salida.push(l); } else texto.push(l);
    }
    soltar();
  }
  return salida.join("").replace(/\uE001(\d+)\uE001/g, (_, n) => pres[Number(n)] || "");
}

function listasSeguras(html) {
  const salida = [];
  let modo = "";
  let puntos = [];
  const cerrar = () => {
    if (!modo) return;
    const etiqueta = modo === "ul" ? "ul" : "ol";
    salida.push("<" + etiqueta + ">" + puntos.map((t) => "<li>" + t + "</li>").join("") + "</" + etiqueta + ">");
    modo = "";
    puntos = [];
  };
  for (const linea of String(html).split("\n")) {
    const limpia = linea.replace(/[ \t]+$/, "");
    const viñeta = limpia.match(/^[ \t]{0,3}- (.+)$/);
    const numero = limpia.match(/^[ \t]{0,3}\d+\. (.+)$/);
    if (viñeta) {
      if (modo !== "ul") { cerrar(); modo = "ul"; }
      puntos.push(viñeta[1]);
    } else if (numero) {
      if (modo !== "ol") { cerrar(); modo = "ol"; }
      puntos.push(numero[1]);
    } else {
      cerrar();
      salida.push(linea);
    }
  }
  cerrar();
  return salida.join("\n");
}

function corteBloqueCerrado(texto) {
  const bruto = String(texto ?? "");
  let cerrado = 0;
  let valla = false;
  let mate = "";
  for (let i = 0; i < bruto.length; i++) {
    if (!mate && bruto.startsWith("```", i)) {
      valla = !valla;
      i += 2;
      if (!valla) {
        const fin = bruto.indexOf("\n", i + 1);
        cerrado = fin < 0 ? bruto.length : fin + 1;
        if (fin >= 0) i = fin;
      }
      continue;
    }
    if (valla) continue;
    if (!mate) {
      if (bruto.startsWith("\\[", i)) { mate = "\\]"; i += 1; continue; }
      if (bruto.startsWith("\\(", i)) { mate = "\\)"; i += 1; continue; }
      if (bruto.startsWith("$$", i)) { mate = "$$"; i += 1; continue; }
      if (dolarAbre(bruto, i)) { mate = "$"; continue; }
    } else if (bruto.startsWith(mate, i)) {
      i += mate.length - 1;
      mate = "";
      continue;
    }
    if (!mate && bruto[i] === "\n") cerrado = i + 1;
  }
  return cerrado;
}

function esLineaDeLista(cola) {
  if (!cola || cola.indexOf("\n") >= 0 || cola.indexOf("```") >= 0) return false;
  return /^[ \t]{0,3}(?:-|\d+\.)[ \t]+\S/.test(cola);
}

function markdownEnCurso(texto, cache) {
  const bruto = String(texto ?? "");
  let corte = corteBloqueCerrado(bruto);
  let cola = bruto.slice(corte);
  // «- pan» sin salto aún es una lista. Si se escapa, la e2e no ve <ul>.
  if (esLineaDeLista(cola)) {
    corte = bruto.length;
    cola = "";
  }
  let html;
  if (cache && cache.hasta === corte) html = cache.html;
  else {
    html = markdownSeguro(bruto.slice(0, corte));
    if (cache) { cache.hasta = corte; cache.html = html; }
  }
  // Un bloque de código aún abierto ya sale en su caja (con «Copiar») mientras se escribe.
  const valla = cola.indexOf("```");
  if (valla >= 0) {
    const huecos = [];
    const guardar = (x) => { huecos.push(x); return "\uE000SOPA" + (huecos.length - 1) + "\uE000"; };
    return html + escapar(cola.slice(0, valla)) + restaurar(escapar(proteger(cola.slice(valla), guardar)), huecos);
  }
  return html + escapar(cola);
}

// ---------------------------------------------------------------- etiqueta del código

// Qué se comprobó, con los datos reales que guarda la comprobación (se ve al tocar la etiqueta).
function detalleComprobacion(c) {
  if (!c) return "";
  if (c.detalle) return String(c.detalle);
  const frases = [];
  if (Array.isArray(c.revisado) && c.revisado.length) frases.push("Se revisó " + c.revisado.join("; ") + ".");
  const n = Number(c.intentos || 0);
  frases.push(n ? `Hubo ${n} ${n === 1 ? "intento" : "intentos"} de corrección.` : "No hubo intentos de corrección.");
  if (Array.isArray(c.fallos) && c.fallos.length) frases.push(`Quedan ${c.fallos.length} ${c.fallos.length === 1 ? "error" : "errores"}.`);
  if (Array.isArray(c.sin_comprobar) && c.sin_comprobar.length) frases.push("Sin comprobar: " + c.sin_comprobar.join("; ") + ".");
  if (c.captura || (Array.isArray(c.capturas) && c.capturas.length)) frases.push("Hay una captura de la página.");
  if (Array.isArray(c.pruebas) && c.pruebas.length) {
    const mal = c.pruebas.filter((p) => p && p.estado && p.estado !== "ok");
    frases.push(mal.length
      ? "Pruebas: " + mal.slice(0, 4).map((p) => "bloque " + (Number(p.bloque) + 1) + " " + p.nombre + ": " + p.estado).join("; ") + "."
      : "Pruebas locales en verde (" + c.pruebas.length + ").");
  }
  frases.push("No comprueba el aspecto de la página.");
  return frases.join(" ");
}

function srcCapturas(c) {
  const lista = [];
  if (c && typeof c.captura === "string") lista.push(c.captura);
  if (c && Array.isArray(c.capturas)) {
    for (const item of c.capturas) {
      if (item && typeof item.src === "string") lista.push(item.src);
    }
  }
  const vistos = [];
  for (const s of lista) {
    if (/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(s) && vistos.indexOf(s) < 0) vistos.push(s);
  }
  return vistos.slice(0, 2).map((s) => `<img class="comprobacion-captura" alt="Captura de la página generada" src="${s}">`).join("");
}

// Etiqueta que se puede pulsar (y con title para el ratón); el detalle abierto se guarda en el mensaje.
function htmlEtiquetaComprobacion(m, indice) {
  const c = m && m.comprobacion;
  if (!c || !c.texto) return "";
  const det = detalleComprobacion(c);
  const abierto = !!m.verDetalle;
  const clase = c.estado === "ok" ? "ok" : (c.estado === "sin" ? "sin" : "no");
  return `<button type="button" class="comprobacion ${clase}" data-comprobacion="${indice}"`
    + ` title="${escapar(det)}" aria-expanded="${abierto}">${c.estado === "ok" ? "✓ " : ""}${escapar(c.texto)}</button>`
    + `<span class="comprobacion-detalle"${abierto ? "" : " hidden"}>${escapar(det)}</span>`
    + srcCapturas(c);
}

// Delegado: al tocar la etiqueta se abre o cierra la explicación. Devuelve true si era la etiqueta.
function alPulsarComprobacion(ev, lista) {
  const b = ev.target && ev.target.closest ? ev.target.closest("[data-comprobacion]") : null;
  if (!b) return false;
  const m = lista[Number(b.dataset.comprobacion)];
  if (m) m.verDetalle = !m.verDetalle;
  const det = b.nextElementSibling;
  if (det && det.classList.contains("comprobacion-detalle")) det.hidden = !(m ? m.verDetalle : det.hidden);
  b.setAttribute("aria-expanded", String(!!(m && m.verDetalle)));
  return true;
}

// ---------------------------------------------------------------- copiar

function copiaAntigua(texto, doc) {
  doc = doc || document;
  const area = doc.createElement("textarea");
  area.value = texto;
  area.setAttribute("aria-hidden", "true");
  area.style.position = "fixed"; area.style.top = "0"; area.style.left = "0";
  area.style.opacity = "0"; area.style.fontSize = "16px";  // 16 px: iOS no hace zoom
  area.contentEditable = "true"; area.readOnly = false;
  doc.body.appendChild(area);
  let hecho = false;
  try {
    area.focus();
    area.select();
    area.setSelectionRange(0, texto.length);  // iOS no selecciona con select()
    hecho = doc.execCommand("copy");
  } catch (e) { hecho = false; }
  doc.body.removeChild(area);
  return hecho;
}

// Sin HTTPS (el iPhone por la red local) navigator.clipboard no existe: textarea y execCommand.
async function copiarTexto(texto, nav, doc) {
  nav = nav || (typeof navigator !== "undefined" ? navigator : null);
  if (nav && nav.clipboard && nav.clipboard.writeText) {
    try { await nav.clipboard.writeText(texto); return true; } catch (e) { /* se prueba la otra vía */ }
  }
  return copiaAntigua(texto, doc);
}

// El estado «Copiado» y el scroll de cada caja se guardan por orden y sobreviven al re-render.
const estadoCajas = { copiado: new Map(), izquierda: new Map() };

function guardarCajas(raiz) {
  raiz.querySelectorAll(".caja-codigo pre").forEach((pre, i) => {
    if (pre.scrollLeft) estadoCajas.izquierda.set(i, pre.scrollLeft); else estadoCajas.izquierda.delete(i);
  });
}

function restaurarCajas(raiz, ahora) {
  ahora = ahora || Date.now();
  raiz.querySelectorAll(".caja-codigo").forEach((caja, i) => {
    const boton = caja.querySelector(".copiar");
    const hasta = estadoCajas.copiado.get(i);
    if (boton && hasta && hasta.t > ahora) boton.textContent = hasta.texto;
    const pre = caja.querySelector("pre");
    if (pre && estadoCajas.izquierda.has(i)) pre.scrollLeft = estadoCajas.izquierda.get(i);
  });
}

async function alPulsarCopiar(ev, raiz) {
  const boton = ev.target && ev.target.closest ? ev.target.closest(".caja-codigo .copiar") : null;
  if (!boton) return false;
  ev.preventDefault();
  const caja = boton.closest(".caja-codigo");
  const code = caja.querySelector("pre code");
  const indice = [...raiz.querySelectorAll(".caja-codigo")].indexOf(caja);
  const hecho = await copiarTexto(code ? code.textContent : "");
  const texto = hecho ? "Copiado" : "No he podido copiar";
  estadoCajas.copiado.set(indice, { texto, t: Date.now() + 1500 });
  const actual = raiz.querySelectorAll(".caja-codigo .copiar")[indice] || boton;
  actual.textContent = texto;
  setTimeout(() => {
    const b = raiz.querySelectorAll(".caja-codigo .copiar")[indice];
    if (b && b.textContent === texto) b.textContent = "Copiar";
  }, 1500);
  return true;
}

// ---------------------------------------------------------------- seguir el final

// Solo baja con el texto si ya estaba al final (margen en px). Si sube con la rueda, el dedo
// o las teclas, deja de moverse y aparece «Ir al final»; al bajar del todo vuelve a seguir.
function seguirAlFinal(caja, boton, opciones) {
  const margen = (opciones && opciones.margen) || 24;
  const doc = (opciones && opciones.doc) || (typeof document !== "undefined" ? document : null);
  const est = { seguir: true };
  let propio = false;
  let ultimo = caja.scrollTop;
  let dedo = null;
  const alFondo = () => caja.scrollHeight - caja.scrollTop - caja.clientHeight <= margen;
  const pintarBoton = () => { if (boton) boton.hidden = est.seguir || alFondo(); };
  const bajar = () => {
    propio = true;
    caja.scrollTop = caja.scrollHeight;
    ultimo = caja.scrollTop;
    propio = false;
  };
  const soltar = () => { est.seguir = false; pintarBoton(); };
  caja.addEventListener("wheel", (e) => { if (e.deltaY < 0) soltar(); }, { passive: true });
  caja.addEventListener("touchstart", (e) => { dedo = e.touches && e.touches[0] ? e.touches[0].clientY : null; }, { passive: true });
  caja.addEventListener("touchmove", (e) => {
    const y = e.touches && e.touches[0] ? e.touches[0].clientY : null;
    if (dedo != null && y != null && y > dedo + 4) soltar();  // el dedo baja: el texto sube
  }, { passive: true });
  if (doc) doc.addEventListener("keydown", (e) => {
    const t = e.target;
    if (t && (t.tagName === "TEXTAREA" || t.tagName === "INPUT" || t.tagName === "SELECT" || t.isContentEditable)) return;
    if (["PageUp", "Home", "ArrowUp"].includes(e.key)) soltar();
  });
  caja.addEventListener("scroll", () => {
    if (propio) return;
    if (caja.scrollTop < ultimo - 2 && !alFondo()) est.seguir = false;
    else if (alFondo()) est.seguir = true;
    ultimo = caja.scrollTop;
    pintarBoton();
  }, { passive: true });
  if (boton) boton.addEventListener("click", () => { est.seguir = true; bajar(); pintarBoton(); });
  pintarBoton();
  return {
    estado: est,
    pintado() { if (est.seguir) bajar(); else ultimo = caja.scrollTop; pintarBoton(); },
    irAlFinal() { est.seguir = true; bajar(); pintarBoton(); },
  };
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { markdownSeguro, markdownEnCurso, parrafos, corteBloqueCerrado, cajaCodigo, copiarTexto, copiaAntigua,
    seguirAlFinal, guardarCajas, restaurarCajas, estadoCajas, alPulsarCopiar, detalleComprobacion,
    htmlEtiquetaComprobacion, alPulsarComprobacion };
}
