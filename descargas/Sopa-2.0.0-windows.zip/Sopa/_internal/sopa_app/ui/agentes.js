// Pestaña Agentes. La lógica vive en Python.
"use strict";
const ag = {
  editando: null,
  carrera: null,
  propuesta: null,
  sobrescribir: false,
  ocupado: false,
  carpetas: [],
  equipo: [],
  avatares: [],
  editandoEquipo: null,
};
const EQUIPO_VISTO = "sopa-equipo-visto";
const ESTADO_EQUIPO = { listo: "Listo", trabajando: "Trabajando", error: "Error" };

function fichaEquipo(id) {
  const lista = (estado && estado.equipo && estado.equipo.length) ? estado.equipo : ag.equipo;
  return (lista || []).find((a) => a.id === (id || "chat")) || null;
}

function htmlAvatar(ficha, vivo) {
  const emoji = (ficha && ficha.emoji) || "🥣";
  const anim = (ficha && ficha.animacion) || "vapor";
  const id = (ficha && ficha.avatar) || "sprout";
  const base = (ficha && ficha.cara) || ("avatares/" + id);
  const grande = vivo === "grande" ? " grande" : "";
  // El emoji es el respaldo. montarAvatares pone la foto fija (también en vistas ocultas) y, en pantalla, el clip.
  return `<span class="avatar avatar-vivo${grande}" data-anim="${esc(anim)}" data-avatar="${esc(id)}" data-cara="${esc(base)}" aria-hidden="true"><span class="avatar-emoji">${esc(emoji)}</span></span>`;
}

function marcarClipAvatar(nodo, el) {
  nodo.classList.add("tiene-clip");
  nodo.replaceChildren(el);
}

function cargarImagenAvatar(nodo, url, alFallar) {
  const img = new Image();
  img.alt = "";
  img.className = "avatar-clip";
  img.onload = () => {
    if (nodo.querySelector("video")) return;
    marcarClipAvatar(nodo, img);
  };
  img.onerror = () => { if (typeof alFallar === "function") alFallar(); };
  img.src = url;
}

function cargarVideoAvatar(nodo, url, poster) {
  const video = document.createElement("video");
  video.className = "avatar-clip";
  video.muted = true;
  video.loop = true;
  video.autoplay = true;
  video.playsInline = true;
  video.preload = "auto";
  video.setAttribute("playsinline", "");
  video.setAttribute("aria-hidden", "true");
  if (poster) video.poster = poster;
  video.addEventListener("loadeddata", () => {
    marcarClipAvatar(nodo, video);
    video.play().catch(() => {});
  }, { once: true });
  video.addEventListener("error", () => {
    if (poster) cargarImagenAvatar(nodo, poster);
  }, { once: true });
  video.src = url;
}

const clipsHilo = [];

function rescatarClipsHilo() {
  clipsHilo.length = 0;
  const caja = document.getElementById("mensajes");
  if (!caja) return;
  caja.querySelectorAll(".avatar-vivo video.avatar-clip").forEach((video) => {
    const nodo = video.closest(".avatar-vivo");
    clipsHilo.push({ id: (nodo && nodo.dataset.avatar) || "", video: video });
    video.remove();
  });
}

function tomarClipHilo(id) {
  const i = clipsHilo.findIndex((c) => c.id === id);
  if (i < 0) return null;
  return clipsHilo.splice(i, 1)[0].video;
}

function soltarClipsHiloSobrantes() {
  clipsHilo.splice(0).forEach((c) => {
    c.video.pause();
    c.video.removeAttribute("src");
    c.video.load();
  });
}

const INTRO_POOL = "avatares/sopa-pool-dive.webm";
let introPoolVista = false;

function reproducirIntroAgentes() {
  if (introPoolVista) return;
  if (estado && estado.e2e) return;
  if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const caja = document.getElementById("intro-agentes");
  const video = document.getElementById("intro-pool");
  if (!caja || !video) return;
  introPoolVista = true;
  const cerrar = () => {
    video.pause();
    video.removeAttribute("src");
    video.load();
    caja.hidden = true;
  };
  video.loop = false;
  video.addEventListener("ended", cerrar, { once: true });
  video.addEventListener("error", cerrar, { once: true });
  caja.hidden = false;
  video.src = INTRO_POOL;
  video.play().catch(cerrar);
}

function avatarEnPantalla(nodo) {
  for (let n = nodo; n && n.nodeType === 1; n = n.parentElement) {
    if (n.hidden) return false;
    const estilo = window.getComputedStyle(n);
    if (estilo.display === "none" || estilo.visibility === "hidden") return false;
  }
  return true;
}

function montarAvatares(raiz) {
  if (!raiz || !raiz.querySelectorAll) return;
  const quieto = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  raiz.querySelectorAll(".avatar-vivo:not([data-listo])").forEach((nodo) => {
    const id = nodo.dataset.avatar || "";
    const base = nodo.dataset.cara || ("avatares/" + id);
    const info = (estado && estado.caras && estado.caras[id]) || null;
    const quietoExt = (info && info.quieto) || "png";
    const png = base + "." + quietoExt;
    const conFoto = nodo.dataset.foto === "1";
    // Vista oculta (Sala o Equipo sin abrir, chips del chat): foto fija ya, sin WebM.
    // Así la cara no se queda en emoji. Al enseñar la vista, mostrarVista vuelve a
    // montar y entonces llega el clip. Siete WebM ocultos eran descodificaciones de más.
    if (!avatarEnPantalla(nodo)) {
      if (!conFoto) {
        nodo.dataset.foto = "1";
        cargarImagenAvatar(nodo, png);
      }
      return;
    }
    nodo.dataset.listo = "1";
    // En la e2e el 27B va en CPU. Un WebM por cara no deja salir el relato.
    if (nodo.closest("#mensajes")) {
      const vivo = tomarClipHilo(id);
      if (vivo) {
        marcarClipAvatar(nodo, vivo);
        vivo.play().catch(() => {});
        return;
      }
    }
    if (quieto || (estado && estado.e2e)) {
      if (!conFoto) cargarImagenAvatar(nodo, png);
      return;
    }
    if (!conFoto) cargarImagenAvatar(nodo, png);
    cargarVideoAvatar(nodo, base + ".webm", png);
  });
  if (raiz.id === "mensajes") soltarClipsHiloSobrantes();
}

function pintarChipsEquipo() {
  const caja = $("#equipo-chat");
  const sel = $("#chat-agente");
  if (!caja || !sel) return;
  const lista = estado.equipo || [];
  if (!lista.length) {
    caja.innerHTML = "";
    return;
  }
  const activo = sel.value || "chat";
  const marca = estado.equipoEstado || "listo";
  caja.innerHTML = lista.map((a) => {
    const elegido = a.id === activo;
    const estadoTexto = elegido ? (ESTADO_EQUIPO[marca] || "Listo") : "";
    return `<button type="button" class="equipo-chip" role="option" data-id="${esc(a.id)}" aria-selected="${elegido ? "true" : "false"}" data-estado="${elegido ? esc(marca) : "listo"}">`
      + htmlAvatar(a)
      + `<span class="textos"><b>${esc(a.nombre)}</b><small>${esc(a.rol || a.descripcion || "")}</small>`
      + (estadoTexto ? `<small class="estado-agente">${esc(estadoTexto)}</small>` : "")
      + `</span></button>`;
  }).join("");
  montarAvatares(caja);
  caja.querySelectorAll(".equipo-chip").forEach((b) => {
    b.onclick = () => {
      sel.value = b.dataset.id;
      estado.equipoEstado = "listo";
      pintarAgenteActivo();
    };
  });
}

function marcarEstadoEquipo(valor) {
  estado.equipoEstado = valor === "trabajando" || valor === "error" ? valor : "listo";
  pintarAgenteActivo();
}

function pintarOnboardingEquipo() {
  const caja = $("#equipo-onboarding");
  if (!caja) return;
  let visto = false;
  try { visto = localStorage.getItem(EQUIPO_VISTO) === "1"; } catch (e) { visto = true; }
  caja.hidden = visto;
}

function cerrarOnboardingEquipo() {
  try { localStorage.setItem(EQUIPO_VISTO, "1"); } catch (e) { /* sin almacén, se vuelve a enseñar */ }
  const caja = $("#equipo-onboarding");
  if (caja) caja.hidden = true;
}

function pintarAgentes() {
  api().agentes_estado().then(pintarEstadoAgentes).catch(() => {
    $("#agentes-aviso").innerHTML = aviso("err", esc("No he podido abrir los agentes."));
  });
}

function pintarEstadoAgentes(r) {
  if (!r) return;
  const avisoCaja = $("#agentes-aviso");
  const permitido = r.permitido !== false && r.ok !== false;
  if (!permitido) {
    avisoCaja.innerHTML = aviso("warn", esc(r.aviso || r.error || "No he podido abrir los agentes."));
  } else if (r.error) {
    avisoCaja.innerHTML = aviso("err", esc(r.error));
  } else {
    avisoCaja.innerHTML = "";
  }
  ag.carpetas = r.carpetas || [];
  pintarPlanAgente(r);
  const cajaPlan = $("#agentes-plan");
  if (cajaPlan && r.habilidades) {
    const nombres = Array.isArray(r.habilidades.nombres) ? r.habilidades.nombres : [];
    const texto = nombres.length
      ? `Habilidades locales (${nombres.length}): ${nombres.join(", ")}. Están en este equipo y no salen a la red.`
      : "Habilidades locales: ninguna todavía. Puedes dejar un SKILL.md en la carpeta de datos, sin red.";
    cajaPlan.insertAdjacentHTML("beforeend", `<p>${esc(texto)}</p>`);
  }
  ag.equipo = r.equipo || ag.equipo || [];
  ag.avatares = r.avatares || ag.avatares || [];
  if (estado && Array.isArray(r.equipo) && r.equipo.length) estado.equipo = r.equipo;
  if (estado && Array.isArray(r.avatares)) estado.avatares = r.avatares;
  if (estado && r.caras && typeof r.caras === "object") estado.caras = r.caras;
  pintarEquipoPagina();
  pintarListaAgentes(r.agentes || [], permitido);
  pintarCarpetasAgente();
  pintarSelectorAgentes(r.agentes || []);
  pintarOpcionesAvatar($("#ag-avatar"), "zen");
  ["agentes-editor", "agentes-tarea"].forEach((id) => {
    const nodo = document.getElementById(id);
    if (nodo) nodo.classList.toggle("oculto", !permitido);
  });
}

function pintarPlanAgente(r) {
  const caja = $("#agentes-plan");
  if (!caja) return;
  if (!r || r.permitido === false) {
    caja.innerHTML = "";
    return;
  }
  const plan = r.plan;
  if (!r.motor_ligero) {
    caja.innerHTML = "<h3>Modelo del chat</h3><p>Tus compañeros usan el mismo modelo que el chat. No hace falta instalar nada más.</p>";
    return;
  }
  if (!plan) {
    caja.innerHTML = "<h3>Modelo del chat</h3><p>Hay un modelo aparte en este equipo, pero no he podido leer sus datos.</p>"
      + '<div class="acciones"><button type="button" id="ag-plan">Volver a leer el plan</button></div>';
  } else {
    const filas = [
      ["Modelo", plan.modelo],
      ["Cuantización", plan.cuantizacion],
      ["Régimen", plan.regimen],
      ["Estimación", plan.estimacion],
    ].filter((par) => par[1]);
    const lista = filas.map((par) => `<div><small>${esc(par[0])}</small><b>${esc(par[1])}</b></div>`).join("");
    const args = plan.argumentos
      ? `<p class="mono">${esc(plan.argumentos)}</p><small>Argumentos de llama-server. Sopa los enseña y no los lanza.</small>`
      : "";
    const equipo = (r.hardware || []).map((d) => `${esc(d.clave)}: ${esc(d.valor)}`).join(" · ");
    caja.innerHTML = `<h3>Modelo del chat</h3><p>Tus compañeros usan el modelo del chat.</p>`
      + `<details><summary>Detalles del modelo aparte</summary><div class="filas">${lista}</div>${args}`
      + (equipo ? `<small>${equipo}</small>` : "")
      + "</details>"
      + '<div class="acciones"><button type="button" id="ag-plan">Volver a leer el plan</button></div>';
  }
  const boton = $("#ag-plan");
  if (boton) boton.onclick = async () => {
    const nuevo = await api().agentes_plan();
    if (!nuevo || nuevo.ok === false) {
      $("#agentes-aviso").innerHTML = aviso("err", esc((nuevo && nuevo.error) || "No he podido leer el plan."));
      return;
    }
    pintarPlanAgente({ permitido: true, motor_ligero: nuevo.motor_ligero, plan: nuevo.plan, hardware: nuevo.hardware });
  };
}

function pintarListaAgentes(agentes, permitido) {
  const caja = $("#agentes-lista");
  if (!caja) return;
  if (!permitido) {
    caja.innerHTML = "";
    return;
  }
  if (!agentes.length) {
    caja.innerHTML = "<p>Todavía no hay ninguno. Crea el primero aquí abajo.</p>";
    return;
  }
  caja.innerHTML = agentes.map((a) => (
    `<div class="filas"><div>${htmlAvatar(a)}<b>${esc(a.nombre)}</b><small>${esc(a.rol || a.descripcion || a.instrucciones || "")}</small></div>`
    + `<div class="acciones"><button type="button" data-editar="${esc(a.id)}">Editar</button>`
    + `<button type="button" class="fantasma peligro" data-borrar="${esc(a.id)}">Borrar</button></div></div>`
  )).join("");
  montarAvatares(caja);
  caja.querySelectorAll("[data-editar]").forEach((b) => {
    b.onclick = () => {
      const encontrado = agentes.find((a) => a.id === b.dataset.editar);
      if (encontrado) cargarFormularioAgente(encontrado);
    };
  });
  caja.querySelectorAll("[data-borrar]").forEach((b) => {
    b.onclick = () => borrarAgente(b.dataset.borrar);
  });
}

function pintarCarpetasAgente(elegidas) {
  const caja = $("#ag-carpetas");
  if (!caja) return;
  const marcas = new Set(elegidas || []);
  if (!ag.carpetas.length) {
    caja.innerHTML = "<small>Aún no hay carpetas autorizadas. Se añaden en Ajustes.</small>";
    return;
  }
  caja.innerHTML = ag.carpetas.map((c) => (
    `<label class="interruptor"><input type="checkbox" value="${esc(c.id)}"${marcas.has(c.id) ? " checked" : ""}> `
    + `${esc(c.nombre)}</label>`
  )).join("");
}

function pintarSelectorAgentes(agentes) {
  const sel = $("#ag-elegido");
  if (!sel) return;
  const previo = sel.value;
  sel.innerHTML = agentes.map((a) => `<option value="${esc(a.id)}">${esc(a.nombre)}</option>`).join("");
  if (previo && agentes.some((a) => a.id === previo)) sel.value = previo;
}

function cargarFormularioAgente(a) {
  ag.editando = a.id;
  $("#agentes-form-titulo").textContent = "Editar agente";
  $("#ag-nombre").value = a.nombre || "";
  $("#ag-descripcion").value = a.descripcion || "";
  pintarOpcionesAvatar($("#ag-avatar"), a.avatar || "zen");
  $("#ag-instrucciones").value = a.instrucciones || "";
  $("#ag-motor").value = a.motor || "llama";
  $("#ag-modo").value = a.modo || "";
  $("#ag-modelo").value = a.modelo || "";
  $("#ag-pasos").value = a.max_pasos || 8;
  $("#ag-tokens").value = a.max_tokens || 1024;
  document.querySelectorAll("#ag-herramientas input").forEach((input) => {
    input.checked = (a.herramientas || []).includes(input.value);
  });
  pintarCarpetasAgente(a.carpetas || []);
}

function limpiarFormularioAgente() {
  ag.editando = null;
  $("#agentes-form-titulo").textContent = "Nuevo agente";
  $("#agentes-form").reset();
  $("#ag-pasos").value = 8;
  $("#ag-tokens").value = 1024;
  pintarCarpetasAgente([]);
}

function definicionFormulario() {
  const herramientas = [...document.querySelectorAll("#ag-herramientas input:checked")].map((input) => input.value);
  const carpetas = [...document.querySelectorAll("#ag-carpetas input:checked")].map((input) => input.value);
  const modo = $("#ag-modo").value;
  const modelo = $("#ag-modelo").value.trim();
  return {
    nombre: $("#ag-nombre").value.trim(),
    descripcion: $("#ag-descripcion").value.trim(),
    instrucciones: $("#ag-instrucciones").value.trim(),
    herramientas,
    carpetas,
    motor: $("#ag-motor").value,
    modo: modo || null,
    modelo: modelo || null,
    max_pasos: Number($("#ag-pasos").value),
    max_tokens: Number($("#ag-tokens").value),
  };
}

async function guardarAgente(ev) {
  ev.preventDefault();
  const cuerpo = definicionFormulario();
  const r = ag.editando
    ? await api().agentes_editar(ag.editando, cuerpo)
    : await api().agentes_crear(cuerpo);
  if (!r || r.ok === false) {
    $("#agentes-aviso").innerHTML = aviso("err", esc((r && r.error) || "No he podido guardarlo."));
    return;
  }
  const ident = r.agente && r.agente.id;
  if (ident && $("#ag-avatar")) {
    const cara = await api().equipo_guardar(ident, {
      nombre: cuerpo.nombre.slice(0, 40),
      rol: (cuerpo.descripcion || "Agente de este equipo").slice(0, 60),
      descripcion: (cuerpo.descripcion || "Agente de este equipo.").slice(0, 200),
      avatar: $("#ag-avatar").value || "zen",
    }, true);
    if (!cara || cara.ok === false) {
      $("#agentes-aviso").innerHTML = aviso("warn", esc((cara && cara.error) || "El agente está guardado, pero no he podido cambiar la cara."));
    }
  }
  limpiarFormularioAgente();
  pintarEstadoAgentes(await api().agentes_estado());
  toast("Agente guardado.");
}

async function borrarAgente(ident) {
  if (!confirm("¿Borrar este agente? No borra archivos de tus carpetas.")) return;
  const r = await api().agentes_borrar(ident);
  if (!r || r.ok === false) {
    $("#agentes-aviso").innerHTML = aviso("err", esc((r && r.error) || "No he podido borrarlo."));
    return;
  }
  if (ag.editando === ident) limpiarFormularioAgente();
  pintarEstadoAgentes(await api().agentes_estado());
}

function pintarEventosAgente(eventos) {
  const caja = $("#agentes-eventos");
  if (!caja) return;
  const texto = {
    paso: (e) => `Paso ${e.n} de ${e.de}.`,
    herramienta: (e) => e.que || (e.hecho ? "He usado una herramienta." : "No he usado esa herramienta."),
    vista_previa: () => "Hay una vista previa para confirmar.",
    final: (e) => e.texto || "",
  };
  caja.innerHTML = (eventos || []).map((e) => `<small>${esc((texto[e.tipo] || (() => ""))(e))}</small>`).join("");
}

function pintarPropuestaAgente(p) {
  const caja = $("#agentes-propuesta");
  if (!caja) return;
  if (!p || !p.id || p.rechazada) {
    caja.innerHTML = p && p.que ? aviso("info", esc(p.que)) : "";
    return;
  }
  ag.propuesta = p;
  const rutas = (p.rutas || []).map((r) => `<li>${esc(r.donde || "")} ${esc(r.carpeta || "")} / ${esc(r.ruta || "")}</li>`).join("");
  const contenido = p.contenido != null ? `<pre class="vista-previa">${esc(p.contenido)}</pre>` : "";
  const sobre = p.sobrescribe || ag.sobrescribir
    ? `<p>${esc(p.aviso || "Ya hay algo con ese nombre. Si confirmas otra vez, lo de ahora va a la papelera de reciclaje.")}</p>` : "";
  caja.innerHTML = `<div class="tarjeta propuesta-accion"><b>${esc(p.que || "Tienes una acción para revisar.")}</b>`
    + `<ul>${rutas}</ul>${contenido}${sobre}`
    + '<div class="acciones"><button class="primario" type="button" id="ag-si">Confirmar</button>'
    + '<button class="fantasma" type="button" id="ag-no">Cancelar</button></div></div>';
  $("#ag-si").onclick = () => resolverPropuestaAgente(true);
  $("#ag-no").onclick = () => resolverPropuestaAgente(false);
}

async function lanzarAgente(ev) {
  ev.preventDefault();
  if (ag.ocupado) return;
  const ident = $("#ag-elegido").value;
  const tarea = $("#ag-tarea").value.trim();
  if (!ident || !tarea) {
    $("#agentes-aviso").innerHTML = aviso("err", esc("Elige un agente y escribe la tarea."));
    return;
  }
  ag.ocupado = true;
  ag.sobrescribir = false;
  ag.eventos = [];
  $("#agentes-propuesta").innerHTML = "";
  $("#agentes-eventos").innerHTML = aviso("info", "Trabajando…");
  const r = await api().agentes_lanzar(ident, tarea);
  ag.ocupado = false;
  if (!r || r.ok === false) {
    $("#agentes-eventos").innerHTML = "";
    $("#agentes-aviso").innerHTML = aviso("err", esc((r && r.error) || "No he podido lanzarlo."));
    return;
  }
  aplicarResultadoAgente(r);
}

function aplicarResultadoAgente(r) {
  ag.carrera = r.carrera || ag.carrera;
  $("#agentes-aviso").innerHTML = "";
  ag.eventos = (ag.eventos || []).concat(r.eventos || []);
  pintarEventosAgente(ag.eventos);
  if (r.necesita_sobrescribir) {
    ag.sobrescribir = true;
    pintarPropuestaAgente({ ...(ag.propuesta || {}), id: (r.propuesta && r.propuesta.id) || (ag.propuesta && ag.propuesta.id), sobrescribe: true, aviso: r.texto });
    return;
  }
  if (r.estado === "esperando" && r.propuesta) {
    pintarPropuestaAgente(r.propuesta);
    return;
  }
  ag.propuesta = null;
  ag.sobrescribir = false;
  const finales = (ag.eventos || []).filter((e) => e.tipo === "final");
  const ultimo = finales[finales.length - 1];
  const mal = ultimo && (ultimo.motivo === "error" || ultimo.motivo === "rechazo");
  $("#agentes-propuesta").innerHTML = r.texto ? aviso(mal ? "err" : "ok", esc(r.texto)) : "";
}

async function resolverPropuestaAgente(aceptar) {
  if (!ag.carrera || !ag.propuesta || ag.ocupado) return;
  ag.ocupado = true;
  const r = aceptar
    ? await api().agentes_confirmar(ag.carrera, ag.propuesta.id, ag.sobrescribir)
    : await api().agentes_cancelar(ag.carrera, ag.propuesta.id);
  ag.ocupado = false;
  if (!r || r.ok === false) {
    $("#agentes-aviso").innerHTML = aviso("err", esc((r && r.error) || "No he podido hacerlo."));
    return;
  }
  if (!r.necesita_sobrescribir) ag.propuesta = null;
  aplicarResultadoAgente(r);
}

function pintarOpcionesAvatar(sel, elegido) {
  if (!sel) return;
  const lista = (estado && estado.avatares && estado.avatares.length) ? estado.avatares : ag.avatares;
  if (!lista.length) {
    sel.innerHTML = `<option value="zen">⚪</option>`;
    return;
  }
  sel.innerHTML = lista.map((a) => `<option value="${esc(a.id)}">${esc(a.emoji)} ${esc(a.id)}</option>`).join("");
  if ([...sel.options].some((o) => o.value === elegido)) sel.value = elegido;
}

function pintarEquipoPagina() {
  const caja = $("#equipo-lista");
  if (!caja) return;
  const lista = ag.equipo || [];
  if (!lista.length) {
    caja.innerHTML = "<p>El equipo aparece al abrir esta pantalla.</p>";
    return;
  }
  caja.innerHTML = lista.map((a) => {
    const prev = (estado.previews && estado.previews[a.id]) || "Aún no habéis hablado";
    return `<article class="equipo-ficha" data-agente="${esc(a.id)}">${htmlAvatar(a, "grande")}`
      + `<div class="equipo-textos"><b>${esc(a.nombre)}</b><small>${esc(a.rol || "")}</small><small>${esc(prev)}</small></div>`
      + `<div class="acciones"><button type="button" class="primario" data-abrir="${esc(a.id)}">Abrir chat</button>`
      + `<button type="button" class="fantasma" data-equipo="${esc(a.id)}">Editar</button></div></article>`;
  }).join("");
  montarAvatares(caja);
  caja.querySelectorAll("[data-abrir]").forEach((b) => {
    b.onclick = () => entrarEnAgente(b.dataset.abrir);
  });
  caja.querySelectorAll("[data-equipo]").forEach((b) => {
    b.onclick = () => abrirEquipo(b.dataset.equipo);
  });
}

function entrarEnAgente(ident) {
  const sel = $("#chat-agente");
  if (sel && [...sel.options].some((o) => o.value === ident)) {
    sel.value = ident;
    if (window.pywebview) sel.dispatchEvent(new Event("change"));
    else if (typeof pintarAgenteActivo === "function") pintarAgenteActivo();
  }
  if (!window.pywebview) {
    document.querySelectorAll(".vista").forEach((v) => v.classList.toggle("visible", v.id === "vista-chat"));
    marcarNav("chat");
    if (typeof pintarMensajes === "function") pintarMensajes();
    return;
  }
  if (typeof mostrarVista === "function") mostrarVista("chat");
}

function textoPreview(texto) {
  const limpio = String(texto || "").replace(/\s+/g, " ").trim();
  if (!limpio) return "";
  return limpio.length > 84 ? limpio.slice(0, 83).trim() + "…" : limpio;
}

function pintarSala() {
  const caja = $("#sala-agentes");
  if (!caja) return;
  const lista = (estado.equipo && estado.equipo.length) ? estado.equipo : [];
  const activo = ($("#chat-agente") && $("#chat-agente").value) || "chat";
  const previews = estado.previews || {};
  caja.innerHTML = lista.map((a) => {
    const prev = previews[a.id] || "Aún no habéis hablado";
    const on = a.id === activo;
    return `<button type="button" class="sala-item" role="option" data-sala="${esc(a.id)}" data-agente="${esc(a.id)}" aria-selected="${on ? "true" : "false"}">`
      + htmlAvatar(a, true)
      + `<span class="sala-textos"><span class="sala-nombre">${esc(a.nombre)}</span>`
      + `<span class="sala-preview">${esc(prev)}</span></span></button>`;
  }).join("");
  caja.querySelectorAll("[data-sala]").forEach((b) => {
    b.onclick = () => {
      const sel = $("#chat-agente");
      if (!sel || sel.value === b.dataset.sala) return;
      sel.value = b.dataset.sala;
      sel.dispatchEvent(new Event("change"));
    };
  });
  montarAvatares(caja);
  const quien = $("#sala-quien");
  const ficha = fichaEquipo(activo) || { nombre: "Sopa", rol: "Conversación", emoji: "🥣", animacion: "vapor", avatar: "sprout", cara: "avatares/sprout" };
  if (quien) {
    quien.innerHTML = htmlAvatar(ficha, true) + `<div><h1>${esc(ficha.nombre)}</h1><p>${esc(ficha.rol || "")}</p></div>`;
    montarAvatares(quien);
  }
  const elegido = caja.querySelector('[aria-selected="true"]');
  if (elegido && elegido.scrollIntoView) elegido.scrollIntoView({ block: "nearest" });
}

function recordarHiloLocal(agente) {
  const id = agente || (($("#chat-agente") && $("#chat-agente").value) || "chat");
  estado.hilos = estado.hilos || {};
  estado.hilos[id] = {
    id: estado.conversacion,
    mensajes: (estado.mensajes || []).slice(),
    documentos: (estado.docs || []).slice(),
    version: estado.versionConv || 0,
  };
  const ultima = [...(estado.mensajes || [])].reverse().find((m) => m.role === "assistant" && String(m.content || "").trim());
  if (ultima) {
    estado.previews = estado.previews || {};
    estado.previews[id] = textoPreview(ultima.content);
  }
  pintarSala();
}

function aplicarHilo(r) {
  estado.conversacion = r.id;
  estado.versionConv = r.version || 0;
  estado.mensajes = r.mensajes || [];
  estado.docs = r.documentos || [];
  const id = r.agente || (($("#chat-agente") && $("#chat-agente").value) || "chat");
  estado.hilos = estado.hilos || {};
  estado.hilos[id] = {
    id: r.id, mensajes: estado.mensajes.slice(), documentos: estado.docs.slice(), version: estado.versionConv,
  };
  if (r.preview) {
    estado.previews = estado.previews || {};
    estado.previews[id] = r.preview;
  }
  if (typeof pintarDocs === "function") pintarDocs();
  if (typeof pintarMensajes === "function") pintarMensajes();
  pintarSala();
}

async function abrirHilo(ident, token) {
  if (typeof api !== "function") return;
  const local = estado.hilos && estado.hilos[ident];
  const r = await api().hilo_abrir(ident);
  if (token !== estado.hiloToken || !r || r.ok === false) return;
  if ((($("#chat-agente") && $("#chat-agente").value) || "chat") !== ident) return;
  // «Nueva» acaba de dejar un hilo vacío. No recuperes el anterior: el 27B se atasca con el prefill.
  if (local && local.fresco && !(local.mensajes || []).length) {
    api().hilo_fijar(ident, local.id);
    return;
  }
  aplicarHilo(r);
}

async function cargarPreviews() {
  if (typeof api !== "function") return;
  try {
    const r = await api().hilos_resumen();
    estado.previews = estado.previews || {};
    (r && r.hilos || []).forEach((h) => {
      if (h && h.id && h.preview) estado.previews[h.id] = h.preview;
    });
  } catch (e) { /* la lista sigue con lo que haya */ }
  pintarSala();
}

function prepararHilo() {
  estado.hiloToken = (estado.hiloToken || 0) + 1;
  const id = ($("#chat-agente") && $("#chat-agente").value) || "chat";
  const cache = estado.hilos && estado.hilos[id];
  if (cache && cache.id) {
    estado.conversacion = cache.id;
    estado.mensajes = (cache.mensajes || []).slice();
    estado.docs = cache.documentos || [];
    estado.versionConv = cache.version || 0;
    if (typeof pintarDocs === "function") pintarDocs();
    if (typeof pintarMensajes === "function") pintarMensajes();
  }
  abrirHilo(id, estado.hiloToken);
  cargarPreviews();
}

function cambiarAgenteVisible() {
  estado.equipoEstado = "listo";
  estado.hiloToken = (estado.hiloToken || 0) + 1;
  const token = estado.hiloToken;
  const sel = $("#chat-agente");
  const id = (sel && sel.value) || "chat";
  estado.agenteTurno = id;
  const panel = $("#sala-panel-recuerdos");
  if (panel && !panel.hidden) pintarRecuerdos();
  const cache = estado.hilos && estado.hilos[id];
  if (cache && cache.id) {
    estado.conversacion = cache.id;
    estado.mensajes = (cache.mensajes || []).slice();
    estado.docs = cache.documentos || [];
    estado.versionConv = cache.version || 0;
    if (typeof pintarDocs === "function") pintarDocs();
    if (typeof pintarMensajes === "function") pintarMensajes();
    pintarSala();
  } else {
    estado.mensajes = [];
    estado.conversacion = null;
    estado.docs = [];
    if (typeof pintarDocs === "function") pintarDocs();
    if (typeof pintarMensajes === "function") pintarMensajes();
    pintarSala();
  }
  if (typeof pintarAgenteActivo === "function") pintarAgenteActivo();
  abrirHilo(id, token);
}

function empezarHilo() {
  const agente = ($("#chat-agente") && $("#chat-agente").value) || "chat";
  estado.hiloToken = (estado.hiloToken || 0) + 1;
  estado.mensajes = [];
  estado.docs = [];
  estado.conversacion = "conv-" + Date.now();
  estado.versionConv = 0;
  estado.hilos = estado.hilos || {};
  estado.hilos[agente] = { id: estado.conversacion, mensajes: [], documentos: [], version: 0, fresco: true };
  estado.previews = estado.previews || {};
  estado.previews[agente] = "";
  if (typeof pintarDocs === "function") pintarDocs();
  if (typeof pintarMensajes === "function") pintarMensajes();
  document.querySelectorAll("[data-conv]").forEach((e) => e.classList.remove("activa"));
  pintarSala();
  if (typeof api === "function") api().hilo_fijar(agente, estado.conversacion);
}

async function pintarRecuerdos() {
  const panel = $("#sala-panel-recuerdos");
  if (!panel || panel.hidden) return;
  const id = ($("#chat-agente") && $("#chat-agente").value) || "chat";
  const ficha = fichaEquipo(id);
  const nombre = (ficha && ficha.nombre) || "este agente";
  let r = null;
  try { r = await api().memoria_agente(id); } catch (e) { r = null; }
  const entradas = (r && r.entradas) || [];
  const lista = entradas.length
    ? entradas.map((e) => `<li><span>${esc(e.texto)}</span><button type="button" class="fantasma" data-olvido="${esc(e.id)}">Quitar</button></li>`).join("")
    : `<li class="sala-vacio">Todavía no recuerda nada. Pídeselo en el chat («Recuerda que…») o escríbelo aquí.</li>`;
  panel.innerHTML = `<div class="sala-recuerdos-cabeza"><b>Lo que recuerda ${esc(nombre)}</b><button type="button" class="fantasma" id="sala-recuerdos-cerrar">Cerrar</button></div>`
    + `<ul>${lista}</ul>`
    + `<form id="sala-recuerdo-form"><input id="sala-recuerdo-texto" maxlength="500" placeholder="Algo que deba recordar…" aria-label="Nuevo recuerdo"><button class="primario" type="submit">Guardar</button></form>`;
  const cerrar = $("#sala-recuerdos-cerrar");
  if (cerrar) cerrar.onclick = () => { panel.hidden = true; };
  panel.querySelectorAll("[data-olvido]").forEach((b) => {
    b.onclick = async () => {
      await api().memoria_agente_borrar(id, b.dataset.olvido);
      pintarRecuerdos();
    };
  });
  const form = $("#sala-recuerdo-form");
  if (form) form.onsubmit = async (ev) => {
    ev.preventDefault();
    const texto = $("#sala-recuerdo-texto").value.trim();
    if (!texto) return;
    const hecho = await api().memoria_agente_añadir(id, texto);
    if (!hecho || hecho.ok === false) {
      $("#aviso-chat").innerHTML = aviso("err", esc((hecho && hecho.error) || "No he podido guardarlo."));
      return;
    }
    pintarRecuerdos();
  };
}

function alternarRecuerdos() {
  const panel = $("#sala-panel-recuerdos");
  if (!panel) return;
  panel.hidden = !panel.hidden;
  if (!panel.hidden) pintarRecuerdos();
}

function abrirEquipo(ident) {
  const ficha = (ag.equipo || []).find((a) => a.id === ident);
  const form = $("#equipo-form");
  if (!ficha || !form) return;
  ag.editandoEquipo = ident;
  form.hidden = false;
  $("#equipo-form-titulo").textContent = ficha.nombre;
  $("#eq-nombre").value = ficha.nombre || "";
  $("#eq-rol").value = ficha.rol || "";
  $("#eq-descripcion").value = ficha.descripcion || "";
  $("#eq-instrucciones").value = ficha.instrucciones || "";
  const cajaNota = $("#eq-instrucciones-caja");
  if (cajaNota) cajaNota.hidden = false;
  pintarOpcionesAvatar($("#eq-avatar"), ficha.avatar || "zen");
}

function cerrarEquipo() {
  ag.editandoEquipo = null;
  const form = $("#equipo-form");
  if (form) form.hidden = true;
}

async function guardarEquipo(ev) {
  ev.preventDefault();
  if (!ag.editandoEquipo) return;
  const ficha = (ag.equipo || []).find((a) => a.id === ag.editandoEquipo);
  const cambios = {
    nombre: $("#eq-nombre").value.trim(),
    rol: $("#eq-rol").value.trim(),
    descripcion: $("#eq-descripcion").value.trim(),
    avatar: $("#eq-avatar").value,
  };
  cambios.instrucciones = $("#eq-instrucciones").value.trim();
  const r = await api().equipo_guardar(ag.editandoEquipo, cambios);
  if (!r || r.ok === false) {
    $("#agentes-aviso").innerHTML = aviso("err", esc((r && r.error) || "No he podido guardar el compañero."));
    return;
  }
  cerrarEquipo();
  if (typeof cargarAgentesChat === "function") await cargarAgentesChat();
  pintarEstadoAgentes(await api().agentes_estado());
  toast("Compañero guardado.");
}

async function restablecerEquipo() {
  if (!ag.editandoEquipo) return;
  const r = await api().equipo_restablecer(ag.editandoEquipo);
  if (!r || r.ok === false) {
    $("#agentes-aviso").innerHTML = aviso("err", esc((r && r.error) || "No he podido volver al original."));
    return;
  }
  cerrarEquipo();
  if (typeof cargarAgentesChat === "function") await cargarAgentesChat();
  pintarEstadoAgentes(await api().agentes_estado());
  toast("Nombre original recuperado.");
}

(function () {
  const previa = window.mostrarVista;
  if (typeof previa === "function") {
    window.mostrarVista = function (nombre) {
      if (nombre !== "agentes") {
        const intro = document.getElementById("intro-pool");
        const caja = document.getElementById("intro-agentes");
        if (intro) { intro.pause(); intro.removeAttribute("src"); intro.load(); }
        if (caja) caja.hidden = true;
      }
      window.__verAjustesAgente = false;
      previa(nombre);
      if (nombre === "agentes") {
        reproducirIntroAgentes();
        if (window.pywebview) pintarAgentes();
        else if (ag.equipo && ag.equipo.length) pintarEquipoPagina();
      }
    };
    window.__abrirAjustesAgente = async function (id) {
      window.__verAjustesAgente = true;
      previa("agentes");
      reproducirIntroAgentes();
      try {
        pintarEstadoAgentes(await api().agentes_estado());
      } catch (e) { /* el formulario sigue */ }
      if (id) abrirEquipo(id);
    };
  }
  window.addEventListener("pywebviewready", () => {
    const form = $("#agentes-form");
    const lanzar = $("#agentes-lanzar");
    const limpiar = $("#ag-limpiar");
    if (form) form.onsubmit = guardarAgente;
    if (lanzar) lanzar.onsubmit = lanzarAgente;
    if (limpiar) limpiar.onclick = limpiarFormularioAgente;
    const equipo = $("#equipo-form");
    const entendido = $("#equipo-entendido");
    if (equipo) equipo.onsubmit = guardarEquipo;
    if ($("#eq-cerrar")) $("#eq-cerrar").onclick = cerrarEquipo;
    if ($("#eq-restablecer")) $("#eq-restablecer").onclick = restablecerEquipo;
    if (entendido) entendido.onclick = cerrarOnboardingEquipo;
    const ajustes = $("#sala-ajustes");
    const editarSala = $("#sala-editar");
    const recuerdos = $("#sala-recuerdos");
    if (ajustes) ajustes.onclick = () => window.__abrirAjustesAgente(($("#chat-agente") && $("#chat-agente").value) || "chat");
    if (editarSala) editarSala.onclick = () => window.__abrirAjustesAgente(($("#chat-agente") && $("#chat-agente").value) || "chat");
    if (recuerdos) recuerdos.onclick = alternarRecuerdos;
    const nueva = $("#chat-nueva");
    if (nueva) nueva.onclick = empezarHilo;
    const sel = $("#chat-agente");
    if (sel) sel.onchange = cambiarAgenteVisible;
  });
  document.addEventListener("DOMContentLoaded", () => {
    if (window.pywebview) return;
    const params = new URLSearchParams(location.search);
    if (params.get("tema") === "oscuro" || params.get("tema") === "claro") document.documentElement.dataset.tema = params.get("tema");
    if (params.get("muestra") !== "equipo") return;
    const ver = $("#version");
    if (ver) ver.textContent = "Versión 2.0.0";
    estado.equipo = [
      { id: "chat", nombre: "Sopa", rol: "Conversación", descripcion: "Habla contigo en este equipo.", emoji: "🥣", animacion: "vapor", avatar: "sprout" },
      { id: "director", nombre: "Director", rol: "Coordinador", descripcion: "Entiende el pedido y lo hace.", emoji: "🎭", animacion: "saludo", avatar: "saturn", persona: true },
      { id: "codigo", nombre: "Código", rol: "Programar", descripcion: "Escribe y revisa código.", emoji: "💻", animacion: "tecleo", avatar: "circuit", persona: true },
      { id: "documentos", nombre: "Documentos", rol: "Leer documentos", descripcion: "Resume PDF, Word y Excel.", emoji: "📄", animacion: "hojeo", avatar: "mirage" },
      { id: "archivos", nombre: "Archivos", rol: "Ordenar carpetas", descripcion: "Ordena y espera confirmación.", emoji: "📁", animacion: "orden", avatar: "alloy" },
      { id: "investigacion", nombre: "Investigación", rol: "Buscar y citar", descripcion: "Busca y cita las fuentes.", emoji: "🔎", animacion: "busqueda", avatar: "proton" },
      { id: "automatizaciones", nombre: "Automatizaciones", rol: "Tareas repetidas", descripcion: "Prepara tareas que se confirman.", emoji: "⚙️", animacion: "engranaje", avatar: "volt" },
    ];
    estado.agenteTurno = "director";
    estado.equipoEstado = "trabajando";
    const sel = $("#chat-agente");
    if (sel) sel.value = "director";
    estado.mensajes = [
      { role: "user", content: "Programa la pantalla de inicio, entera.", origen: "escritorio" },
      { role: "assistant", content: "Soy Director. Empiezo por el escritorio y te dejo el código en este turno, sin repetir el plan.", agente: "director", agente_nombre: "Director", origen: "escritorio" },
    ];
    ag.equipo = estado.equipo;
    const vista = params.get("vista") === "agentes" ? "agentes" : "chat";
    document.querySelectorAll(".vista").forEach((v) => v.classList.toggle("visible", v.id === "vista-" + vista));
    marcarNav(vista);
    estado.previews = {
      chat: "Puedo ayudarte con lo que tengas en este equipo.",
      director: "Soy Director. Empiezo por el escritorio y te dejo el código en este turno, sin repetir el plan.",
      codigo: "La pantalla de inicio queda en un solo archivo, lista para revisar.",
      documentos: "Puedo resumir un PDF, un Word o un Excel de tus carpetas.",
      archivos: "Dime la carpeta y te enseño el plan antes de mover nada.",
      investigacion: "Puedo buscar y citar las fuentes, si enciendes la web.",
      automatizaciones: "Una tarea se guarda solo después de que la confirmes.",
    };
    pintarChipsEquipo();
    pintarAgenteActivo();
    pintarSala();
    pintarMensajes();
    if (vista === "agentes") {
      pintarEquipoPagina();
      reproducirIntroAgentes();
    }
  });
})();
