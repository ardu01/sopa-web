// Diseño 3D. La vista previa la calcula Python; aquí solo se pinta.
"use strict";
let disenoCodigo = "";

async function cargarDiseno3d() {
  const caja = $("#diseno3d-estado");
  if (!caja) return;
  try {
    const r = await api().diseno3d_estado();
    if (!r || !r.ok) {
      caja.innerHTML = aviso("err", esc((r && r.error) || "No he podido ver el motor de diseño."));
      return;
    }
    const inventario = r.inventario_aviso
      ? aviso(r.inventario_piezas ? "ok" : "warn", esc(r.inventario_aviso))
      : "";
    caja.innerHTML = aviso("info", esc(r.nota || "Diseño 3D en este equipo.")) + inventario;
  } catch (e) {
    caja.innerHTML = aviso("err", esc("No he podido ver el motor de diseño."));
  }
}

function pintarDiseno(r) {
  const info = (r && r.informe) || {};
  const etiqueta = (r && r.etiqueta) || {};
  const resultado = $("#diseno3d-resultado");
  resultado.hidden = false;
  $("#diseno3d-etiqueta").textContent = etiqueta.texto || "Diseño 3D";
  const img = $("#diseno3d-previa");
  if (info.captura) {
    img.src = info.captura;
    img.hidden = false;
  } else {
    img.removeAttribute("src");
    img.hidden = true;
  }
  const medidas = info.medidas;
  $("#diseno3d-medidas").innerHTML = medidas
    ? tarjeta("Ancho", `${medidas.ancho_mm} mm`, "X")
      + tarjeta("Fondo", `${medidas.fondo_mm} mm`, "Y")
      + tarjeta("Alto", `${medidas.alto_mm} mm`, "Z")
    : "";
  const inventario = info.inventario || {};
  $("#diseno3d-inventario").textContent = inventario.aviso || info.aviso || "";
  disenoCodigo = (r && r.codigo) || "";
  $("#diseno3d-codigo").textContent = disenoCodigo;
  $("#diseno3d-stl-ruta").textContent = "";
}

function engancharDiseno3d() {
  const form = $("#diseno3d-form");
  if (!form || form.dataset.listo === "1") return;
  form.dataset.listo = "1";
  form.onsubmit = async (ev) => {
    ev.preventDefault();
    const boton = $("#diseno3d-preparar");
    boton.disabled = true;
    $("#diseno3d-aviso").innerHTML = aviso("info", "Preparando la pieza…");
    try {
      const r = await api().diseno3d_preparar($("#diseno3d-pedido").value);
      if (!r || !r.ok) {
        $("#diseno3d-aviso").innerHTML = aviso("err", esc((r && r.error) || "No he podido preparar la pieza."));
        return;
      }
      $("#diseno3d-aviso").innerHTML = "";
      pintarDiseno(r);
    } catch (e) {
      $("#diseno3d-aviso").innerHTML = aviso("err", esc("No he podido preparar la pieza."));
    } finally {
      boton.disabled = false;
    }
  };
  const guardar = $("#diseno3d-stl");
  if (guardar) guardar.onclick = async () => {
    if (!disenoCodigo) {
      $("#diseno3d-stl-ruta").textContent = "Todavía no hay una pieza.";
      return;
    }
    try {
      const r = await api().diseno3d_guardar_stl(disenoCodigo, "pieza");
      $("#diseno3d-stl-ruta").textContent = r && r.ok ? r.ruta : ((r && r.error) || "No he podido guardar el STL.");
    } catch (e) {
      $("#diseno3d-stl-ruta").textContent = "No he podido guardar el STL.";
    }
  };
}

engancharDiseno3d();
