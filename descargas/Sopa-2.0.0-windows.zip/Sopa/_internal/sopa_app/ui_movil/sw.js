const CACHE = "sopa-movil-5";
const SHELL = ["/", "/tokens.css", "/manifest.webmanifest", "/icono.png",
  "/iconos/icono-192.png?v=0c7cafb4d1e0", "/iconos/icono-512.png?v=8a4345ffd7bb", "/iconos/icono-maskable-512.png?v=7821e104d9b4"];
const ICONOS_INICIO = new Set([
  "/apple-touch-icon.png",
  "/apple-touch-icon-precomposed.png",
  "/apple-touch-icon-180x180.png",
  "/apple-touch-icon-180x180-precomposed.png",
  "/iconos/apple-touch-icon-180.png",
  "/favicon.ico",
]);
self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => e.waitUntil(
  caches.keys().then((claves) => Promise.all(claves.filter((c) => c !== CACHE).map((c) => caches.delete(c)))).then(() => self.clients.claim())
));
self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  if (ICONOS_INICIO.has(url.pathname)) return;
  if (e.request.method !== "GET" || url.origin !== self.location.origin || url.pathname.startsWith("/api") || url.pathname.startsWith("/e/")) return;
  e.respondWith(fetch(e.request).then((r) => {
    const copia = r.clone();
    caches.open(CACHE).then((c) => c.put(e.request, copia));
    return r;
  }).catch(() => caches.match(e.request)));
});
