// Pestaña Agentes. La lógica vive en Python.
"use strict";
const ag = {
  editando: null,
  carrera: null,
  propuesta: null,
  sobrescribir: false,
  ocupado: false,
  carpetas: [],
};

function pintarAgentes() {
  api().agentes_estado().then(pintarEstadoAgentes).catch(() => {
    $("#agentes-aviso").innerHTML = aviso("err", esc("No he podido abrir los agentes."));
  });
}

function pintarEstadoAgentes(r) {
  if (!r) return;
  const avisoCaja = $("#agentes-aviso");
  const permitido = r.permitido !== false && r.ok !== false;
  if (!permitido) {
    avisoCaja.innerHTML = aviso("warn", esc(r.aviso || r.error || "No he podido abrir los agentes."));
  } else if (r.error) {
    avisoCaja.innerHTML = aviso("err", esc(r.error));
  } else {
    avisoCaja.innerHTML = "";
  }
  ag.carpetas = r.carpetas || [];
  pintarPlanAgente(r);
  pintarListaAgentes(r.agentes || [], permitido);
  pintarCarpetasAgente();
  pintarSelectorAgentes(r.agentes || []);
  ["agentes-editor", "agentes-tarea"].forEach((id) => {
    const nodo = document.getElementById(id);
    if (nodo) nodo.classList.toggle("oculto", !permitido);
  });
}

function pintarPlanAgente(r) {
  const caja = $("#agentes-plan");
  if (!caja) return;
  if (!r || r.permitido === false) {
    caja.innerHTML = "";
    return;
  }
  const plan = r.plan;
  if (!r.motor_ligero) {
    caja.innerHTML = "<h3>Motor ligero</h3><p>No está en este equipo. Los agentes usan el modelo del chat.</p>";
    return;
  }
  if (!plan) {
    caja.innerHTML = "<h3>Motor ligero</h3><p>Está en este equipo, pero no he podido leer el plan.</p>"
      + '<div class="acciones"><button type="button" id="ag-plan">Volver a leer el plan</button></div>';
  } else {
    const filas = [
      ["Modelo", plan.modelo],
      ["Cuantización", plan.cuantizacion],
      ["Régimen", plan.regimen],
      ["Estimación", plan.estimacion],
    ].filter((par) => par[1]);
    const lista = filas.map((par) => `<div><small>${esc(par[0])}</small><b>${esc(par[1])}</b></div>`).join("");
    const args = plan.argumentos
      ? `<p class="mono">${esc(plan.argumentos)}</p><small>Argumentos de llama-server. Sopa los enseña y no los lanza.</small>`
      : "";
    const equipo = (r.hardware || []).map((d) => `${esc(d.clave)}: ${esc(d.valor)}`).join(" · ");
    caja.innerHTML = `<h3>Plan de este equipo</h3><div class="filas">${lista}</div>${args}`
      + (equipo ? `<small>${equipo}</small>` : "")
      + '<div class="acciones"><button type="button" id="ag-plan">Volver a leer el plan</button></div>';
  }
  const boton = $("#ag-plan");
  if (boton) boton.onclick = async () => {
    const nuevo = await api().agentes_plan();
    if (!nuevo || nuevo.ok === false) {
      $("#agentes-aviso").innerHTML = aviso("err", esc((nuevo && nuevo.error) || "No he podido leer el plan."));
      return;
    }
    pintarPlanAgente({ permitido: true, motor_ligero: nuevo.motor_ligero, plan: nuevo.plan, hardware: nuevo.hardware });
  };
}

function pintarListaAgentes(agentes, permitido) {
  const caja = $("#agentes-lista");
  if (!caja) return;
  if (!permitido) {
    caja.innerHTML = "";
    return;
  }
  if (!agentes.length) {
    caja.innerHTML = "<p>Todavía no hay ninguno. Crea el primero aquí abajo.</p>";
    return;
  }
  caja.innerHTML = agentes.map((a) => (
    `<div class="filas"><div><b>${esc(a.nombre)}</b><small>${esc(a.descripcion || a.instrucciones || "")}</small></div>`
    + `<div class="acciones"><button type="button" data-editar="${esc(a.id)}">Editar</button>`
    + `<button type="button" class="fantasma peligro" data-borrar="${esc(a.id)}">Borrar</button></div></div>`
  )).join("");
  caja.querySelectorAll("[data-editar]").forEach((b) => {
    b.onclick = () => {
      const encontrado = agentes.find((a) => a.id === b.dataset.editar);
      if (encontrado) cargarFormularioAgente(encontrado);
    };
  });
  caja.querySelectorAll("[data-borrar]").forEach((b) => {
    b.onclick = () => borrarAgente(b.dataset.borrar);
  });
}

function pintarCarpetasAgente(elegidas) {
  const caja = $("#ag-carpetas");
  if (!caja) return;
  const marcas = new Set(elegidas || []);
  if (!ag.carpetas.length) {
    caja.innerHTML = "<small>Aún no hay carpetas autorizadas. Se añaden en Ajustes.</small>";
    return;
  }
  caja.innerHTML = ag.carpetas.map((c) => (
    `<label class="interruptor"><input type="checkbox" value="${esc(c.id)}"${marcas.has(c.id) ? " checked" : ""}> `
    + `${esc(c.nombre)}</label>`
  )).join("");
}

function pintarSelectorAgentes(agentes) {
  const sel = $("#ag-elegido");
  if (!sel) return;
  const previo = sel.value;
  sel.innerHTML = agentes.map((a) => `<option value="${esc(a.id)}">${esc(a.nombre)}</option>`).join("");
  if (previo && agentes.some((a) => a.id === previo)) sel.value = previo;
}

function cargarFormularioAgente(a) {
  ag.editando = a.id;
  $("#agentes-form-titulo").textContent = "Editar agente";
  $("#ag-nombre").value = a.nombre || "";
  $("#ag-descripcion").value = a.descripcion || "";
  $("#ag-instrucciones").value = a.instrucciones || "";
  $("#ag-motor").value = a.motor || "llama";
  $("#ag-modo").value = a.modo || "";
  $("#ag-modelo").value = a.modelo || "";
  $("#ag-pasos").value = a.max_pasos || 8;
  $("#ag-tokens").value = a.max_tokens || 1024;
  document.querySelectorAll("#ag-herramientas input").forEach((input) => {
    input.checked = (a.herramientas || []).includes(input.value);
  });
  pintarCarpetasAgente(a.carpetas || []);
}

function limpiarFormularioAgente() {
  ag.editando = null;
  $("#agentes-form-titulo").textContent = "Nuevo agente";
  $("#agentes-form").reset();
  $("#ag-pasos").value = 8;
  $("#ag-tokens").value = 1024;
  pintarCarpetasAgente([]);
}

function definicionFormulario() {
  const herramientas = [...document.querySelectorAll("#ag-herramientas input:checked")].map((input) => input.value);
  const carpetas = [...document.querySelectorAll("#ag-carpetas input:checked")].map((input) => input.value);
  const modo = $("#ag-modo").value;
  const modelo = $("#ag-modelo").value.trim();
  return {
    nombre: $("#ag-nombre").value.trim(),
    descripcion: $("#ag-descripcion").value.trim(),
    instrucciones: $("#ag-instrucciones").value.trim(),
    herramientas,
    carpetas,
    motor: $("#ag-motor").value,
    modo: modo || null,
    modelo: modelo || null,
    max_pasos: Number($("#ag-pasos").value),
    max_tokens: Number($("#ag-tokens").value),
  };
}

async function guardarAgente(ev) {
  ev.preventDefault();
  const cuerpo = definicionFormulario();
  const r = ag.editando
    ? await api().agentes_editar(ag.editando, cuerpo)
    : await api().agentes_crear(cuerpo);
  if (!r || r.ok === false) {
    $("#agentes-aviso").innerHTML = aviso("err", esc((r && r.error) || "No he podido guardarlo."));
    return;
  }
  limpiarFormularioAgente();
  pintarEstadoAgentes(await api().agentes_estado());
  toast("Agente guardado.");
}

async function borrarAgente(ident) {
  if (!confirm("¿Borrar este agente? No borra archivos de tus carpetas.")) return;
  const r = await api().agentes_borrar(ident);
  if (!r || r.ok === false) {
    $("#agentes-aviso").innerHTML = aviso("err", esc((r && r.error) || "No he podido borrarlo."));
    return;
  }
  if (ag.editando === ident) limpiarFormularioAgente();
  pintarEstadoAgentes(await api().agentes_estado());
}

function pintarEventosAgente(eventos) {
  const caja = $("#agentes-eventos");
  if (!caja) return;
  const texto = {
    paso: (e) => `Paso ${e.n} de ${e.de}.`,
    herramienta: (e) => e.que || (e.hecho ? "He usado una herramienta." : "No he usado esa herramienta."),
    vista_previa: () => "Hay una vista previa para confirmar.",
    final: (e) => e.texto || "",
  };
  caja.innerHTML = (eventos || []).map((e) => `<small>${esc((texto[e.tipo] || (() => ""))(e))}</small>`).join("");
}

function pintarPropuestaAgente(p) {
  const caja = $("#agentes-propuesta");
  if (!caja) return;
  if (!p || !p.id || p.rechazada) {
    caja.innerHTML = p && p.que ? aviso("info", esc(p.que)) : "";
    return;
  }
  ag.propuesta = p;
  const rutas = (p.rutas || []).map((r) => `<li>${esc(r.donde || "")} ${esc(r.carpeta || "")} / ${esc(r.ruta || "")}</li>`).join("");
  const contenido = p.contenido != null ? `<pre class="vista-previa">${esc(p.contenido)}</pre>` : "";
  const sobre = p.sobrescribe || ag.sobrescribir
    ? `<p>${esc(p.aviso || "Ya hay algo con ese nombre. Si confirmas otra vez, lo de ahora va a la papelera de reciclaje.")}</p>` : "";
  caja.innerHTML = `<div class="tarjeta propuesta-accion"><b>${esc(p.que || "Tienes una acción para revisar.")}</b>`
    + `<ul>${rutas}</ul>${contenido}${sobre}`
    + '<div class="acciones"><button class="primario" type="button" id="ag-si">Confirmar</button>'
    + '<button class="fantasma" type="button" id="ag-no">Cancelar</button></div></div>';
  $("#ag-si").onclick = () => resolverPropuestaAgente(true);
  $("#ag-no").onclick = () => resolverPropuestaAgente(false);
}

async function lanzarAgente(ev) {
  ev.preventDefault();
  if (ag.ocupado) return;
  const ident = $("#ag-elegido").value;
  const tarea = $("#ag-tarea").value.trim();
  if (!ident || !tarea) {
    $("#agentes-aviso").innerHTML = aviso("err", esc("Elige un agente y escribe la tarea."));
    return;
  }
  ag.ocupado = true;
  ag.sobrescribir = false;
  ag.eventos = [];
  $("#agentes-propuesta").innerHTML = "";
  $("#agentes-eventos").innerHTML = aviso("info", "Trabajando…");
  const r = await api().agentes_lanzar(ident, tarea);
  ag.ocupado = false;
  if (!r || r.ok === false) {
    $("#agentes-eventos").innerHTML = "";
    $("#agentes-aviso").innerHTML = aviso("err", esc((r && r.error) || "No he podido lanzarlo."));
    return;
  }
  aplicarResultadoAgente(r);
}

function aplicarResultadoAgente(r) {
  ag.carrera = r.carrera || ag.carrera;
  $("#agentes-aviso").innerHTML = "";
  ag.eventos = (ag.eventos || []).concat(r.eventos || []);
  pintarEventosAgente(ag.eventos);
  if (r.necesita_sobrescribir) {
    ag.sobrescribir = true;
    pintarPropuestaAgente({ ...(ag.propuesta || {}), id: (r.propuesta && r.propuesta.id) || (ag.propuesta && ag.propuesta.id), sobrescribe: true, aviso: r.texto });
    return;
  }
  if (r.estado === "esperando" && r.propuesta) {
    pintarPropuestaAgente(r.propuesta);
    return;
  }
  ag.propuesta = null;
  ag.sobrescribir = false;
  const finales = (ag.eventos || []).filter((e) => e.tipo === "final");
  const ultimo = finales[finales.length - 1];
  const mal = ultimo && (ultimo.motivo === "error" || ultimo.motivo === "rechazo");
  $("#agentes-propuesta").innerHTML = r.texto ? aviso(mal ? "err" : "ok", esc(r.texto)) : "";
}

async function resolverPropuestaAgente(aceptar) {
  if (!ag.carrera || !ag.propuesta || ag.ocupado) return;
  ag.ocupado = true;
  const r = aceptar
    ? await api().agentes_confirmar(ag.carrera, ag.propuesta.id, ag.sobrescribir)
    : await api().agentes_cancelar(ag.carrera, ag.propuesta.id);
  ag.ocupado = false;
  if (!r || r.ok === false) {
    $("#agentes-aviso").innerHTML = aviso("err", esc((r && r.error) || "No he podido hacerlo."));
    return;
  }
  if (!r.necesita_sobrescribir) ag.propuesta = null;
  aplicarResultadoAgente(r);
}

(function () {
  const previa = window.mostrarVista;
  if (typeof previa === "function") {
    window.mostrarVista = function (nombre) {
      previa(nombre);
      if (nombre === "agentes") pintarAgentes();
    };
  }
  window.addEventListener("pywebviewready", () => {
    const form = $("#agentes-form");
    const lanzar = $("#agentes-lanzar");
    const limpiar = $("#ag-limpiar");
    if (form) form.onsubmit = guardarAgente;
    if (lanzar) lanzar.onsubmit = lanzarAgente;
    if (limpiar) limpiar.onclick = limpiarFormularioAgente;
  });
})();
