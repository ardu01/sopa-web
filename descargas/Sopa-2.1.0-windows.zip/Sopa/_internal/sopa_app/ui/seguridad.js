// La puerta de seguridad: la tarjeta «Sopa pregunta» en la Sala y Ajustes · Seguridad.
// Nada sale del equipo; la vista previa llega sin claves ni tokens.
const NIVEL_TEXTO = { libre: "Libre", anotada: "Anotada", preguntar: "Preguntar", bloqueada: "Bloqueada" };
let puertaPreguntas = [];
let puertaReloj = null;

async function refrescarPuerta(nueva) {
  let r;
  try { r = await api().seguridad_preguntas(); } catch (e) { return; }
  puertaPreguntas = (r && r.preguntas) || [];
  pintarPuerta();
  const sala = $("#vista-chat");
  if (nueva && puertaPreguntas.length && sala && !sala.classList.contains("visible")) {
    toast("Sopa te pregunta algo en la Sala.");
  }
}

function pintarPuerta() {
  const caja = $("#puerta-preguntas");
  if (!caja) return;
  if (!puertaPreguntas.length) {
    caja.innerHTML = "";
    clearInterval(puertaReloj); puertaReloj = null;
    return;
  }
  caja.innerHTML = puertaPreguntas.map((p) => `<div class="tarjeta puerta-pregunta" data-id="${esc(p.id)}">
    <b>Sopa pregunta: ¿${esc(p.etiqueta)}?</b>
    ${p.vista ? `<pre class="vista-previa">${esc(p.vista)}</pre>` : ""}
    <small>${p.origen === "movil" ? "Lo ha pedido el móvil. " : ""}Vale solo para esta llamada.</small>
    <div class="acciones"><button class="primario" type="button" data-puerta="si">Sí</button><button class="fantasma" type="button" data-puerta="no">No</button>
    <span class="puerta-cuenta" aria-live="off">Quedan ${Number(p.quedan) || 0} s. Sin respuesta es un no.</span></div></div>`).join("");
  caja.querySelectorAll("[data-puerta]").forEach((b) => {
    b.onclick = () => responderPuerta(b.closest(".puerta-pregunta").dataset.id, b.dataset.puerta === "si");
  });
  if (!puertaReloj) puertaReloj = setInterval(() => {
    puertaPreguntas.forEach((p) => { p.quedan = Math.max(0, (Number(p.quedan) || 0) - 1); });
    caja.querySelectorAll(".puerta-pregunta").forEach((t) => {
      const p = puertaPreguntas.find((x) => x.id === t.dataset.id);
      const c = t.querySelector(".puerta-cuenta");
      if (p && c) c.textContent = `Quedan ${p.quedan} s. Sin respuesta es un no.`;
    });
  }, 1000);
}

async function responderPuerta(id, si) {
  const tarjeta = document.querySelector(`.puerta-pregunta[data-id="${CSS.escape(id)}"]`);
  if (tarjeta) tarjeta.querySelectorAll("button").forEach((b) => { b.disabled = true; });
  const r = await api().responder_seguridad(id, si === true);
  if (!r.ok) toast(r.error || "Esa pregunta ya no está abierta.");
  refrescarPuerta(false);
}

function filaSeguridad(h, config) {
  const propio = (config.niveles || {})[h.herramienta] || "";
  const opciones = (h.con_vista ? ["preguntar", "bloqueada"] : ["libre", "anotada", "preguntar", "bloqueada"])
    .map((n) => `<option value="${n}"${propio === n ? " selected" : ""}>${NIVEL_TEXTO[n]}</option>`).join("");
  const nota = h.con_vista ? " · con vista previa" : "";
  const vigente = h.nivel === h.movil ? NIVEL_TEXTO[h.nivel] : `${NIVEL_TEXTO[h.nivel]} (móvil: ${NIVEL_TEXTO[h.movil]})`;
  return `<tr><td>${esc(h.etiqueta)}<small class="seg-nota">${esc(h.herramienta)}${nota}</small></td>
    <td><select data-seg-herramienta="${esc(h.herramienta)}" aria-label="Nivel de ${esc(h.etiqueta)}">
      <option value=""${propio ? "" : " selected"}>De fábrica (${NIVEL_TEXTO[h.fabrica]})</option>${opciones}</select></td>
    <td class="seg-vigente">${esc(vigente)}</td></tr>`;
}

async function pintarSeguridad(extra = "") {
  const caja = $("#seg-contenido");
  if (!caja) return;
  let r;
  try { r = await api().seguridad_estado(); } catch (e) { r = { ok: false }; }
  if (!r.ok) { caja.innerHTML = aviso("err", "No he podido leer la seguridad."); return; }
  const config = r.config || {};
  const porGrupo = (r.grupos || []).map((g) => {
    const filas = (r.herramientas || []).filter((h) => h.grupo === g.id).map((h) => filaSeguridad(h, config)).join("");
    return `<tr class="seg-grupo"><th colspan="3">${esc(g.etiqueta)} · de fábrica ${esc(NIVEL_TEXTO[g.fabrica])}</th></tr>${filas}`;
  }).join("");
  const registro = (r.registro || []).slice().reverse().map((e) => `<li><b>${esc(e.resultado)}</b> · ${esc(e.herramienta)} · ${esc((e.cuando || "").replace("T", " "))}${e.origen === "movil" ? " · móvil" : ""}<br><span class="vista-previa">${esc(e.vista)}</span></li>`).join("");
  caja.innerHTML = `${extra}
    <table class="seg-tabla"><thead><tr><th>Herramienta</th><th>Nivel</th><th>Ahora</th></tr></thead><tbody>${porGrupo}</tbody></table>
    <div class="seg-reglas">
      <label>Plazo para responder (segundos) <input id="seg-plazo" type="number" min="10" max="600" value="${Number(config.plazo_segundos) || 60}"></label>
      <label>Denegar siempre (una por línea, p. ej. <code>movil/borrar</code>)<textarea id="seg-denegar" rows="3">${esc((config.denegar || []).join("\n"))}</textarea></label>
      <label>Permitir sin preguntar (una por línea)<textarea id="seg-permitir" rows="3">${esc((config.permitir || []).join("\n"))}</textarea></label>
    </div>
    <div class="acciones"><button id="seg-guardar" class="primario" type="button">Guardar</button><button id="seg-borrar" class="fantasma" type="button">Borrar el registro</button></div>
    <h3>Registro de seguridad</h3>
    ${registro ? `<ul class="seg-registro">${registro}</ul>` : "<p class=\"sub\">Aún no hay nada anotado.</p>"}`;
  $("#seg-guardar").onclick = guardarSeguridad;
  $("#seg-borrar").onclick = async () => { await api().borrar_registro_seguridad(); pintarSeguridad(aviso("ok", "Registro borrado.")); };
}

function lineasSeguridad(sel) {
  return String($(sel).value || "").split(/[\n,]+/).map((t) => t.trim()).filter(Boolean);
}

async function guardarSeguridad() {
  const niveles = {};
  document.querySelectorAll("[data-seg-herramienta]").forEach((s) => { if (s.value) niveles[s.dataset.segHerramienta] = s.value; });
  const config = {
    plazo_segundos: Number($("#seg-plazo").value) || 60,
    niveles,
    denegar: lineasSeguridad("#seg-denegar"),
    permitir: lineasSeguridad("#seg-permitir"),
  };
  const r = await api().guardar_seguridad(config);
  pintarSeguridad(r.ok ? aviso("ok", "Guardado. Se aplica a la próxima llamada.") : aviso("err", esc(r.error || "No he podido guardarlo.")));
}

window.addEventListener("pywebviewready", () => refrescarPuerta(false));
