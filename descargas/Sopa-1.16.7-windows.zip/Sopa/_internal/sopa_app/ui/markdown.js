"use strict";
// Pintado del chat. El HTML se escapa. Las fórmulas las dibuja KaTeX, ya incluido.
// No se toca el interior de un bloque de código.

function escapar(texto) {
  return String(texto ?? "").replace(/[&<>"]/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;",
  }[c]));
}

function pintarMate(src, display) {
  if (typeof katex === "undefined" || !katex.renderToString) return escapar(src);
  try {
    return katex.renderToString(src, { throwOnError: false, displayMode: !!display });
  } catch (e) {
    return escapar(src);
  }
}

function dolarAbre(bruto, i) {
  if (bruto[i] !== "$" || bruto[i + 1] === "$") return false;
  const sig = bruto[i + 1];
  if (!sig || sig === " " || sig === "\n" || sig === "\t") return false;
  if (i > 0 && bruto[i - 1] === "\\") return false;
  if (i > 0 && /\d/.test(bruto[i - 1])) return false;
  return true;
}

function dolarValido(src) {
  if (!src || /^\s/.test(src) || /\s$/.test(src)) return false;
  if (/^\d+(?:[.,]\d+)?$/.test(src)) return false;
  return true;
}

function abrirMate(bruto, i) {
  if (bruto.startsWith("\\[", i)) return { abre: "\\[", cierra: "\\]", display: true };
  if (bruto.startsWith("\\(", i)) return { abre: "\\(", cierra: "\\)", display: false };
  if (bruto.startsWith("$$", i)) return { abre: "$$", cierra: "$$", display: true };
  if (dolarAbre(bruto, i)) return { abre: "$", cierra: "$", display: false, dolar: true };
  return null;
}

function proteger(bruto, guardar) {
  let i = 0;
  let out = "";
  while (i < bruto.length) {
    if (bruto.startsWith("```", i)) {
      const fin = bruto.indexOf("```", i + 3);
      const cuerpo = fin < 0 ? bruto.slice(i + 3) : bruto.slice(i + 3, fin);
      const salto = cuerpo.indexOf("\n");
      const codigo = salto < 0 ? cuerpo : cuerpo.slice(salto + 1);
      out += guardar("<pre><code>" + escapar(codigo.replace(/\n$/, "")) + "</code></pre>");
      if (fin < 0) break;
      i = fin + 3;
      continue;
    }
    const mate = abrirMate(bruto, i);
    if (mate) {
      const desde = i + mate.abre.length;
      const fin = bruto.indexOf(mate.cierra, desde);
      if (fin >= 0) {
        const src = bruto.slice(desde, fin);
        if (mate.dolar && !dolarValido(src)) {
          out += bruto[i];
          i += 1;
          continue;
        }
        out += guardar(pintarMate(src, mate.display));
        i = fin + mate.cierra.length;
        continue;
      }
    }
    out += bruto[i];
    i += 1;
  }
  return out;
}

function restaurar(html, huecos) {
  return html.replace(/\uE000SOPA(\d+)\uE000/g, (_, n) => huecos[Number(n)] || "");
}

function esSep(linea) {
  return /^\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(String(linea).trim());
}

function esFila(linea) {
  const t = String(linea).trim();
  return t.includes("|") && !esSep(t);
}

function celdas(linea) {
  let t = String(linea).trim();
  if (t.startsWith("|")) t = t.slice(1);
  if (t.endsWith("|")) t = t.slice(0, -1);
  return t.split("|").map((c) => c.trim());
}

function tablas(html) {
  const lineas = String(html).split("\n");
  const salida = [];
  for (let i = 0; i < lineas.length; i++) {
    if (esFila(lineas[i]) && i + 1 < lineas.length && esSep(lineas[i + 1])) {
      const cabeza = celdas(lineas[i]);
      const cuerpo = [];
      i += 2;
      while (i < lineas.length && esFila(lineas[i])) {
        cuerpo.push(celdas(lineas[i]));
        i += 1;
      }
      i -= 1;
      const th = cabeza.map((c) => "<th>" + c + "</th>").join("");
      const trs = cuerpo.map((fila) => "<tr>" + fila.map((c) => "<td>" + c + "</td>").join("") + "</tr>").join("");
      salida.push("<table><thead><tr>" + th + "</tr></thead><tbody>" + trs + "</tbody></table>");
    } else {
      salida.push(lineas[i]);
    }
  }
  return salida.join("\n");
}

function markdownSeguro(texto) {
  const bruto = String(texto ?? "").replace(/\r\n/g, "\n");
  const huecos = [];
  const guardar = (html) => {
    const marca = "\uE000SOPA" + huecos.length + "\uE000";
    huecos.push(html);
    return marca;
  };
  let html = escapar(proteger(bruto, guardar));
  html = html.replace(/`([^`\n]+)`/g, "<code>$1</code>");
  html = html.replace(/^### (.+)$/gm, "<h3>$1</h3>");
  html = html.replace(/^## (.+)$/gm, "<h2>$1</h2>");
  html = html.replace(/^# (.+)$/gm, "<h1>$1</h1>");
  html = html.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  html = html.replace(/\*\*([^*]+)$/g, "<strong>$1</strong>");
  html = tablas(html);
  html = html.replace(/^---[ \t]*$/gm, "<hr>");
  html = listasSeguras(html);
  html = html.replace(/[ \t]{2,}(?=\n|$)/g, "");
  return restaurar(html, huecos);
}

function listasSeguras(html) {
  const salida = [];
  let modo = "";
  let puntos = [];
  const cerrar = () => {
    if (!modo) return;
    const etiqueta = modo === "ul" ? "ul" : "ol";
    salida.push("<" + etiqueta + ">" + puntos.map((t) => "<li>" + t + "</li>").join("") + "</" + etiqueta + ">");
    modo = "";
    puntos = [];
  };
  for (const linea of String(html).split("\n")) {
    const limpia = linea.replace(/[ \t]+$/, "");
    const viñeta = limpia.match(/^[ \t]{0,3}- (.+)$/);
    const numero = limpia.match(/^[ \t]{0,3}\d+\. (.+)$/);
    if (viñeta) {
      if (modo !== "ul") { cerrar(); modo = "ul"; }
      puntos.push(viñeta[1]);
    } else if (numero) {
      if (modo !== "ol") { cerrar(); modo = "ol"; }
      puntos.push(numero[1]);
    } else {
      cerrar();
      salida.push(linea);
    }
  }
  cerrar();
  return salida.join("\n");
}

function corteBloqueCerrado(texto) {
  const bruto = String(texto ?? "");
  let cerrado = 0;
  let valla = false;
  let mate = "";
  for (let i = 0; i < bruto.length; i++) {
    if (!mate && bruto.startsWith("```", i)) {
      valla = !valla;
      i += 2;
      if (!valla) {
        const fin = bruto.indexOf("\n", i + 1);
        cerrado = fin < 0 ? bruto.length : fin + 1;
        if (fin >= 0) i = fin;
      }
      continue;
    }
    if (valla) continue;
    if (!mate) {
      if (bruto.startsWith("\\[", i)) { mate = "\\]"; i += 1; continue; }
      if (bruto.startsWith("\\(", i)) { mate = "\\)"; i += 1; continue; }
      if (bruto.startsWith("$$", i)) { mate = "$$"; i += 1; continue; }
      if (dolarAbre(bruto, i)) { mate = "$"; continue; }
    } else if (bruto.startsWith(mate, i)) {
      i += mate.length - 1;
      mate = "";
      continue;
    }
    if (!mate && bruto[i] === "\n") cerrado = i + 1;
  }
  return cerrado;
}

function markdownEnCurso(texto, cache) {
  const bruto = String(texto ?? "");
  const corte = corteBloqueCerrado(bruto);
  const cola = bruto.slice(corte);
  let html;
  if (cache && cache.hasta === corte) html = cache.html;
  else {
    html = markdownSeguro(bruto.slice(0, corte));
    if (cache) { cache.hasta = corte; cache.html = html; }
  }
  return html + escapar(cola);
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { markdownSeguro, markdownEnCurso, corteBloqueCerrado };
}
