const DEMO = {
  version: "1.5.1",
  instalada: "0.10.0",
  carpeta: "%LOCALAPPDATA%\\Programs\\Sopa",
  datos: "%LOCALAPPDATA%\\Sopa",
};

let estado = null;
let accionPendiente = "instalar";
let pantallaPrevia = "instalar";

const $ = (id) => document.getElementById(id);

function reduceMotion() {
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function mostrar(id) {
  const siguiente = $("p-" + id);
  if (!siguiente) return;
  const actual = document.querySelector(".pantalla.activa");
  $("cerrar").disabled = id === "progreso";
  if (actual === siguiente) return;
  document.querySelectorAll(".pantalla").forEach((el) => {
    if (el !== actual && el !== siguiente) {
      el.hidden = true;
      el.classList.remove("activa", "entra", "sale");
    }
  });
  if (actual) {
    actual.classList.remove("entra", "activa");
    if (reduceMotion()) {
      actual.hidden = true;
      actual.classList.remove("sale");
    } else {
      actual.classList.add("sale");
      const salir = (ev) => {
        if (ev.target !== actual || ev.animationName !== "sale") return;
        actual.removeEventListener("animationend", salir);
        actual.hidden = true;
        actual.classList.remove("sale");
      };
      actual.addEventListener("animationend", salir);
    }
  }
  siguiente.hidden = false;
  siguiente.classList.remove("sale");
  siguiente.classList.add("activa");
  if (reduceMotion()) siguiente.classList.remove("entra");
  else {
    siguiente.classList.remove("entra");
    void siguiente.offsetWidth;
    siguiente.classList.add("entra");
  }
  if (document.body.dataset.captura === "1" && document.body.dataset.lista !== "1") {
    const listo = () => { document.body.dataset.lista = "1"; };
    if (reduceMotion()) listo();
    else {
      const fin = (ev) => {
        if (ev.target !== siguiente || ev.animationName !== "llega") return;
        siguiente.removeEventListener("animationend", fin);
        listo();
      };
      siguiente.addEventListener("animationend", fin);
    }
  }
}

function textoVersion(instalada, nueva) {
  if (!instalada) return "Versión " + nueva;
  if (instalada === nueva) return "Ya tienes la " + nueva + ". Se instalará otra vez encima.";
  if (instalada === "desconocida") return "Hay una Sopa en este equipo. Se instalará la " + nueva + " encima.";
  return "De la " + instalada + " a la " + nueva + ".";
}

function rellenar(e) {
  estado = e;
  $("version-nueva").textContent = "Versión " + e.version;
  $("datos-instalar").textContent = "Tus modelos, documentos y licencia se quedan en " + e.datos + ".";
  $("datos-actualizar").textContent = "Tus modelos, documentos y licencia se quedan en " + e.datos + ".";
  $("ruta-actual").textContent = e.carpeta;
  $("texto-version").textContent = textoVersion(e.versionInstalada, e.version);
  $("carpeta").value = e.carpeta;
  $("txt-conservar").textContent = "Siguen en " + e.datos + ".";
  if (e.tema) document.documentElement.dataset.tema = e.tema;
}

function aplicarDemo(q) {
  rellenar({
    version: DEMO.version,
    versionInstalada: q.get("pantalla") === "actualizar" ? DEMO.instalada : null,
    carpeta: DEMO.carpeta,
    datos: DEMO.datos,
    tema: q.get("tema") || "claro",
  });
  if (q.get("carpeta") === "1") {
    $("elegir-carpeta").checked = true;
    $("bloque-carpeta").hidden = false;
  }
  const pantalla = q.get("pantalla") || "instalar";
  if (pantalla === "progreso") progreso(Number(q.get("pct") || 64), q.get("texto") || "Copiando archivos");
  else if (pantalla === "licencia") cargarLicencia();
  else mostrar(pantalla);
  if (pantalla === "desinstalar" && q.get("borrar") === "1") {
    document.querySelector('input[value="borrar"]').checked = true;
    estiloDesinstalar();
  }
}

function api() { return window.pywebview && window.pywebview.api; }

async function cargarLicencia() {
  pantallaPrevia = document.querySelector(".pantalla:not([hidden])")?.id?.slice(2) || "instalar";
  mostrar("licencia");
  if ($("texto-licencia").textContent) return;
  try {
    if (api()) $("texto-licencia").textContent = await api().licencia();
    else $("texto-licencia").textContent = await (await fetch("licencia.txt")).text();
  } catch (e) {
    $("texto-licencia").textContent = "No se pudo leer la licencia.";
  }
}

function progreso(porcentaje, texto) {
  mostrar("progreso");
  const n = Math.max(0, Math.min(100, Math.round(porcentaje)));
  $("barra").style.width = n + "%";
  $("barra-caja").setAttribute("aria-valuenow", String(n));
  $("porcentaje").textContent = n + " %";
  $("estado-texto").textContent = texto || "";
  $("titulo-progreso").textContent = accionPendiente === "desinstalar" ? "Desinstalando" : (estado && estado.versionInstalada ? "Actualizando" : "Instalando");
}

function fallo(mensaje) {
  $("texto-error").textContent = mensaje || "No se pudo completar.";
  mostrar("error");
}

function estiloDesinstalar() {
  const borrar = document.querySelector('input[name="datos"]:checked').value === "borrar";
  const boton = $("btn-desinstalar");
  boton.textContent = borrar ? "Desinstalar y borrar mis datos" : "Desinstalar";
  boton.classList.toggle("peligro-solido", borrar);
  boton.classList.toggle("primario", !borrar);
}

async function instalar() {
  if (!api()) return;
  const personalizada = $("elegir-carpeta").checked ? $("carpeta").value : null;
  accionPendiente = "instalar";
  $("texto-listo").textContent = "Sopa está en el escritorio y en el menú Inicio.";
  $("btn-abrir").hidden = false;
  const r = await api().instalar(personalizada);
  if (r && r.estado === "abierta") mostrar("abierta");
  else if (r && r.estado === "error") fallo(r.mensaje);
}

async function continuarTrasCerrar() {
  if (!api()) return;
  const r = await api().cerrar_sopa();
  if (r && r.estado === "error") { fallo(r.mensaje); return; }
  if (accionPendiente === "desinstalar") await desinstalar();
  else await instalar();
}

async function desinstalar() {
  if (!api()) return;
  accionPendiente = "desinstalar";
  const borrar = document.querySelector('input[name="datos"]:checked').value === "borrar";
  const r = await api().desinstalar(borrar);
  if (r && r.estado === "abierta") mostrar("abierta");
  else if (r && r.estado === "error") fallo(r.mensaje);
  else if (r && r.estado === "listo") {
    $("texto-listo").textContent = borrar
      ? "Se quitó Sopa y se borraron tus datos."
      : "Se quitó Sopa. Tus datos siguen en este equipo.";
    $("btn-abrir").hidden = true;
    mostrar("listo");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  const q = new URLSearchParams(location.search);
  if (q.get("tema")) document.documentElement.dataset.tema = q.get("tema");
  $("elegir-carpeta").addEventListener("change", () => { $("bloque-carpeta").hidden = !$("elegir-carpeta").checked; });
  document.querySelectorAll('input[name="datos"]').forEach((el) => el.addEventListener("change", estiloDesinstalar));
  $("ver-licencia").addEventListener("click", cargarLicencia);
  $("btn-volver").addEventListener("click", () => mostrar(pantallaPrevia));
  $("btn-reintentar").addEventListener("click", () => mostrar(estado && estado.versionInstalada ? "actualizar" : (accionPendiente === "desinstalar" ? "desinstalar" : "instalar")));
  $("cerrar").addEventListener("click", () => api() ? api().cerrar() : window.close());
  $("btn-cancelar").addEventListener("click", () => api() ? api().cerrar() : mostrar("instalar"));
  $("btn-cerrar-listo").addEventListener("click", () => api() ? api().cerrar() : window.close());
  $("btn-instalar").addEventListener("click", instalar);
  $("btn-actualizar").addEventListener("click", instalar);
  $("btn-abrir").addEventListener("click", () => api() && api().abrir());
  $("btn-desinstalar").addEventListener("click", desinstalar);
  $("btn-cerrar-sopa").addEventListener("click", continuarTrasCerrar);
  $("examinar").addEventListener("click", async () => {
    if (!api()) return;
    const r = await api().elegir_carpeta();
    if (r && r.ruta) $("carpeta").value = r.ruta;
    else if (r && r.estado === "error") fallo(r.mensaje);
  });
  if (q.get("pantalla") || q.get("modo") === "desinstalar") document.body.dataset.captura = "1";
  if (q.get("pantalla")) aplicarDemo(q);
  else if (q.get("modo") === "desinstalar") mostrar("desinstalar");
  else if (api()) arrancarDesdeApi();
});

let arrancado = false;
async function arrancarDesdeApi() {
  if (arrancado || !api()) return;
  arrancado = true;
  const e = await api().estado();
  rellenar(e);
  const modo = e.modo === "desinstalar" || e.modo === "actualizar" ? e.modo : (e.versionInstalada ? "actualizar" : "instalar");
  accionPendiente = modo === "desinstalar" ? "desinstalar" : "instalar";
  if (modo === "desinstalar") mostrar(e.abierta ? "abierta" : "desinstalar");
  else if (e.abierta) mostrar("abierta");
  else mostrar(modo);
}

window.addEventListener("pywebviewready", arrancarDesdeApi);
