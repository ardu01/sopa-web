// Interfaz de Sopa. Toda la lógica pesada vive en Python (window.pywebview.api).
"use strict";
window.__errores = [];
window.addEventListener("error", (e) => window.__errores.push(String(e.message)));
window.addEventListener("unhandledrejection", (e) => window.__errores.push(String(e.reason)));
const $ = (s) => document.querySelector(s);
const api = () => window.pywebview.api;
const esc = (t) => String(t ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const TEXTO_CHAT = { gpu: "En la gráfica", mixto: "Gráfica + memoria", cpu: "En el procesador (lento)", no: "No cabe" };
const TEXTO_ESP = { chat: "Charlar", razonamiento: "Razonar", codigo: "Programar", documentos: "Documentos", rapido: "Rápido", vision: "Imágenes" };
const TEXTO_PERS = { si: "Sí", justo: "Justo", no: "No" };
const TEXTO_VERIF = { verificado: "Verificado", estimado: "Estimado", no_soportado: "No soportado" };
const TEXTO_FUNC = { verificado: "Verificado en equipo real", ci: "Probado en pruebas automáticas", pendiente: "Pendiente de probar" };
const ICONO = { ok: "ok", warn: "aviso", err: "error", info: "info" };
const svg = (n) => `<svg class="i"><use href="#i-${n}"/></svg>`;
const aviso = (tipo, texto, accion = "", icono = ICONO[tipo]) => `<div class="aviso ${tipo}">${svg(icono)}<div>${texto}</div>${accion ? `<span class="accion">${accion}</span>` : ""}</div>`;
const vacio = (icono, titulo, texto, extra = "") => `<div class="vacio">${svg(icono)}<h3>${esc(titulo)}</h3><p>${esc(texto)}</p>${extra}</div>`;
function toast(texto) {
  const t = $("#toast"); t.innerHTML = svg("ok") + `<span>${esc(texto)}</span>`; t.classList.remove("oculto");
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.add("oculto"), 5000);
}
function fallo(caja, texto) { $(caja).innerHTML = aviso("err", esc(texto)); }
let estado = { docs: [],  info: null, cursor: 0, mensajes: [], conversacion: null, versionConv: 0, ocupadoMovil: false, datos: null };

window.sopaEvento = function (ev) {
  if (!ev || !ev.tipo) return;
  if (ev.tipo === "modelo_cargando") marcarMotor("Sopa está cargando el modelo, un momento…");
  if (ev.tipo === "chat_ocupado" && ev.origen === "movil") marcarMotor("Escribiendo desde el móvil…");
  if (ev.tipo === "chat_libre") marcarMotor("");
  if (ev.tipo === "modelo_cambiado" && ev.modelo) {
    estado.modeloChat = ev.modelo;
    const sel = $("#chat-modelo");
    if (sel) for (const o of sel.options) {
      if (o.value.endsWith("/" + ev.modelo + ".gguf") || o.value.endsWith("\\" + ev.modelo + ".gguf") || o.textContent.startsWith(ev.modelo)) sel.value = o.value;
    }
  }
  if ((ev.tipo === "conv_creada" || ev.tipo === "conv_borrada" || ev.tipo === "conv_mensaje" || ev.tipo === "conv_fin") && $("#vista-chat") && $("#vista-chat").classList.contains("visible")) {
    if (ev.tipo !== "conv_mensaje" || ev.origen === "movil") cargarModelosChat();
  }
  if (ev.id && ev.id === estado.conversacion && ev.origen === "movil") {
    if (ev.tipo === "conv_trozo" && ev.texto != null) {
      const ultimo = estado.mensajes[estado.mensajes.length - 1];
      if (!ultimo || ultimo.role !== "assistant") estado.mensajes.push({ role: "assistant", content: "", origen: "movil" });
      estado.mensajes[estado.mensajes.length - 1].content = ev.texto;
      if (ev.version) estado.versionConv = ev.version;
      pintarMensajes(true);
    } else if (ev.version && ev.version > (estado.versionConv || 0)) {
      recargarConversacion(ev.id);
    }
  }
};

function marcarMotor(texto) {
  estado.ocupadoMovil = !!texto;
  const campo = $("#chat-texto");
  const enviar = $("#chat-enviar");
  if (campo) campo.disabled = !!texto;
  if (enviar) enviar.disabled = !!texto;
  const caja = $("#aviso-chat");
  if (!caja) return;
  if (texto) caja.innerHTML = aviso("info", texto);
  else if (caja.textContent.includes("Escribiendo desde el móvil") || caja.textContent.includes("cargando el modelo")) caja.innerHTML = "";
}

async function recargarConversacion(id) {
  const r = await api().conversacion(id);
  if (!r || !r.ok || r.id !== estado.conversacion) return;
  estado.versionConv = r.version || estado.versionConv;
  estado.mensajes = r.mensajes || [];
  estado.docs = r.documentos || [];
  if (typeof pintarDocs === "function") pintarDocs();
  pintarMensajes(estado.ocupadoMovil);
}

function mostrarVista(nombre) {
  document.querySelectorAll(".vista").forEach((v) => v.classList.toggle("visible", v.id === "vista-" + nombre));
  document.querySelectorAll("nav button").forEach((b) => b.classList.toggle("activa", b.dataset.vista === nombre));
  if (nombre === "modelos") { cargarCatalogo(); cargarLocales(); }
  if (nombre === "chat") cargarModelosChat();
  if (nombre === "documentos") cargarDocumentos();
  if (nombre === "personalizar") cargarModelosPersonalizar();
  if (nombre === "memoria") cargarMemoria();
  if (nombre === "ajustes") { api().licencia().then(pintarLicencia); pintarCodigoProbador(); pintarMovil(); pintarActualizaciones(); pintarCarpetas(); }
}

function aplicarTema(tema) {
  document.documentElement.dataset.tema = tema;
  $("#tema").value = tema;
}

function tarjeta(titulo, valor, detalle) {
  return `<div class="tarjeta"><small>${esc(titulo)}</small><b>${esc(valor)}</b><small>${esc(detalle || "")}</small></div>`;
}

async function cargarInicio() {
  const r = await api().info();
  estado.info = r;
  $("#version").textContent = `Versión ${r.version}${r.beta ? " beta" : ""} · ${r.licencia ? r.licencia.nombre : "Básico"}`;
  aplicarTema(r.ajustes.tema || "sistema");
  const h = r.hardware;
  const gpu = h.gpus[0];
  $("#hardware").innerHTML =
    tarjeta("Procesador", `${h.nucleos} núcleos`, h.cpu) +
    tarjeta("Memoria RAM", `${h.ram_total_gb.toFixed(1)} GB`, `${h.ram_libre_gb.toFixed(1)} GB libres`) +
    tarjeta("Tarjeta gráfica", gpu ? gpu.nombre : "Sin GPU NVIDIA", gpu ? `Driver ${gpu.driver} · capacidad ${gpu.capacidad}` : "Se usará el procesador") +
    tarjeta("Memoria de vídeo", gpu ? `${gpu.vram_total_gb.toFixed(1)} GB` : "—", gpu ? `${gpu.vram_libre_gb.toFixed(1)} GB libres` : "") +
    tarjeta("CUDA", h.cuda || "No disponible", h.cuda ? "Lista para entrenar" : "Necesaria para entrenar rápido") +
    tarjeta("Disco libre", `${h.disco_libre_gb.toFixed(0)} GB`, r.datos);
  $("#avisos-inicio").innerHTML =
    (r.aviso_driver ? aviso("warn", esc(r.aviso_driver.split(" Actualízalo")[0]), `<a href="${esc(r.url_driver)}" target="_blank">Actualizar el driver</a>`) : "") +
    (!gpu ? aviso("info", "No hay una gráfica NVIDIA compatible. Puedes chatear con modelos pequeños usando el procesador; entrenar será lento.") : "");
  $("#motor-estado").innerHTML = r.motor_listo
    ? aviso("ok", "El motor de entrenamiento está instalado.")
    : aviso("info", "Para entrenar modelos con tus ejemplos hace falta instalar el motor (unos 3 GB, una sola vez).", `<button id="instalar" class="primario">Instalar motor</button>`);
  const f = await api().funciones();
  $("#funciones-nota").textContent = f.nota;
  $("#funciones").innerHTML = f.funciones.map((x) => `<tr><td>${esc(x.nombre)}</td><td><span class="chip ${x.estado}">${TEXTO_FUNC[x.estado]}</span>${x.fecha ? `<small>${esc(x.fecha)}</small>` : ""}</td></tr>`).join("");
  const b = $("#instalar");
  if (b) b.onclick = async () => { const x = await api().instalar_motor(); if (!x.ok) fallo("#motor-estado", x.error); else mostrarVista("registro"); };
}

async function cargarCatalogo() {
  const r = await api().catalogo($("#solo-compatibles").checked);
  $("#aviso-red").innerHTML = navigator.onLine ? "" : aviso("warn", "Sin conexión. Puedes usar los modelos que ya tienes; las descargas se reanudarán cuando vuelva la red.", "", "sinred");
  if (!r.modelos.length) { $("#lista-modelos").innerHTML = `<tr><td colspan="8">${vacio("modelos", "Ningún modelo encaja aquí", "Desmarca el filtro para ver el catálogo completo.")}</td></tr>`; return; }
  $("#lista-modelos").innerHTML = r.modelos.map((m) => `
    <tr><td><span class="mono-modelo">${esc(m.nombre.slice(0, 2))}</span><b>${esc(m.nombre)}</b><small>${esc(m.descripcion)}</small></td>
      <td>${(m.especialidad || []).map((e) => `<span class="chip">${TEXTO_ESP[e] || esc(e)}</span>`).join(" ")}${m.vision ? `<small>Imágenes: próximamente</small>` : ""}</td>
      <td>${m.gguf_gb} GB</td>
      <td><span class="chip ${m.equipo_potente ? "no" : m.chat}">${m.equipo_potente ? "Equipo potente" : TEXTO_CHAT[m.chat]}</span><small>${esc(m.chat_texto)}</small></td>
      <td><span class="chip ${m.personalizar}">${TEXTO_PERS[m.personalizar]}</span><small>${esc(m.personalizar_texto)}</small></td>
      <td><span class="chip ${m.verificacion}">${TEXTO_VERIF[m.verificacion]}</span><small>${esc(m.verificacion_texto)}</small></td>
      <td>${chipLicencia(m)}<small><a href="${esc(m.licencia_url)}" target="_blank">${esc(m.licencia)}</a></small></td>
      <td>${m.descargado ? "✔ Descargado" : m.solo_catalogo ? '<span class="chip dev">Solo catálogo</span>' : m.chat === "no" ? "" : `<button data-descargar="${m.id}" ${navigator.onLine ? "" : "disabled"}>${svg("descarga")}${m.parcial_bytes ? "Continuar" : "Descargar"}</button><small>${(m.gguf.bytes / 1e9).toFixed(1)} GB</small>`}</td></tr>`).join("");
  estado.catalogo = Object.fromEntries(r.modelos.map((m) => [m.id, m]));
  document.querySelectorAll("[data-descargar]").forEach((b) => b.onclick = () => confirmarLicencia(b.dataset.descargar));
}

const TEXTO_LIC = { abierta: "Uso comercial", condiciones: "Con condiciones", no_comercial: "No comercial" };
const chipLicencia = (m) => `<span class="chip lic-${esc(m.licencia_tipo || "abierta")}">${TEXTO_LIC[m.licencia_tipo] || TEXTO_LIC.abierta}</span>`;

// Antes de descargar se muestra siempre la licencia del modelo; si no es abierta, hay que aceptarla.
function confirmarLicencia(id) {
  const m = (estado.catalogo || {})[id] || {};
  const caja = $("#descarga");
  caja.classList.remove("oculto");
  const tipo = m.licencia_tipo || "abierta";
  const enlace = `<a href="${esc(m.licencia_url)}" target="_blank">Leer la licencia completa</a>`;
  const titulo = tipo === "no_comercial" ? `<b>${esc(m.nombre)} es solo para uso no comercial.</b> ` : tipo === "condiciones" ? `<b>${esc(m.nombre)} tiene condiciones de uso.</b> ` : `<b>${esc(m.nombre)}</b> · `;
  caja.innerHTML = aviso(tipo === "no_comercial" ? "err" : tipo === "condiciones" ? "warn" : "info",
    `${titulo}${esc(m.licencia_nota || m.licencia)} ${enlace}`,
    `<button class="primario" id="lic-aceptar">${tipo === "abierta" ? "Descargar" : "Acepto la licencia y descargo"}</button><button class="fantasma" id="lic-cancelar">Cancelar</button>`);
  $("#lic-aceptar").onclick = () => descargar(id);
  $("#lic-cancelar").onclick = () => caja.classList.add("oculto");
  caja.scrollIntoView({ block: "nearest" });
}

async function cargarLocales() {
  const r = await api().modelos_locales();
  const caja = $("#lista-locales");
  if (!r.modelos.length) { caja.innerHTML = `<small>Aún no tienes modelos. Descarga uno del catálogo o importa uno exportado.</small>`; return; }
  caja.innerHTML = r.modelos.map((m) => `<div class="fila-modelo">
      <div><b>${esc(m.personalizado ? m.id.slice(4) : m.id)}</b> ${m.personalizado ? '<span class="chip ok">Personalizado</span>' : ""}<small>${m.tamano_gb} GB</small></div>
      <div class="acciones">${m.personalizado ? `<button class="fantasma" data-renombrar="${esc(m.id)}">Renombrar</button>` : ""}
        <button class="fantasma" data-exportar="${esc(m.id)}">Exportar…</button>
        <button class="fantasma peligro" data-borrar="${esc(m.id)}">Borrar</button></div></div>`).join("");
  const av = $("#aviso-gestion");
  document.querySelectorAll("[data-renombrar]").forEach((b) => b.onclick = async () => {
    const nuevo = prompt("Nuevo nombre:", b.dataset.renombrar.slice(4)); if (!nuevo) return;
    const x = await api().renombrar_modelo(b.dataset.renombrar, nuevo);
    av.innerHTML = x.ok ? aviso("ok", `Renombrado a «${esc(x.id.slice(4))}».`) : aviso("err", esc(x.error)); cargarLocales();
  });
  document.querySelectorAll("[data-exportar]").forEach((b) => b.onclick = async () => {
    const x = await api().exportar_modelo(b.dataset.exportar);
    if (x.cancelado) return;
    if (!x.ok) { av.innerHTML = aviso("err", esc(x.error)); return; }
    const paso = async () => {
      const e = await api().estado_exportacion();
      if (e.activo) {
        const pct = e.total ? Math.round(100 * e.hecho / e.total) : 0;
        av.innerHTML = `<div class="aviso info">${svg("info")}<div>Exportando «${esc(e.id)}»… ${pct} %${e.total ? ` (${gib(e.hecho / 2)} de ${gib(e.total / 2)})` : ""}<div class="barra"><div style="width:${pct}%"></div></div></div></div>`;
        setTimeout(paso, 500);
      } else av.innerHTML = e.error ? aviso("err", esc(e.error)) : aviso("ok", `Exportado en ${esc(e.ruta)}. Puedes llevarlo a otro equipo e importarlo.`);
    };
    paso();
  });
  document.querySelectorAll("[data-borrar]").forEach((b) => b.onclick = () => {
    av.innerHTML = aviso("warn", `¿Borrar «${esc(b.dataset.borrar)}» de este equipo? ${b.dataset.borrar.startsWith("mio-") ? "Se borra también lo necesario para seguir personalizándolo." : "Podrás volver a descargarlo."}`,
      `<button class="peligro" id="borrar-si">Borrar</button><button class="fantasma" id="borrar-no">Cancelar</button>`);
    $("#borrar-no").onclick = () => av.innerHTML = "";
    $("#borrar-si").onclick = async () => { const x = await api().borrar_modelo(b.dataset.borrar); av.innerHTML = x.ok ? aviso("ok", "Borrado.") : aviso("err", esc(x.error)); cargarLocales(); cargarCatalogo(); };
  });
}

async function importarModelo() {
  const av = $("#aviso-gestion");
  av.innerHTML = aviso("info", "Comprobando e importando…");
  let x = await api().importar_modelo();
  if (x.cancelado) { av.innerHTML = ""; return; }
  if (!x.ok && /^Ya tienes/.test(x.error || "")) {
    const nombre = prompt(`${x.error} ¿Con qué nombre lo importo?`);
    if (!nombre) { av.innerHTML = ""; return; }
    x = await api().importar_modelo_ruta(x.ruta, nombre);
  }
  if (!x.ok) { av.innerHTML = aviso("err", esc(x.error)); return; }
  const lic = x.licencia_base;
  av.innerHTML = aviso("ok", `Importado como «${esc(x.id.replace(/^mio-/, ""))}». Ya puedes usarlo en el chat.`)
    + (lic && lic.tipo === "no_comercial" ? aviso("err", `Está basado en un modelo de uso no comercial (${esc(lic.nombre)}).`) : lic && lic.tipo === "condiciones" ? aviso("warn", `Está basado en un modelo con condiciones de uso (${esc(lic.nombre)}).`) : "");
  cargarLocales();
}

async function descargar(id) {
  const r = await api().descargar_modelo(id);
  const caja = $("#descarga");
  if (!r.ok) { caja.classList.remove("oculto"); caja.innerHTML = aviso("err", esc(r.error)); return; }
  $("#punto-descarga").parentElement.classList.add("ocupado");
  caja.classList.remove("oculto");
  const t = setInterval(async () => {
    const d = await api().estado_descarga();
    const pct = d.total ? Math.round((100 * d.hecho) / d.total) : 0;
    const accion = d.fase === "verificando" ? "Comprobando que el archivo es correcto" : "Descargando";
    caja.innerHTML = `<h3>${accion} ${esc(d.id)}</h3><div class="progreso"><div style="width:${pct}%"></div></div>
      <small>${pct}% · ${(d.hecho / 1e9).toFixed(2)} de ${(d.total / 1e9).toFixed(2)} GB</small><button id="cancelar" class="fantasma">Cancelar</button>`;
    const c = $("#cancelar"); if (c) c.onclick = () => api().cancelar_descarga();
    if (!d.activa) {
      clearInterval(t);
      $("#punto-descarga").parentElement.classList.remove("ocupado");
      caja.innerHTML = d.cancelada ? aviso("warn", esc(d.error)) : d.error ? aviso("err", esc(d.error), "Pulsa «Continuar» para reintentar.")
        : aviso("ok", d.verificado ? "Descarga completa y comprobada." : "Descarga completa.", `<button class="primario" onclick="mostrarVista('chat')">Empezar a chatear</button>`);
      if (!d.error) toast("Modelo descargado y comprobado.");
      cargarCatalogo();
    }
  }, 700);
}

async function cargarModelosChat() {
  const r = await api().modelos_locales();
  const antes = $("#chat-modelo").value;  // al volver a pintar la lista no se pierde el modelo en uso
  $("#chat-modelo").innerHTML = r.modelos.length
    ? r.modelos.map((m) => `<option value="${esc(m.ruta)}">${m.personalizado ? "✨ " : ""}${esc(m.id)} (${m.tamano_gb} GB)</option>`).join("")
    : `<option value="">Aún no tienes modelos</option>`;
  if (antes && r.modelos.some((m) => m.ruta === antes)) $("#chat-modelo").value = antes;
  estado.hayModelos = r.modelos.length > 0;
  if (!estado.mensajes.length) pintarMensajes();
  pintarEleccionChat();
  const c = await api().conversaciones();
  $("#historial").innerHTML = c.conversaciones.length
    ? c.conversaciones.map((x) => `<div data-conv="${esc(x.id)}" class="${x.id === estado.conversacion ? "activa" : ""}" title="${esc(x.titulo)}${x.modelo ? " · " + esc(x.modelo) : ""}"><span>${esc(x.titulo)}</span><button class="borrar fantasma" data-md="${esc(x.id)}" title="Guardar como texto">↓</button><button class="borrar fantasma" data-borrar="${esc(x.id)}" title="Borrar">×</button></div>`).join("")
    : `<small style="padding:8px 10px">Tus conversaciones se guardan aquí, en este equipo.</small>`;
  $("#historial").insertAdjacentHTML("beforeend", `<p class="pie-historial">${c.conversaciones.length ? '<button class="fantasma" id="conv-exportar">Exportar todas…</button>' : ""}<button class="fantasma" id="conv-importar">Importar…</button></p>`);
  const avc = $("#aviso-chat");
  if ($("#conv-exportar")) $("#conv-exportar").onclick = async () => {
    const x = await api().exportar_conversaciones();
    avc.innerHTML = x.cancelado ? "" : x.ok ? aviso("ok", `${x.cantidad} conversaciones exportadas en ${esc(x.ruta)}.`) : aviso("err", esc(x.error));
  };
  $("#conv-importar").onclick = async () => {
    const x = await api().importar_conversaciones();
    if (x.cancelado) return;
    avc.innerHTML = x.ok ? aviso("ok", `${x.importadas.length} conversaciones importadas${x.omitidas ? ` (${x.omitidas} no eran válidas)` : ""}.`) : aviso("err", esc(x.error));
    cargarModelosChat();
  };
  document.querySelectorAll("[data-md]").forEach((b) => b.onclick = async (ev) => {
    ev.stopPropagation();
    const x = await api().exportar_conversacion_md(b.dataset.md);
    avc.innerHTML = x.cancelado ? "" : x.ok ? aviso("ok", `Guardada como texto en ${esc(x.ruta)}.`) : aviso("err", esc(x.error));
  });
  document.querySelectorAll("[data-conv]").forEach((d) => d.onclick = () => {
    const x = c.conversaciones.find((y) => y.id === d.dataset.conv);
    estado.conversacion = x.id; estado.versionConv = x.version || 0; estado.mensajes = x.mensajes; estado.docs = x.documentos || []; pintarDocs(); pintarMensajes();
    document.querySelectorAll("[data-conv]").forEach((e) => e.classList.toggle("activa", e === d));
  });
  document.querySelectorAll("[data-borrar]").forEach((b) => b.onclick = async (ev) => {
    ev.stopPropagation();
    if (!confirm("¿Borrar esta conversación? No se puede deshacer.")) return;
    await api().borrar_conversacion(b.dataset.borrar);
    if (estado.conversacion === b.dataset.borrar) { estado.conversacion = null; estado.mensajes = []; pintarMensajes(); }
    cargarModelosChat();
  });
}

function pintarMensajes(pensando) {
  const caja = $("#mensajes");
  caja.innerHTML = estado.mensajes.map((m) => m.role === "assistant"
    ? `<div class="msg assistant"><div>${m.razonamiento ? `<details class="razonamiento"><summary>Ver cómo lo ha pensado</summary>${esc(m.razonamiento)}</details>` : ""}${esc(m.content)}${m.herramienta && m.herramienta.que ? `<small class="meta">${esc(m.herramienta.que)}</small>` : ""}${m.fuentes && m.fuentes.length ? `<div class="fuentes">${m.fuentes.map((f, i) => `<span class="chip" title="${esc(f.texto.slice(0, 300))}">[${i + 1}] ${esc(f.nombre)}${f.pagina ? " · p. " + f.pagina : ""}</span>`).join("")}</div>` : ""}${m.citas && m.citas.invalidas && m.citas.invalidas.length ? `<small class="aviso-cita">Cita ${m.citas.invalidas.map((n) => "[" + n + "]").join(", ")}, que no está entre las fuentes: compruébalo.</small>` : ""}${m.cortada ? `<small>La respuesta se cortó por larga.</small>` : ""}${m.segundos ? `<small class="meta">${m.segundos} s</small>` : ""}</div></div>`
    : `<div class="msg ${m.role}">${esc(m.content)}</div>`).join("") +
    (pensando ? `<div class="msg assistant"><span class="escribiendo"></span></div>` : "");
  if (!estado.mensajes.length && !pensando) caja.innerHTML = estado.hayModelos === false
    ? vacio("chat", "Aún no tienes ningún modelo", "Descarga uno en Modelos; Sopa te dirá cuáles van bien en tu equipo.", `<button class="primario" onclick="mostrarVista('modelos')">Ver modelos</button>`)
    : vacio("chat", "¿De qué quieres hablar?", "Escribe y Sopa cargará el modelo adecuado. Nada sale de tu ordenador.",
      `<div class="ideas">${["Resume este texto en tres puntos", "Escribe un correo amable para pedir un cambio de turno", "Explícame qué es la inflación con un ejemplo", "Dame ideas para una cena con lo que tengo en la nevera"].map((t) => `<button class="idea">${t}</button>`).join("")}</div>`);
  caja.querySelectorAll(".idea").forEach((b) => b.onclick = () => { $("#chat-texto").value = b.textContent; $("#chat-texto").focus(); });
  caja.scrollTop = caja.scrollHeight;
}

// «Sopa usará X porque…»: el modelo se elige solo según la tarea; el desplegable permite cambiarlo.
async function pintarEleccionChat() {
  const caja = $("#chat-eleccion");
  if (estado.modeloChat) { caja.innerHTML = ""; return; }
  const tarea = $("#chat-tarea").value;
  const r = await api().elegir_modelo(estado.docs.length && tarea === "charlar" ? "documentos" : tarea);
  if (!r.ok) { caja.innerHTML = ""; return; }
  if (r.elegido && r.elegido.ruta) $("#chat-modelo").value = r.elegido.ruta;
  caja.innerHTML = textoEleccion(r, "Puedes escribir ya: se cargará al enviar. Para usar otro, elígelo arriba y pulsa «Cargar».");
}

function textoEleccion(r, extra = "") {
  const sug = r.sugerencia ? ` <small>Mejor aún para tu equipo: <b>${esc(r.sugerencia.nombre)}</b> (${r.sugerencia.gb} GB). ${esc(r.sugerencia.por_que)} <a href="#" onclick="mostrarVista('modelos');return false">Ver en Modelos</a></small>` : "";
  if (!r.elegido) return aviso(r.puede === false ? "err" : "info", esc(r.aviso || r.motivo || ""), r.sugerencia ? `<button class="primario" onclick="mostrarVista('modelos')">Ver modelos</button>` : "");
  return aviso(r.aviso ? "warn" : "info", `Sopa usará <b>${esc(r.elegido.nombre)}</b> porque ${esc(minus(r.motivo.replace(/^[^:]*:\s*/, "")))}${r.aviso ? " " + esc(r.aviso) : ""}${extra ? ` <small>${esc(extra)}</small>` : ""}${sug}`);
}
const minus = (t) => t ? t[0].toLowerCase() + t.slice(1) : "";

async function cargarChat(ruta) {
  if (!ruta) return;
  $("#chat-cargar").disabled = true; $("#chat-cargar").textContent = "Cargando…";
  const r = await api().chat_cargar(ruta);
  $("#chat-cargar").disabled = false; $("#chat-cargar").textContent = "Cargar";
  if (!r.ok) return fallo("#aviso-chat", r.error);
  const donde = r.reparto === "gpu" ? "en la gráfica" : r.reparto === "mixto"
    ? `repartido entre la gráfica y la memoria (${r.capas_gpu} de ${r.capas_total} partes en la gráfica; irá algo más lento)` : "en el procesador (irá más lento)";
  estado.modeloChat = r.modelo;
  $("#chat-eleccion").innerHTML = "";
  $("#aviso-chat").innerHTML = aviso(r.reparto === "gpu" ? "ok" : "info", `Modelo «${esc(r.modelo)}» listo ${donde}.`);
}

async function enviar(ev) {
  ev.preventDefault();
  const texto = $("#chat-texto").value.trim();
  if (!texto || estado.ocupadoMovil) return;
  $("#chat-texto").value = "";
  estado.mensajes.push({ role: "user", content: texto, origen: "escritorio" });
  pintarMensajes(true);
  $("#propuesta-accion").innerHTML = "";
  const nueva = !estado.conversacion;
  estado.conversacion = estado.conversacion || "conv-" + Date.now();
  estado.enviando = true;
  try {
    const r = await api().chat_enviar(estado.mensajes, parseFloat($("#chat-temp").value), $("#chat-razonar").checked, estado.docs.map((d) => d.id), $("#chat-tarea").value, estado.conversacion, "escritorio");
    if (!r.ok) { estado.mensajes.pop(); pintarMensajes(); return fallo("#aviso-chat", r.error); }
    if (r.modelo_auto) avisoModeloAuto(r.modelo_auto, "#aviso-chat");
    estado.mensajes.push({ role: "assistant", content: r.respuesta, razonamiento: r.razonamiento || "", fuentes: r.fuentes || [], citas: r.citas || null, cortada: r.cortada, tps: r.tokens_por_segundo, segundos: r.segundos, origen: "escritorio", herramienta: r.uso_herramienta || null });
    pintarMensajes();
    if (r.propuesta_memoria) proponerMemoria(r.propuesta_memoria);
    if (r.propuesta_accion) pintarPropuesta(r.propuesta_accion);
    else $("#propuesta-accion").innerHTML = "";
    const guardada = await api().guardar_conversacion(estado.conversacion, { titulo: estado.mensajes[0].content.slice(0, 60), modelo: estado.modeloChat || "", documentos: estado.docs, actualizada: new Date().toISOString(), origen: "escritorio", mensajes: estado.mensajes });
    if (guardada && guardada.version) estado.versionConv = guardada.version;
    if (nueva) cargarModelosChat();
  } finally {
    estado.enviando = false;
  }
}

function avisoModeloAuto(m, caja) {
  estado.modeloChat = m.id;
  if (m.ruta) $("#chat-modelo").value = m.ruta;
  $("#chat-eleccion").innerHTML = "";
  $(caja).innerHTML = aviso("ok", `Sopa ha cargado <b>${esc(m.nombre)}</b> porque ${esc(minus(m.motivo.replace(/^[^:]*:\s*/, "")))}`);
}

function pintarPropuesta(p) {
  const caja = $("#propuesta-accion");
  if (!p) { caja.innerHTML = ""; return; }
  if (p.rechazada || !p.id) {
    caja.innerHTML = aviso("warn", esc(p.que || "No he hecho nada."));
    return;
  }
  const rutas = (p.rutas || []).map((r) => `<li>${esc(r.donde || "En")} <b>${esc(r.carpeta)}</b>: ${esc(r.ruta)}</li>`).join("");
  const contenido = p.contenido != null ? `<pre class="vista-previa">${esc(p.contenido)}</pre>` : "";
  const sobre = p.aviso ? aviso("warn", esc(p.aviso)) : "";
  caja.innerHTML = `<div class="tarjeta propuesta-accion"><b>${esc(p.que)}</b><ul>${rutas}</ul>${contenido}${sobre}<div class="acciones"><button class="primario" id="prop-si" type="button">Confirmar</button><button class="fantasma" id="prop-no" type="button">Cancelar</button></div></div>`;
  $("#prop-no").onclick = () => cancelarPropuesta(p.id);
  $("#prop-si").onclick = () => confirmarPropuesta(p.id, false);
}

async function cancelarPropuesta(id) {
  const r = await api().acciones_cancelar(id);
  $("#propuesta-accion").innerHTML = aviso("info", esc(r.ok ? "Cancelado. No he cambiado nada." : (r.error || "No he cambiado nada.")));
  if ($("#vista-ajustes").classList.contains("visible")) pintarCarpetas();
}

function resultadoPropuesta(r) {
  const caja = $("#propuesta-accion");
  if (!r || r.ok === false) {
    caja.innerHTML = aviso("err", esc((r && r.error) || "No he podido hacerlo."));
    return;
  }
  const des = r.puede_deshacer ? `<button class="fantasma" id="prop-deshacer" type="button">Deshacer</button>` : "";
  caja.innerHTML = aviso("ok", esc(r.texto || "Hecho."), des);
  const b = $("#prop-deshacer");
  if (b) b.onclick = async () => {
    const x = await api().acciones_deshacer();
    caja.innerHTML = x.ok ? aviso("ok", esc(x.texto || "He deshecho la última acción.")) : aviso("err", esc(x.error));
    if ($("#vista-ajustes").classList.contains("visible")) pintarCarpetas();
  };
  if ($("#vista-ajustes").classList.contains("visible")) pintarCarpetas();
}

async function confirmarPropuesta(id, sobrescribir) {
  const boton = $("#prop-si");
  if (boton) boton.disabled = true;
  const r = await api().acciones_confirmar(id, sobrescribir);
  if (r && r.necesita_sobrescribir) {
    const acciones = $("#propuesta-accion .acciones");
    if (!acciones) return;
    acciones.innerHTML = `<span>Esto sustituye lo que ya hay. Lo de ahora irá a la papelera.</span><button class="primario" id="prop-sobre" type="button">Sí, sustituir</button><button class="fantasma" id="prop-no2" type="button">Cancelar</button>`;
    $("#prop-no2").onclick = () => cancelarPropuesta(id);
    $("#prop-sobre").onclick = async () => {
      $("#prop-sobre").disabled = true;
      resultadoPropuesta(await api().acciones_confirmar(id, true));
    };
    return;
  }
  resultadoPropuesta(r);
}

async function pintarCarpetas(mensaje) {
  const r = await api().acciones_estado();
  if (!r || r.ok === false) {
    $("#carp-aviso").innerHTML = aviso("err", esc((r && r.error) || "No he podido leer las carpetas."));
    return;
  }
  const cabe = r.permitido !== false;
  $("#carp-anadir").disabled = !cabe;
  $("#carp-deshacer").disabled = !r.puede_deshacer;
  const avisoPlan = !cabe ? aviso("warn", esc(r.aviso || "")) : "";
  const apagadas = cabe && !(r.carpetas || []).length ? aviso("info", "No hay carpetas autorizadas. Las acciones están apagadas.") : "";
  $("#carp-aviso").innerHTML = avisoPlan || mensaje || apagadas;
  const herr = [["leer", "Leer"], ["buscar", "Buscar"], ["resumir", "Resumir"], ["archivos", "Cambiar archivos"]];
  $("#carp-lista").innerHTML = (r.carpetas || []).map((c) => {
    const mapa = c.herramientas || {};
    const checks = herr.map(([id, nombre]) =>
      `<label><input type="checkbox" data-herr="${id}" data-carpeta="${esc(c.id)}" ${mapa[id] !== false ? "checked" : ""} ${cabe ? "" : "disabled"}> ${nombre}</label>`).join("");
    const desdeMovil = `<label><input type="checkbox" data-movil="${esc(c.id)}" ${c.desde_movil === true ? "checked" : ""} ${cabe ? "" : "disabled"}> Permitir desde el móvil</label>`;
    return `<div class="fila-modelo"><div><span>${esc(c.nombre)}<small>${esc(c.ruta)}</small></span><div class="herramientas-carpeta">${checks}${desdeMovil}</div></div><button class="fantasma" data-quitar-carpeta="${esc(c.id)}" type="button" ${cabe ? "" : "disabled"}>Quitar</button></div>`;
  }).join("");
  $("#carp-registro").innerHTML = (r.registro || []).length
    ? r.registro.slice().reverse().map((e) => `<div class="resultado"><b>${esc(e.fecha)}</b> ${esc(e.accion)}<p>${esc(e.resultado)}</p></div>`).join("")
    : `<small>Aún no hay acciones.</small>`;
  document.querySelectorAll("[data-quitar-carpeta]").forEach((b) => b.onclick = async () => {
    const x = await api().acciones_quitar(b.dataset.quitarCarpeta);
    pintarCarpetas(x.ok ? aviso("ok", "Carpeta quitada. Sopa ya no propondrá acciones ahí.") : aviso("err", esc(x.error)));
  });
  document.querySelectorAll("[data-herr]").forEach((b) => b.onchange = async () => {
    const x = await api().acciones_herramienta(b.dataset.carpeta, b.dataset.herr, b.checked);
    pintarCarpetas(x.ok ? "" : aviso("err", esc(x.error || "No he podido cambiar la herramienta.")));
  });
  document.querySelectorAll("[data-movil]").forEach((b) => b.onchange = async () => {
    const x = await api().acciones_desde_movil(b.dataset.movil, b.checked);
    pintarCarpetas(x.ok ? "" : aviso("err", esc(x.error || "No he podido cambiar el móvil.")));
  });
}

function proponerMemoria(texto) {
  $("#aviso-chat").innerHTML = aviso("info", `¿Guardar en la memoria? «${esc(texto)}»`,
    `<button class="primario" id="mem-si">Guardar</button><button class="fantasma" id="mem-no">No</button>`, "memoria");
  $("#mem-no").onclick = () => $("#aviso-chat").innerHTML = "";
  $("#mem-si").onclick = async () => {
    const x = await api().memoria_añadir(texto, "chat");
    $("#aviso-chat").innerHTML = x.ok ? aviso("ok", "Guardado en la memoria. Puedes verlo o borrarlo en Memoria.") : aviso("err", esc(x.error));
  };
}

async function cargarModelosPersonalizar() {
  const [r, e] = await Promise.all([api().catalogo(false), api().elegir_modelo("entrenar")]);
  const sel = $("#p-modelo");
  sel.innerHTML = r.modelos.map((m) => `<option value="${m.id}" ${m.personalizar === "no" && estado.info.hardware.gpus.length ? "disabled" : ""}>${esc(m.nombre)} — ${TEXTO_PERS[m.personalizar]}</option>`).join("");
  if (e.ok && e.elegido && !sel.dataset.tocado) sel.value = e.elegido.id;
  $("#p-eleccion").innerHTML = !e.ok ? "" : e.elegido
    ? aviso(e.aviso ? "warn" : "info", `Sopa propone <b>${esc(e.elegido.nombre)}</b>: ${esc(minus(e.motivo.replace(/^[^:]*:\s*/, "")))}${e.aviso ? " " + esc(e.aviso) : ""} <small>Puedes elegir otro en el paso 1.</small>`)
    : aviso("err", esc(e.aviso || e.motivo));
  const info = () => { const m = r.modelos.find((x) => x.id === sel.value); $("#p-modelo-info").textContent = m ? m.personalizar_texto : ""; };
  sel.onchange = () => { sel.dataset.tocado = "1"; info(); estimar(); }; info();
}

async function elegirDatos() {
  const r = await api().elegir_archivo();
  if (!r.ruta) return;
  estado.datos = r.ruta; $("#p-datos-ruta").textContent = r.ruta;
  const v = await api().vista_previa_datos(r.ruta);
  $("#p-vista").textContent = v.ok
    ? `${v.filas} ejemplos · formato «${v.plantilla}»${v.aviso ? " · ⚠ " + v.aviso : ""}\n` + v.ejemplos.map((e) => JSON.stringify(e).slice(0, 200)).join("\n")
    : "✖ " + v.error;
  estimar();
}

async function estimar() {
  const p = $("#p-estimacion");
  if (!estado.datos || !$("#p-modelo").value) return;
  const r = await api().estimar_tiempo($("#p-modelo").value, estado.datos, $("#p-intensidad").value);
  p.innerHTML = r.ok
    ? `Tardará <b>${esc(r.texto)}</b> (${r.fiabilidad === "medido" ? "medido en un equipo real" : "aproximado"}).`
      + (r.plan ? `<br><small class="plan">${svg("info")} ${esc(r.plan.texto)}</small>` : "")
      + `<details class="detalles"><summary>Ver detalles</summary><small>${r.pasos} pasos de ~${r.segundos_por_paso} s.${r.plan && r.plan.detalle ? " " + esc(r.plan.detalle) : ""}</small></details>`
    : esc(r.error);
}

async function empezar() {
  const r = await api().entrenar({ modelo: $("#p-modelo").value, datos: estado.datos, intensidad: $("#p-intensidad").value, nombre: $("#p-nombre").value });
  if (!r.ok) return fallo("#aviso-pers", r.error);
  $("#aviso-pers").innerHTML = "";
  $("#p-estado").textContent = "Empezando…";
}

function textoPuestos(l) {
  if (!l.puestos) return "";
  if (l.nivel === "pro") return l.puestos === 1 ? "licencia comercial, 1 puesto" : `licencia comercial, ${l.puestos} puestos`;
  return l.puestos === 1 ? "uso personal, 1 ordenador" : `uso personal, ${l.puestos} ordenadores`;
}

function textoOrdenadoresBasico(l) {
  if (!l || l.nivel !== "basico" || !l.puestos) return "";
  if (l.puestos === 1) return "Básico es gratis y vale para 1 ordenador.";
  return `Básico es gratis y vale para ${l.puestos} ordenadores.`;
}

function pintarLicencia(l, mensaje) {
  const beta = l.origen === "beta";
  $("#lic-nivel").textContent = l.nombre;
  $("#version").textContent = $("#version").textContent.replace(/·.*$/, "· " + l.nombre);
  $("#lic-chip").className = "chip " + (l.nivel === "basico" ? "" : "verificado");
  $("#lic-chip").textContent = l.nivel === "basico" ? "Sin licencia" : (beta ? "Incluido en la beta" : "Licencia válida");
  const puestos = textoPuestos(l);
  $("#lic-detalle").textContent = l.id
    ? `Licencia ${l.id}${l.titular ? " · " + l.titular : ""} · compra de por vida desde ${fechaCorta(l.emitida)}${puestos ? " · " + puestos : ""}`
    : (beta ? "Plus está incluido mientras dura esta beta. Cuando termine, sin una licencia Sopa vuelve a Básico." : textoOrdenadoresBasico(l));
  $("#lic-mejoras").innerHTML = l.actualizaciones_hasta
    ? `Tu licencia incluye mejoras hasta el ${esc(fechaCorta(l.actualizaciones_hasta))}. <button class="fantasma" id="lic-ampliar">Ampliar mejoras</button>` : "";
  if ($("#lic-ampliar")) $("#lic-ampliar").onclick = () => toast("Para ampliar las mejoras, pide un nuevo código a quien te dio tu licencia y pégalo aquí.");
  $("#lic-quitar").classList.toggle("oculto", !l.id);
  $("#lic-nota").textContent = beta
    ? "La licencia se comprueba en este equipo, sin conexión. Mientras dura esta beta, Plus está incluido sin activar nada."
    : "La licencia se comprueba en este equipo, sin conexión. Sin licencia, Sopa funciona como Básico.";
  $("#lic-aviso").innerHTML = mensaje || (l.aviso ? aviso("warn", esc(l.aviso)) : "");
}

let qrFuera = null;

function pintarMovil(r) {
  const panel = $("#movil-panel");
  if (!r) { api().movil_estado().then(pintarMovil); return; }
  const interruptor = $("#movil-on");
  const cabe = r.permitido !== false;
  interruptor.disabled = !cabe;
  interruptor.checked = cabe && !!r.activo;
  const f = r.fuera || {};
  const fueraOn = $("#fuera-on");
  const cabeFuera = cabe && f.permitido !== false;
  if (fueraOn) {
    fueraOn.disabled = !cabeFuera;
    fueraOn.checked = cabeFuera && !!f.activo;
  }
  if (!cabeFuera) qrFuera = null;
  if (!cabe) {
    panel.innerHTML = aviso("warn", esc(r.aviso || ""));
    const fp = $("#fuera-panel");
    if (fp) fp.innerHTML = f.aviso ? aviso("warn", esc(f.aviso)) : "";
    return;
  }
  if (!r.activo) {
    panel.innerHTML = r.error ? aviso("err", esc(r.error)) : "";
  } else {
    const dispositivos = (r.dispositivos || []).map((d) =>
      `<div class="dispositivo"><span>${esc(d.nombre)} · ${esc(d.creado)}</span><button class="fantasma" data-revocar="${esc(d.id)}" type="button">Revocar</button></div>`).join("");
    const vistos = (r.registro_icono || []).map((l) => `<li>${esc(l)}</li>`).join("");
    const queda = r.codigo_segundos > 90 ? Math.round(r.codigo_segundos / 60) + " min" : r.codigo_segundos + " s";
    panel.innerHTML = `<h4>${esc(r.titulo || "")}</h4><div class="qr">${r.qr || ""}</div>`
      + (r.url_enlace ? `<p class="respaldo">${esc(r.url_enlace)}</p>` : "")
      + (r.codigo_segundos ? `<small>Vale una sola vez · quedan ${queda}.</small>` : `<p><button id="movil-codigo" type="button">Nuevo código</button></p>`)
      + dispositivos
      + (vistos ? `<details><summary>Peticiones del icono</summary><ul>${vistos}</ul></details>` : "");
    const otro = $("#movil-codigo");
    if (otro) otro.onclick = async () => pintarMovil(await api().movil_codigo());
    panel.querySelectorAll("[data-revocar]").forEach((b) => b.onclick = async () => pintarMovil(await api().movil_revocar(b.dataset.revocar)));
  }
  pintarFuera(f);
}

function pintarFuera(f) {
  const panel = $("#fuera-panel");
  if (!panel) return;
  if (!f || f.permitido === false) {
    panel.innerHTML = f && f.aviso ? aviso("warn", esc(f.aviso)) : "";
    return;
  }
  if (!f.activo) { panel.innerHTML = ""; return; }
  const moviles = (f.moviles || []).map((d) =>
    `<div class="dispositivo"><span>${esc(d.nombre)} · ${esc(d.creado)}</span><button class="fantasma" data-revocar-tunel="${esc(d.id)}" type="button">Revocar</button></div>`).join("");
  const qr = qrFuera
    ? `<h4>Pasa este código a WireGuard</h4><div class="qr">${qrFuera.qr}</div>`
      + `<p>Se enseña una sola vez y lleva la clave de ese móvil. Si lo cierras sin pasarlo a la app, revoca el móvil y crea otro. La clave no se guarda en el ordenador.</p>`
      + `<pre class="vista-previa">${esc(qrFuera.conf)}</pre>`
      + `<p><button id="fuera-copiar" type="button">Copiar</button> <button id="fuera-listo" type="button">Ya está en el móvil</button></p>`
    : "";
  panel.innerHTML = aviso("warn", esc(f.texto_admin || ""))
    + `<p><a href="${esc(f.url_wireguard || "")}" target="_blank" rel="noopener">Descargar WireGuard para Windows</a></p>`
    + `<p><button id="fuera-guardar" type="button">Guardar archivo del túnel</button></p>`
    + `<p>${esc(f.texto_passkey || "")}</p>`
    + `<p>${esc(f.texto_red || "")}</p>`
    + `<p>${esc(f.texto_dns || "")}</p>`
    + (f.url_movil ? `<p>En el móvil, con el túnel encendido, abre <b>${esc(f.url_movil)}</b>. Es la misma dirección que en casa.</p>` : "")
    + (f.host_es_ip ? aviso("warn", "Este enlace usa una IP. La cara o la huella de fuera de casa necesitan el nombre .local. Enlaza el móvil en casa con ese nombre.") : "")
    + `<p>${esc(f.texto_puerto || "")}</p>`
    + (f.ip_casa ? `<p>La IP de este PC en casa es <b>${esc(f.ip_casa)}</b>. El puerto UDP es <b>${esc(f.puerto)}</b>.</p>` : "")
    + `<p><label>Puerto UDP <input id="fuera-puerto" type="number" min="1" max="65535" value="${Number(f.puerto) || 51820}"></label> <button id="fuera-puerto-ok" type="button">Usar este puerto</button></p>`
    + `<h4>IP pública</h4>`
    + `<p>No se consulta sola. Pulsa Comprobar para preguntarle a tu router, sin salir de casa.</p>`
    + (f.endpoint ? `<p>Los móviles nuevos apuntarán a <b>${esc(f.endpoint)}</b>.</p>` : "")
    + `<p><button id="fuera-comprobar" type="button">Comprobar</button></p>`
    + `<p>${esc(f.aviso_internet || "")}</p>`
    + `<p><button id="fuera-internet" type="button">Preguntar en internet</button></p>`
    + `<p><label>O escribe la IP <input id="fuera-ip" type="text" value="${esc(f.endpoint || "")}" autocomplete="off" spellcheck="false"></label> <button id="fuera-usar" type="button">Usar esta</button></p>`
    + `<p><button id="fuera-anadir" class="primario" type="button">Añadir un móvil</button></p>`
    + qr + moviles
    + (moviles ? `<p>${esc(f.texto_revocar || "")}</p>` : "")
    + (f.escuchando
      ? `<small>El túnel está activo en este PC: Sopa escucha en la IP del túnel.</small>`
      : `<small>Cuando actives el túnel en WireGuard, Sopa escuchará en esa IP.</small>`);
  const falloFuera = async (promesa) => {
    const resp = await promesa;
    if (!resp || resp.ok === false) toast((resp && resp.error) || "No he podido hacerlo.");
    if (resp && resp.fuera) pintarMovil(resp);
    else pintarMovil();
    return resp;
  };
  $("#fuera-guardar").onclick = async () => {
    const resp = await api().fuera_guardar_conf();
    if (resp && resp.cancelado) return;
    if (!resp || resp.ok === false) toast((resp && resp.error) || "No he podido guardar el archivo.");
    else toast("Archivo guardado. Impórtalo en WireGuard.");
  };
  $("#fuera-puerto-ok").onclick = () => falloFuera(api().fuera_puerto(Number($("#fuera-puerto").value)));
  $("#fuera-comprobar").onclick = () => falloFuera(api().fuera_comprobar());
  $("#fuera-internet").onclick = () => falloFuera(api().fuera_comprobar_internet());
  $("#fuera-usar").onclick = () => falloFuera(api().fuera_endpoint($("#fuera-ip").value));
  $("#fuera-anadir").onclick = async () => {
    const resp = await api().fuera_movil_nuevo("");
    if (!resp || resp.ok === false) { toast((resp && resp.error) || "No he podido añadir el móvil."); return; }
    qrFuera = { qr: resp.qr_tunel, conf: resp.conf_tunel, id: resp.movil_tunel };
    pintarMovil(resp);
  };
  const copiar = $("#fuera-copiar");
  if (copiar) copiar.onclick = async () => {
    try { await navigator.clipboard.writeText(qrFuera.conf); toast("Configuración copiada."); }
    catch (e) { toast("Selecciona el texto y cópialo."); }
  };
  const listo = $("#fuera-listo");
  if (listo) listo.onclick = () => { qrFuera = null; pintarMovil(); };
  panel.querySelectorAll("[data-revocar-tunel]").forEach((b) => b.onclick = async () => {
    if (qrFuera && qrFuera.id === b.dataset.revocarTunel) qrFuera = null;
    await falloFuera(api().fuera_revocar(b.dataset.revocarTunel));
  });
}

async function pintarCodigoProbador() {
  const r = await api().codigo_probador();
  if (r.ok) $("#codigo-probador").textContent = r.codigo;
}

async function comprar(plan) {
  const r = await api().comprar(plan);
  $("#lic-aviso").innerHTML = aviso(r.ok ? "info" : "err", esc(r.ok ? r.texto : r.error));
}

async function activarLicencia(promesa) {
  const r = await promesa;
  if (r.cancelado) return;
  if (!r.ok) { $("#lic-aviso").innerHTML = aviso("err", esc(r.error)); return; }
  $("#lic-codigo").value = "";
  pintarLicencia(r, aviso("ok", `Licencia ${esc(r.nombre)} activada.`));
  pintarMovil();
}

const fechaCorta = (iso) => iso ? new Date(iso + "T12:00:00").toLocaleDateString("es-ES", { day: "numeric", month: "long", year: "numeric" }) : "";
const primeraNovedad = (n) => { const t = (n || "").split("\n")[0].replace(/^[-*#]\s*/, "").replace(/\.$/, "").trim(); return t ? t[0].toLowerCase() + t.slice(1) : "mejoras"; };
const gib = (b) => (b / 1024 ** 3).toFixed(2) + " GB";  // mismas unidades que la lista de modelos
const mb = (b) => b > 1e9 ? (b / 1e9).toFixed(2) + " GB" : Math.round(b / 1e6) + " MB";
const fecha = (iso) => iso ? new Date(iso).toLocaleString("es-ES", { dateStyle: "medium", timeStyle: "short" }) : "Nunca";

function avisoDisponible(d) {
  return aviso("info", `<b>Sopa ${esc(d.version)} está disponible</b> · ${mb(d.bytes)}${d.notas ? `<div class="notas">${esc(d.notas)}</div>` : ""}`,
    `<button class="primario" data-act="ahora">Actualizar ahora</button><button class="fantasma" data-act="luego">Más tarde</button><button class="fantasma" data-act="ignorar">Ignorar esta versión</button>`, "actualizar");
}

async function pintarActualizaciones(mensaje) {
  const e = await api().actualizaciones_estado();
  $("#act-version").textContent = e.version;
  $("#act-ultima").textContent = fecha(e.ultima_busqueda);
  $("#act-auto").checked = e.auto;
  $("#act-catalogo").textContent = e.catalogo ? `${e.catalogo.modelos} modelos · ${e.catalogo.origen === "descargado" ? "actualizado" : "incluido"}` : "—";
  const p = e.progreso || {};
  let html = mensaje || "";
  if (p.activa) html = aviso("info", `${{ copia: "Guardando una copia de tus datos…", descargando: "Descargando", verificando: "Comprobando la firma y el archivo…", preparando: "Preparando la nueva versión…" }[p.fase] || "Preparando…"} ${p.total ? Math.round(100 * p.hecho / p.total) + "%" : ""}`, `<button class="fantasma" data-act="cancelar">Cancelar</button>`, "actualizar");
  else if (p.lista) html = aviso("ok", `Sopa ${esc(p.version)} está lista. Se cerrará y se abrirá la nueva versión; si algo falla, volverá sola a la actual. Tus datos no se tocan.`, `<button class="primario" data-act="reiniciar">Reiniciar y actualizar</button>`);
  else if (p.error) html = aviso(p.cancelada ? "warn" : "err", esc(p.error));
  else if (!html && e.disponible && e.disponible.version !== e.ignorada) html = avisoDisponible(e.disponible);
  $("#act-aviso").innerHTML = html;
  if (html) $("#aviso-actualizacion").innerHTML = "";  // en Ajustes, el aviso va dentro de la tarjeta
  const hist = (e.historial || []);
  $("#act-lista").innerHTML = (e.instaladas || []).slice().reverse().map((v) => `<div class="version"><b>${esc(v.version)}</b> <small style="display:inline">instalada ${fecha(v.fecha)}</small></div>`).join("")
    + hist.map((v) => `<div class="version"><b>${esc(v.version)}</b> <small style="display:inline">${esc(v.fecha || "")}</small><p>${esc(v.notas || "")}</p></div>`).join("")
    || `<small>Aún no hay historial.</small>`;
  enlazarAcciones(document);
  if (p.activa) setTimeout(() => pintarActualizaciones(), 800);
  return e;
}

async function avisoGlobal() {
  const e = await api().actualizaciones_estado();
  const u = e.ultima_instalacion;
  if (u) toast(u.estado === "completada" ? `Sopa se ha actualizado a la versión ${u.a}.` : u.detalle || "La actualización no se completó; sigues en tu versión.");
  const d = e.disponible;
  const enAjustes = $("#vista-ajustes").classList.contains("visible");
  $("#aviso-actualizacion").innerHTML = !enAjustes && d && d.version !== e.ignorada && !sessionStorage.getItem("luego") && e.instalable ? avisoDisponible(d) : "";
  enlazarAcciones($("#aviso-actualizacion"));
}

function enlazarAcciones(raiz) {
  raiz.querySelectorAll("[data-act]").forEach((b) => b.onclick = async () => {
    const a = b.dataset.act;
    const e = await api().actualizaciones_estado();
    if (a === "ahora") { $("#aviso-actualizacion").innerHTML = ""; mostrarVista("ajustes"); const r = await api().actualizar_ahora(); return pintarActualizaciones(r.ok ? "" : aviso("err", esc(r.error))); }
    if (a === "luego") { sessionStorage.setItem("luego", "1"); $("#aviso-actualizacion").innerHTML = ""; return; }
    if (a === "ignorar") { await api().ignorar_version(e.disponible.version); $("#aviso-actualizacion").innerHTML = ""; return pintarActualizaciones(aviso("info", `No volveré a avisarte de la versión ${esc(e.disponible.version)}.`)); }
    if (a === "cancelar") { await api().cancelar_actualizacion(); return; }
    if (a === "reiniciar") { await api().reiniciar_para_actualizar(); }
  });
}

function pintarDocs() {
  $("#chat-docs").innerHTML = estado.docs.length
    ? `<small>Responderá con:</small>` + estado.docs.map((d) => `<span class="chip doc">${svg("doc")}${esc(d.nombre)}<button type="button" class="fantasma" data-quitar-doc="${d.id}" title="No usar">×</button></span>`).join("")
    : "";
  document.querySelectorAll("[data-quitar-doc]").forEach((b) => b.onclick = () => { estado.docs = estado.docs.filter((d) => d.id !== b.dataset.quitarDoc); pintarDocs(); });
  if ($("#vista-chat").classList.contains("visible")) pintarEleccionChat();
}

async function adjuntar() {
  $("#chat-adjuntar").disabled = true;
  $("#aviso-chat").innerHTML = aviso("info", "Leyendo tus documentos…");
  const r = await api().elegir_documentos();
  $("#chat-adjuntar").disabled = false;
  for (const d of r.añadidos || []) if (!estado.docs.find((x) => x.id === d.id)) estado.docs.push({ id: d.id, nombre: d.nombre });
  pintarDocs();
  $("#aviso-chat").innerHTML = (r.errores || []).map((e) => aviso("warn", `${esc(e.nombre)}: ${esc(e.error)}`)).join("")
    || ((r.añadidos || []).length ? aviso("ok", `Listo: responderé usando ${r.añadidos.map((d) => esc(d.nombre)).join(", ")}. No sale nada de tu equipo.`) : "");
}

const duracion = (s) => s < 90 ? Math.round(s) + " s" : s < 5400 ? Math.round(s / 60) + " min" : (s / 3600).toFixed(1) + " h";

async function sondear() {
  const r = await api().estado(estado.cursor);
  if (r.lineas && r.lineas.length) {
    const pre = $("#registro");
    pre.textContent += r.lineas.join("\n") + "\n";
    estado.cursor = r.cursor;
  }
  if (r.nombre) {
    $("#p-barra").style.width = Math.round(100 * (r.progreso || 0)) + "%";
    const nombres = { entrenar: "Entrenando", exportar: "Preparando el modelo para el chat", instalar: "Instalando el motor" };
    const u = r.ultimo || {};
    $("#punto-tarea").parentElement.classList.toggle("ocupado", !!r.activa);
    $("#p-progreso").className = "progreso" + (r.error ? " error" : !r.activa && r.codigo !== 0 ? " pausa" : "");
    if (!r.activa && r.codigo === 0 && estado.ultimaFin !== r.nombre + r.cursor) { estado.ultimaFin = r.nombre + r.cursor; if (r.nombre === "exportar") toast("Tu modelo personalizado ya está en el chat."); }
    $("#p-estado").textContent = r.activa
      ? `${nombres[r.nombre] || r.nombre}… ${u.texto || ""}${u.segundos_restantes != null ? " · quedan " + duracion(u.segundos_restantes) : ""}`
      : r.error ? "✖ " + r.error : r.codigo === 0 ? (r.nombre === "exportar" ? "✔ ¡Listo! Tu modelo ya aparece en el chat." : "✔ Terminado.") : "Detenido.";
  }
  if (estado.conversacion && !estado.enviando) {
    try {
      const v = await api().versiones_conversaciones();
      const n = v && v.versiones ? v.versiones[estado.conversacion] : 0;
      if (n && n > (estado.versionConv || 0)) await recargarConversacion(estado.conversacion);
    } catch (e) { /* el sondeo de la tarea sigue */ }
  }
}

window.addEventListener("pywebviewready", () => {
  document.querySelectorAll("nav button").forEach((b) => b.onclick = () => mostrarVista(b.dataset.vista));
  $("#tema").onchange = (e) => { aplicarTema(e.target.value); api().guardar_ajustes({ tema: e.target.value }); };
  $("#solo-compatibles").onchange = cargarCatalogo;
  $("#chat-cargar").onclick = () => cargarChat($("#chat-modelo").value);
  // Otra tarea: se descarga el modelo actual y al enviar se carga el que elija Sopa para ella.
  $("#chat-tarea").onchange = async () => { await api().chat_detener(); estado.modeloChat = null; $("#aviso-chat").innerHTML = ""; pintarEleccionChat(); };
  $("#chat-gguf").onclick = async () => { const r = await api().elegir_gguf(); if (r.ruta) cargarChat(r.ruta); };
  $("#chat-adjuntar").onclick = adjuntar;
  $("#chat-nueva").onclick = () => { estado.mensajes = []; estado.conversacion = null; estado.docs = []; pintarDocs(); pintarMensajes(); document.querySelectorAll("[data-conv]").forEach((e) => e.classList.remove("activa")); };
  $("#chat-form").onsubmit = enviar;
  $("#chat-texto").onkeydown = (e) => { if (e.key === "Enter" && !e.shiftKey) enviar(e); };
  $("#p-datos").onclick = elegirDatos;
  $("#p-empezar").onclick = empezar;
  $("#p-intensidad").onchange = estimar;
  $("#act-buscar").onclick = async () => {
    $("#act-buscar").disabled = true;
    const r = await api().buscar_actualizaciones(true);
    $("#act-buscar").disabled = false;
    const m = { al_dia: aviso("ok", "Tienes la última versión."), sin_conexion: aviso("warn", "Sin conexión con GitHub. Sopa sigue funcionando igual; prueba más tarde.", "", "sinred"),
      invalido: aviso("err", "La información de actualización no es válida (firma incorrecta). Se ha ignorado."),
      fuera_de_plan: r.ignorada_ya ? aviso("ok", "Tienes todo lo incluido en tu licencia.") : `<div class="aviso discreto"><div>Hay una versión nueva con ${esc(primeraNovedad(r.notas))}. Tu licencia incluye mejoras hasta el ${esc(fechaCorta(r.hasta))}; Sopa sigue funcionando igual. <button class="fantasma" id="lic-ampliar2">Ampliar mejoras</button> <button class="fantasma" id="act-ignorar-plan">Ignorar</button></div></div>`,
      requiere_manual: aviso("warn", `La versión ${esc(r.version)} necesita tener antes la ${esc(r.min_version)}. Descárgala e instálala a mano.`) }[r.estado] || "";
    await pintarActualizaciones(m);
    if ($("#act-ignorar-plan")) $("#act-ignorar-plan").onclick = async () => { await api().ignorar_version(r.version); $("#act-aviso").innerHTML = ""; };
    if ($("#lic-ampliar2")) $("#lic-ampliar2").onclick = () => toast("Para ampliar las mejoras, pide un nuevo código a quien te dio tu licencia y pégalo en Licencia.");
  };
  $("#importar-modelo").onclick = importarModelo;
  enlazarDocumentos();
  enlazarMemoria();
  enlazarCarpetas();
  $("#act-auto").onchange = (ev) => api().cambiar_auto(ev.target.checked);
  $("#act-archivo").onclick = async () => { const r = await api().actualizar_desde_archivo(); if (r.cancelado) return; pintarActualizaciones(r.ok ? "" : aviso("err", esc(r.error))); };
  $("#lic-activar").onclick = () => activarLicencia(api().activar_licencia($("#lic-codigo").value));
  $("#lic-archivo").onclick = () => activarLicencia(api().elegir_licencia());
  $("#lic-quitar").onclick = async () => {
    const r = await api().quitar_licencia();
    pintarLicencia(r, aviso("info", r.origen === "beta" ? "Licencia quitada. Mientras dura la beta sigues en Plus." : "Licencia quitada. Sopa funciona como Básico, en 1 ordenador."));
    pintarMovil();
  };
  $("#comprar-plus").onclick = () => comprar("plus");
  $("#comprar-pro").onclick = () => comprar("pro");
  $("#copiar-probador").onclick = async () => {
    const codigo = $("#codigo-probador").textContent;
    try { await navigator.clipboard.writeText(codigo); toast("Código copiado."); }
    catch (e) { toast("Selecciona el código y cópialo."); }
  };
  $("#movil-on").onchange = async (ev) => {
    const queria = ev.target.checked;
    let r;
    try { r = await api().movil_activar(queria); }
    catch (e) { r = { ok: false, error: "No he podido abrir el acceso desde el móvil." }; }
    if (r && r.permitido === false) { pintarMovil(r); return; }
    if (!r || r.ok === false || (queria && !r.activo)) {
      ev.target.checked = false;
      $("#movil-panel").innerHTML = aviso("err", esc((r && r.error) || "No he podido abrir el acceso desde el móvil."));
      return;
    }
    pintarMovil(r);
  };
  $("#fuera-on").onchange = async (ev) => {
    const queria = ev.target.checked;
    if (!queria) qrFuera = null;
    let r;
    try { r = await api().fuera_activar(queria); }
    catch (e) { r = { ok: false, error: "No he podido cambiar el acceso fuera de casa." }; }
    if (!r || r.ok === false) {
      ev.target.checked = false;
      toast((r && r.error) || "No he podido cambiar el acceso fuera de casa.");
      pintarMovil();
      return;
    }
    pintarMovil(r);
  };
  $("#informar-fallo").onclick = async () => {
    const r = await api().informar_fallo();
    if (!r.ok) return;
    $("#codigo-probador").textContent = r.codigo;
    let copiado = false;
    try { await navigator.clipboard.writeText(r.codigo); copiado = true; } catch (e) { /* el código sigue a la vista */ }
    toast(r.abierto
      ? (copiado ? "Código copiado. Se abre el formulario para pegarlo." : "Se abre el formulario. Copia el código y pégalo allí.")
      : "Copia el código y abre " + r.url);
  };
  window.addEventListener("online", () => { if ($("#vista-modelos").classList.contains("visible")) cargarCatalogo(); });
  window.addEventListener("offline", () => { if ($("#vista-modelos").classList.contains("visible")) cargarCatalogo(); });
  $("#p-detener").onclick = () => api().detener();
  cargarInicio().then(() => api().arranque_ok && api().arranque_ok());
  setTimeout(avisoGlobal, 1500); setTimeout(avisoGlobal, 12000);
  setInterval(sondear, 1000);
});


// ---- Tus documentos -----------------------------------------------------------------
const docsSel = new Set();
const FASES = { pendiente: "Preparando…", buscando: "Buscando archivos…", leyendo: "Leyendo documentos", descargando_buscador: "Descargando el buscador por significado", preparando_busqueda: "Preparando la búsqueda por significado…", vectores: "Preparando la búsqueda por significado", terminado: "Listo", cancelado: "Cancelado", error: "Error" };

function markdown(texto) {
  const lineas = esc(texto).split("\n");
  let html = "", lista = false, tabla = [];
  const inline = (t) => t.replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/\[(\d+(?:\s*[,-]\s*\d+)*)\]/g, '<sup class="cita">[$1]</sup>');
  const cerrarTabla = () => {
    if (!tabla.length) return;
    const filas = tabla.filter((f) => !/^\|?\s*:?-{2,}/.test(f)).map((f) => f.replace(/^\||\|$/g, "").split("|").map((c) => inline(c.trim())));
    html += `<table class="tabla md"><thead><tr>${filas[0].map((c) => `<th>${c}</th>`).join("")}</tr></thead><tbody>${filas.slice(1).map((r) => `<tr>${r.map((c) => `<td>${c}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
    tabla = [];
  };
  for (const l of lineas) {
    if (/^\s*\|.*\|\s*$/.test(l)) { tabla.push(l.trim()); continue; }
    cerrarTabla();
    const m = l.match(/^\s*[-*•]\s+(.*)/);
    if (m) { if (!lista) { html += "<ul>"; lista = true; } html += `<li>${inline(m[1])}</li>`; continue; }
    if (lista) { html += "</ul>"; lista = false; }
    const h = l.match(/^#{1,4}\s+(.*)/);
    html += h ? `<h4>${inline(h[1])}</h4>` : l.trim() ? `<p>${inline(l)}</p>` : "";
  }
  cerrarTabla();
  if (lista) html += "</ul>";
  return html;
}

function pintarCitas(r) {
  const citas = (r.citas || []).map((c) => `<details class="cita-fuente"><summary>[${c.n}] ${esc(c.archivo)}${c.pagina ? " · página " + c.pagina : ""}</summary><blockquote>${esc(c.texto)}</blockquote></details>`).join("");
  const avisos = (r.invalidas && r.invalidas.length ? aviso("warn", `La respuesta cita ${r.invalidas.map((n) => "[" + n + "]").join(", ")}, que no existe${r.invalidas.length > 1 ? "n" : ""} entre los extractos: no te fíes de esos datos.`) : "")
    + (r.sin_citas ? aviso("warn", "La respuesta no cita extractos concretos: compruébala en los documentos.") : "")
    + (r.parcial ? aviso("info", "Documento largo: el resumen se ha hecho con extractos repartidos por todo el texto.") : "");
  const leidas = (r.fuentes || []).filter((f) => f.archivo).map((f) => esc(f.archivo) + (f.paginas && f.paginas.length ? ` (p. ${f.paginas.join(", ")})` : "")).join(" · ");
  return avisos + (citas ? `<div class="citas"><small>Fuentes (pulsa para ver el texto exacto):</small>${citas}</div>` : "")
    + (leidas ? `<small class="meta">Leído de: ${leidas}</small>` : "");
}

async function cargarDocumentos() {
  const r = await api().documentos();
  if (!r.ok) return fallo("#doc-aviso", r.error);
  const s = r.resumen;
  $("#doc-resumen").textContent = s.documentos ? `${s.documentos} documentos · ${s.paginas} páginas${s.paginas_ocr ? ` (${s.paginas_ocr} leídas con OCR)` : ""}` : "";
  $("#doc-capacidades").innerHTML = (r.significado.instalado ? "Búsqueda por significado activada. " : `La primera vez que añadas una carpeta se descargará el buscador por significado (${r.significado.mb} MB, licencia ${esc(r.significado.licencia)}). `)
    + (r.ocr ? "Los PDF escaneados se leen con el OCR de Windows." : "En este sistema no hay OCR para PDF escaneados.");
  $("#doc-carpetas").innerHTML = r.carpetas.map((c) => `<div class="fila-modelo"><div><b>${esc(c.ruta.split(/[\\/]/).pop())}</b><small>${c.documentos} documentos · ${c.paginas} páginas</small></div>
      <div class="acciones"><button class="fantasma" data-carpeta-usar="${esc(c.ruta)}">Preguntar en el chat</button><button class="fantasma" data-carpeta-revisar="${esc(c.ruta)}">Volver a revisar</button><button class="fantasma peligro" data-carpeta-quitar="${esc(c.ruta)}">Quitar</button></div></div>`).join("");
  $("#doc-lista").innerHTML = r.documentos.length ? r.documentos.map((d) => `<label class="doc-fila"><input type="checkbox" data-doc="${d.id}" ${docsSel.has(d.id) ? "checked" : ""}>
      ${svg("doc")}<span>${esc(d.nombre)}</span><small>${d.paginas ? d.paginas + " p." : ""}${d.ocr ? " · OCR" : ""}</small><button class="fantasma borrar" data-doc-quitar="${d.id}" title="Quitar de Sopa (no borra el archivo)">×</button></label>`).join("")
    : vacio("doc", "Aún no hay documentos", "Añade una carpeta (apuntes, contratos, manuales…) y Sopa la indexará en segundo plano.");
  document.querySelectorAll("[data-doc]").forEach((c) => c.onchange = () => { c.checked ? docsSel.add(c.dataset.doc) : docsSel.delete(c.dataset.doc); botonesSeleccion(); });
  document.querySelectorAll("[data-doc-quitar]").forEach((b) => b.onclick = async (ev) => { ev.preventDefault(); await api().quitar_documento(b.dataset.docQuitar); docsSel.delete(b.dataset.docQuitar); cargarDocumentos(); });
  document.querySelectorAll("[data-carpeta-quitar]").forEach((b) => b.onclick = () => {
    $("#doc-aviso").innerHTML = aviso("warn", "¿Quitar esta carpeta de Sopa? Tus archivos no se tocan; solo se borra el índice.", `<button class="peligro" id="cq-si">Quitar</button><button class="fantasma" id="cq-no">Cancelar</button>`);
    $("#cq-no").onclick = () => $("#doc-aviso").innerHTML = "";
    $("#cq-si").onclick = async () => { await api().quitar_carpeta(b.dataset.carpetaQuitar); $("#doc-aviso").innerHTML = ""; cargarDocumentos(); };
  });
  document.querySelectorAll("[data-carpeta-revisar]").forEach((b) => b.onclick = () => indexarCarpeta(b.dataset.carpetaRevisar));
  document.querySelectorAll("[data-carpeta-usar]").forEach((b) => b.onclick = () => {
    const c = r.carpetas.find((x) => x.ruta === b.dataset.carpetaUsar);
    estado.docs = [{ id: "carpeta:" + c.ruta, nombre: "Carpeta " + c.ruta.split(/[\\/]/).pop() + ` (${c.documentos})` }];
    mostrarVista("chat"); pintarDocs();
  });
  botonesSeleccion();
  if (r.indexando) sondearIndexado();
}

function botonesSeleccion() {
  const n = docsSel.size;
  $("#doc-resumir").disabled = n < 1; $("#doc-preguntar").disabled = n < 1; $("#doc-comparar").disabled = n < 2;
  $("#doc-resumir").textContent = n > 1 ? `Resumir (${n})` : "Resumir";
}

async function indexarCarpeta(ruta) {
  const r = ruta ? await api().añadir_carpeta_ruta(ruta) : await api().elegir_carpeta_documentos();
  if (r.cancelado) return;
  if (!r.ok) return fallo("#doc-aviso", r.error);
  sondearIndexado();
}

let sondeoIndexado = null;
async function sondearIndexado() {
  clearTimeout(sondeoIndexado);
  const r = await api().estado_indexado();
  const e = r.estado, caja = $("#doc-indexado");
  if (!e) { caja.classList.add("oculto"); return; }
  caja.classList.remove("oculto");
  $("#punto-indexado").parentElement.classList.toggle("ocupado", !!r.activo);
  let pct = 0, detalle = "";
  if (e.fase === "leyendo") { pct = e.total ? e.hechos / e.total : 0; detalle = `${e.hechos} de ${e.total} · ${esc(e.actual)}`; }
  else if (e.fase === "vectores") { pct = e.vectores_total ? e.vectores_hechos / e.vectores_total : 1; detalle = `${e.vectores_hechos} de ${e.vectores_total} fragmentos`; }
  else if (e.fase === "descargando_buscador" && e.descarga) { pct = e.descarga[0] / e.descarga[1]; detalle = `${mb(e.descarga[0])} de ${mb(e.descarga[1])}`; }
  else if (["terminado", "cancelado"].includes(e.fase)) { pct = 1; detalle = `${e.nuevos} nuevos, ${e.saltados} sin cambios${e.paginas_ocr ? `, ${e.paginas_ocr} páginas con OCR` : ""}${e.fin && e.inicio ? " · " + duracion(e.fin - e.inicio) : ""}`; }
  const errores = e.n_errores ? `<details><summary>${e.n_errores} archivo${e.n_errores > 1 ? "s" : ""} sin leer</summary>${e.errores.map((x) => `<div><small>${esc(x.archivo)}: ${esc(x.error)}</small></div>`).join("")}</details>` : "";
  caja.innerHTML = `<div class="cabecera-tarjeta"><h3>${FASES[e.fase] || esc(e.fase)}</h3>${r.activo ? '<button class="fantasma" id="doc-cancelar">Cancelar</button>' : ""}</div>
    <div class="barra"><div style="width:${Math.round(pct * 100)}%"></div></div><small>${detalle}</small>${e.aviso ? aviso("warn", esc(e.aviso)) : ""}${errores}
    ${r.activo ? "<small>Puedes seguir usando Sopa mientras tanto.</small>" : ""}`;
  if ($("#doc-cancelar")) $("#doc-cancelar").onclick = () => api().cancelar_indexado();
  if (r.activo) sondeoIndexado = setTimeout(sondearIndexado, 1000);
  else if (document.querySelector("#vista-documentos.visible")) cargarDocumentos();
}

async function buscarDocs(ev) {
  ev.preventDefault();
  const q = $("#doc-consulta").value.trim(); if (!q) return;
  const r = await api().buscar_documentos(q, docsSel.size ? [...docsSel] : null, 8);
  if (!r.ok) return fallo("#doc-resultados", r.error);
  $("#doc-resultados").innerHTML = r.resultados.length
    ? `<small>${r.modo === "hibrida" ? "Por palabras y por significado" : "Por palabras"} · ${r.resultados.length} resultados</small>` + r.resultados.map((x) => `<div class="resultado"><b>${esc(x.archivo)}</b>${x.pagina ? ` <small>página ${x.pagina}</small>` : ""}<p>${esc(x.texto.slice(0, 320))}${x.texto.length > 320 ? "…" : ""}</p></div>`).join("")
    : aviso("info", "No he encontrado nada parecido.");
}

async function consultaDocs(tipo) {
  const enfoque = $("#doc-enfoque").value.trim();
  $("#doc-resultado").innerHTML = aviso("info", tipo === "resumir" ? "Leyendo y resumiendo… (con documentos largos puede tardar un minuto)" : "Leyendo y comparando…");
  const r = tipo === "resumir" ? await api().resumir_documentos([...docsSel], enfoque) : await api().comparar_documentos([...docsSel], enfoque);
  if (!r.ok) return fallo("#doc-resultado", r.error);
  const auto = r.modelo_auto ? aviso("ok", `Sopa ha cargado <b>${esc(r.modelo_auto.nombre)}</b> porque ${esc(minus(r.modelo_auto.motivo.replace(/^[^:]*:\s*/, "")))}`) : "";
  if (r.modelo_auto) { estado.modeloChat = r.modelo_auto.id; if (r.modelo_auto.ruta) $("#chat-modelo").value = r.modelo_auto.ruta; }
  $("#doc-resultado").innerHTML = auto + `<div class="resultado-docs"><div class="md">${markdown(r.texto)}</div>${pintarCitas(r)}<small class="meta">${r.extractos} extractos · ${r.segundos} s</small></div>`;
}

function enlazarDocumentos() {
  $("#doc-carpeta").onclick = () => indexarCarpeta();
  $("#doc-archivos").onclick = async () => { const r = await api().elegir_documentos(); if (r.errores && r.errores.length) $("#doc-aviso").innerHTML = aviso("warn", r.errores.map((e) => esc(e.nombre + ": " + e.error)).join("<br>")); cargarDocumentos(); };
  $("#doc-busqueda").onsubmit = buscarDocs;
  $("#doc-resumir").onclick = () => consultaDocs("resumir");
  $("#doc-comparar").onclick = () => consultaDocs("comparar");
  $("#doc-preguntar").onclick = async () => {
    const r = await api().documentos();
    estado.docs = r.documentos.filter((d) => docsSel.has(d.id)).map((d) => ({ id: d.id, nombre: d.nombre }));
    mostrarVista("chat"); pintarDocs();
  };
}


// ---- Memoria ------------------------------------------------------------------------
async function cargarMemoria(mensaje) {
  const r = await api().memoria();
  $("#mem-activa").checked = r.activa;
  $("#mem-resumen").textContent = r.entradas.length ? `${r.entradas.length} recuerdo${r.entradas.length > 1 ? "s" : ""}` : "";
  $("#mem-aviso").innerHTML = mensaje || (r.activa ? "" : aviso("info", "La memoria está apagada: Sopa no la usa en el chat, pero se conserva."));
  $("#mem-borrar-todo").classList.toggle("oculto", !r.entradas.length);
  $("#mem-lista").innerHTML = r.entradas.length ? r.entradas.slice().reverse().map((e) => `<div class="fila-modelo"><div><span data-mem-texto="${esc(e.id)}">${esc(e.texto)}</span><small>${esc(e.fecha)}${e.origen === "chat" ? " · desde el chat" : ""}</small></div>
      <div class="acciones"><button class="fantasma" data-mem-editar="${esc(e.id)}">Cambiar</button><button class="fantasma peligro" data-mem-borrar="${esc(e.id)}">Borrar</button></div></div>`).join("")
    : vacio("memoria", "Aún no recuerda nada", "Añade aquí lo que quieras que Sopa tenga en cuenta siempre, o díselo en el chat con «Recuerda que…».");
  const tras = (x, ok) => cargarMemoria(x.ok ? (ok ? aviso("ok", ok) : "") : aviso("err", esc(x.error)));
  document.querySelectorAll("[data-mem-editar]").forEach((b) => b.onclick = async () => {
    const e = r.entradas.find((x) => x.id === b.dataset.memEditar);
    const nuevo = prompt("Cambiar el recuerdo:", e.texto);
    if (nuevo === null || nuevo.trim() === e.texto) return;
    tras(await api().memoria_editar(e.id, nuevo), "Cambiado.");
  });
  document.querySelectorAll("[data-mem-borrar]").forEach((b) => b.onclick = async () => tras(await api().memoria_borrar(b.dataset.memBorrar), "Borrado."));
}

function enlazarCarpetas() {
  $("#carp-anadir").onclick = async () => {
    const r = await api().elegir_carpeta_autorizada();
    if (!r || r.cancelado) return;
    pintarCarpetas(r.ok ? aviso("ok", "Carpeta añadida. Sopa puede proponer acciones aquí, siempre con tu confirmación.") : aviso("err", esc(r.error)));
  };
  $("#carp-deshacer").onclick = async () => {
    const r = await api().acciones_deshacer();
    pintarCarpetas(r.ok ? aviso("ok", esc(r.texto || "He deshecho la última acción.")) : aviso("err", esc(r.error)));
  };
  $("#carp-borrar").onclick = () => {
    $("#carp-aviso").innerHTML = aviso("warn", "¿Borrar el registro de acciones? El registro se olvida. Los archivos no se tocan.",
      `<button class="peligro" id="carp-borrar-si">Borrar el registro</button><button class="fantasma" id="carp-borrar-no">Cancelar</button>`);
    $("#carp-borrar-no").onclick = () => pintarCarpetas();
    $("#carp-borrar-si").onclick = async () => {
      const r = await api().acciones_borrar_registro();
      pintarCarpetas(r.ok ? aviso("ok", "Registro borrado.") : aviso("err", esc(r.error)));
    };
  };
}

function enlazarMemoria() {
  $("#mem-form").onsubmit = async (ev) => {
    ev.preventDefault();
    const x = await api().memoria_añadir($("#mem-texto").value, "a mano");
    if (x.ok) $("#mem-texto").value = "";
    cargarMemoria(x.ok ? aviso("ok", "Guardado.") : aviso("err", esc(x.error)));
  };
  $("#mem-activa").onchange = async (ev) => { await api().memoria_activar(ev.target.checked); cargarMemoria(); };
  $("#mem-borrar-todo").onclick = () => {
    $("#mem-aviso").innerHTML = aviso("warn", "¿Borrar todo lo que Sopa recuerda de ti? No se puede deshacer.", `<button class="peligro" id="mem-todo-si">Borrar todo</button><button class="fantasma" id="mem-todo-no">Cancelar</button>`);
    $("#mem-todo-no").onclick = () => $("#mem-aviso").innerHTML = "";
    $("#mem-todo-si").onclick = async () => { const x = await api().memoria_borrar_todo(); cargarMemoria(x.ok ? aviso("ok", "Memoria borrada.") : aviso("err", esc(x.error))); };
  };
}
