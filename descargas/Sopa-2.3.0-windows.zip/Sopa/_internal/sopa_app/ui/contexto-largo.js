// Conversaciones largas: la tarjeta de Ajustes y el aviso «Lo más antiguo va resumido» del chat.
// Todo se queda en este equipo; aquí solo se leen y guardan ajustes.
function clMiles(n) {
  return String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, "\u00a0");
}

function clTextoUmbral(pct, datos) {
  const tokens = datos && datos.modelo_cargado && datos.contexto ? ` (${clMiles(datos.contexto)} tokens con el modelo cargado)` : "";
  return `Resume cuando la conversación llena el ${pct} % del contexto${tokens}. Más alto: resume menos veces, pero cada vez más de golpe.`;
}

function clTextoDisco(e) {
  const maximo = Number(e && e.maximo) || 2;
  const n = Number(e && e.n) || 0;
  const cuantas = n === 1 ? "1 conversación" : `${n} conversaciones`;
  return `Se guardan las ${maximo} últimas conversaciones. Ahora: ${cuantas}, ${clMiles(e && e.mb)} MB.`;
}

let clDatos = null;
let clConvPintada;

// Lo llama pintarMensajes: solo pregunta al backend cuando cambia la conversación abierta.
function clSiCambiaLaConversacion() {
  const actual = (typeof estado !== "undefined" && estado.conversacion) || null;
  if (actual === clConvPintada) return;
  clConvPintada = actual;
  const texto = $("#cl-resumen-texto");
  if (texto) texto.hidden = true;
  pintarResumido(actual);
}

async function pintarContextoLargo() {
  const tarjeta = $("#contexto-largo");
  if (!tarjeta) return;
  let r;
  try { r = await api().contexto_largo_estado(); } catch (e) { return; }
  if (!r || r.ok === false) return;
  clDatos = r;
  const on = $("#cl-on"), umbral = $("#cl-umbral"), salida = $("#cl-umbral-valor"), ayuda = $("#cl-umbral-ayuda");
  const pct = Math.round((Number(r.umbral) || 0.85) * 100);
  on.checked = r.activo !== false;
  umbral.value = String(pct);
  umbral.disabled = !on.checked;
  salida.textContent = `${pct} %`;
  ayuda.textContent = clTextoUmbral(pct, r);
  $("#cl-ssd").checked = r.ssd !== false;
  $("#cl-disco-texto").textContent = clTextoDisco(r.estados);
}

async function pintarResumido(conversacion) {
  const caja = $("#cl-resumido"), texto = $("#cl-resumen-texto"), boton = $("#cl-ver-resumen");
  if (!caja) return;
  const ocultar = () => { caja.hidden = true; texto.hidden = true; texto.textContent = ""; };
  if (!conversacion) return ocultar();
  let r;
  try { r = await api().contexto_largo_estado(conversacion); } catch (e) { return ocultar(); }
  if (!r || r.ok === false || r.activo === false || !(Number(r.resumidos) > 0) || conversacion !== estado.conversacion) return ocultar();
  const n = Number(r.resumidos);
  $("#cl-resumido-texto").textContent = `Lo más antiguo va resumido (${n} ${n === 1 ? "mensaje" : "mensajes"}). Si preguntas por algo de antes, Sopa lo busca en la conversación entera.`;
  texto.textContent = r.resumen || "";
  caja.hidden = false;
  if (texto.hidden) boton.textContent = "Ver resumen";
}

window.addEventListener("pywebviewready", () => {
  const on = $("#cl-on");
  if (!on) return;
  on.onchange = async (e) => {
    $("#cl-umbral").disabled = !e.target.checked;
    await api().guardar_ajustes({ contexto_largo: e.target.checked === true });
    if (typeof estado !== "undefined") pintarResumido(estado.conversacion);
  };
  $("#cl-umbral").oninput = (e) => {
    const pct = Number(e.target.value);
    $("#cl-umbral-valor").textContent = `${pct} %`;
    $("#cl-umbral-ayuda").textContent = clTextoUmbral(pct, clDatos);
  };
  $("#cl-umbral").onchange = (e) => api().guardar_ajustes({ contexto_umbral: Number(e.target.value) / 100 });
  $("#cl-ssd").onchange = (e) => api().guardar_ajustes({ contexto_ssd: e.target.checked === true });
  $("#cl-borrar-estados").onclick = async () => {
    const r = await api().contexto_borrar_estados();
    if (r && r.ok !== false) $("#cl-disco-texto").textContent = clTextoDisco(r.estados);
  };
  $("#cl-ver-resumen").onclick = () => {
    const texto = $("#cl-resumen-texto");
    texto.hidden = !texto.hidden;
    $("#cl-ver-resumen").textContent = texto.hidden ? "Ver resumen" : "Ocultar resumen";
  };
});
