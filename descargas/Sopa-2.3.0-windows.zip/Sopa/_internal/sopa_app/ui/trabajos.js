// Jarvis 2: Taller › Trabajos, encargos en segundo plano desde la Sala, detalle con traza y aviso al cerrar.
// Sigue las maquetas aprobadas de Imelda. GPL-3.0-only.
"use strict";

// Decisiones abiertas, tal cual la maqueta. Cambiar aquí si Miguel decide otra cosa.
const TR_BOTON_SI = "Permitir";
const TR_BOTON_NO = "Denegar";

const TR = { lista: [], cierre: null, avisar: true, filtro: "", detalle: null, bannerFuera: false, agentes: ["documentos", "archivos", "investigacion", "automatizaciones"], cargado: false, terminados: {} };
const TR_AVATAR = { chat: "sprout", director: "saturn", codigo: "circuit", documentos: "mirage", archivos: "alloy", investigacion: "proton", automatizaciones: "volt" };
const TR_NOMBRE = { chat: "Sopa", director: "Director", codigo: "Código", documentos: "Documentos", archivos: "Archivos", investigacion: "Investigación", automatizaciones: "Automatizaciones" };
const TR_ESTADO = { en_cola: "En cola", trabajando: "Trabajando", esperando: "Esperando tu respuesta", pausado: "Pausado", pausado_cierre: "Pausado al cerrar Sopa", hecho: "Hecho", fallido: "Fallido", cancelado: "Cancelado" };
const TR_I = {
  fondo: '<path d="M20 12a8 8 0 1 1-3-6.2"/><path d="M20 4v4h-4"/><path d="M12 8v4l3 2"/>',
  cola: '<path d="M5 6h14M5 12h14M5 18h9"/>',
  pregunta: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.3-1 .9-1 1.7"/><path d="M12 17v.5"/>',
  pausa: '<path d="M9 6v12M15 6v12"/>', play: '<path d="M8 5l11 7-11 7z"/>',
  apagado: '<path d="M12 3v8"/><path d="M6.3 7a8 8 0 1 0 11.4 0"/>',
  ok: '<path d="m5 12 5 5 9-10"/>', x: '<path d="m6 6 12 12M18 6 6 18"/>', cancel: '<circle cx="12" cy="12" r="9"/><path d="m6 18 12-12"/>',
  pensar: '<path d="M9 18h6M10 21h4"/><path d="M12 3a6 6 0 0 0-3.5 10.9c.4.3.5.7.5 1.1v.5h6V15c0-.4.2-.8.5-1.1A6 6 0 0 0 12 3Z"/>',
  herramienta: '<path d="M14.7 6.3a4 4 0 0 0 5 5L11 20a2.1 2.1 0 0 1-3-3Z"/><path d="M14.7 6.3 17 4l3 3-2.3 2.3"/>',
  flecha: '<path d="M5 12h14M13 6l6 6-6 6"/>', arriba: '<path d="m6 15 6-6 6 6"/>', abajo: '<path d="m6 9 6 6 6-6"/>',
  archivo: '<path d="M6 3h9l4 4v14H6V3Z"/><path d="M14 3v5h5"/>', carpeta: '<path d="M3 6h6l2 2h10v11H3z"/>',
  atras: '<path d="M15 6 9 12l6 6"/>', resultado: '<path d="M6 3h9l4 4v14H6V3Z"/><path d="m9 14 2 2 4-4"/>',
  reintentar: '<path d="M20 11a8 8 0 0 0-14.9-3.5M4 4v4h4"/><path d="M4 13a8 8 0 0 0 14.9 3.5M20 20v-4h-4"/>',
};
const TR_ICONO_ESTADO = { en_cola: "cola", esperando: "pregunta", pausado: "pausa", pausado_cierre: "apagado", hecho: "ok", fallido: "x", cancelado: "cancel" };
const TR_COLOR = { trabajando: "--tr-trabajando", en_cola: "--tr-cola", esperando: "--tr-esperando", pausado: "--tr-pausado", pausado_cierre: "--tr-cierre", hecho: "--tr-hecho", fallido: "--tr-fallido", cancelado: "--tr-cancelado" };
const TR_NIVEL = { libre: "Libre", anotada: "Anotada", preguntar: "Preguntar", bloqueada: "Bloqueada" };
const TR_MARCA = /\[[^\]]*\]\(sopa:(trabajo(?:-fin|-delega|-cola)?)\/(tr-[0-9a-f]+)\)/;

const trE = (t) => String(t ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const trIc = (n, extra = "") => `<svg class="tr-i ${extra}" viewBox="0 0 24 24" aria-hidden="true">${TR_I[n] || ""}</svg>`;
// Pendientes de reanudar: primero el que estaba en marcha, luego la cola en su orden (como el motor).
const trOrdenCierre = (a, b) => {
  const k = (t) => { const e = t.estaba || {}; return [["trabajando", "esperando"].includes(e.estado) ? 0 : 1, e.posicion || 0]; };
  const [a1, a2] = k(a), [b1, b2] = k(b);
  return a1 - b1 || a2 - b2;
};
const trVis = (t) => t.estado_visual || ((t.estado === "pausado" && t.motivo_pausa === "cierre_app") ? "pausado_cierre" : t.estado);
const trPorId = (id) => TR.lista.find((t) => t.id === id);
function trFicha(id) { return (typeof fichaEquipo === "function" && fichaEquipo(id)) || null; }
function trNombre(id) { const f = trFicha(id); return (f && f.nombre) || TR_NOMBRE[id] || id; }
function trAvatar(id) { const f = trFicha(id); return (f && f.avatar) || TR_AVATAR[id] || "sprout"; }
function trIconoEstado(v) { return v === "trabajando" ? '<span class="tr-pulso" aria-hidden="true"></span>' : trIc(TR_ICONO_ESTADO[v]); }
function trChip(v, texto) { return `<span class="tr-estado" data-estado="${v}">${trIconoEstado(v)}${trE(texto || TR_ESTADO[v])}</span>`; }
function trCara(ag, tam = "", anillo = "", badge = false) {
  const b = badge && anillo && anillo !== "trabajando" ? `<span class="tr-badge" data-c="${anillo}">${trIc(TR_ICONO_ESTADO[anillo])}</span>` : "";
  return `<span class="tr-cara ${tam}"${anillo ? ` data-anillo="${anillo}"` : ""}><img src="avatares/${trE(trAvatar(ag))}.png" alt="">${b}</span>`;
}

// ---------- Fechas y tiempos ----------
function trFecha(iso) { if (!iso) return null; const d = new Date(iso); return isNaN(d) ? null : d; }
function trHora(iso) { const d = trFecha(iso); return d ? `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}` : "—"; }
function trDia(d) {
  const hoy = new Date(); const a = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate());
  const b = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  return Math.round((a - b) / 86400000);
}
const TR_MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];
function trCuando(iso) {
  const d = trFecha(iso); if (!d) return "—";
  const n = trDia(d);
  if (n === 0) return trHora(iso);
  if (n === 1) return "Ayer " + trHora(iso);
  return `${d.getDate()} ${TR_MESES[d.getMonth()].slice(0, 3)}`;
}
function trCierreFrase(iso) {
  const d = trFecha(iso); if (!d) return "Sopa se cerró";
  const n = trDia(d);
  const dia = n === 0 ? "hoy" : n === 1 ? "ayer" : `el ${d.getDate()} de ${TR_MESES[d.getMonth()]}`;
  return `Sopa se cerró ${dia} a las ${trHora(iso)}`;
}
function trTiempo(seg) {
  seg = Math.max(0, Math.round(Number(seg) || 0));
  if (seg < 60) return seg ? `${seg} s` : "0 min";
  if (seg < 3600) return `${Math.round(seg / 60)} min`;
  const h = Math.floor(seg / 3600), m = Math.round((seg % 3600) / 60);
  return m ? `${h} h ${m} min` : `${h} h`;
}
const trOrdinal = (n) => `${n}.º`;
function trPaso(t) { return t.paso_actual || { n: t.paso || 0, total_estimado: t.paso || 0, texto: "" }; }
function trDeUnos(p) { return p.total_estimado && p.total_estimado > p.n ? ` de unos ${p.total_estimado}` : ""; }
function trOrigenCorto(t) { return t.delegado_por ? `se lo encargó ${trNombre(t.delegado_por)}` : t.origen === "movil" ? "desde el móvil" : "desde la Sala"; }
function trOrigenLargo(t) { return t.delegado_por ? `Se lo encargó ${trNombre(t.delegado_por)}` : t.origen === "movil" ? "Lo pediste desde el móvil" : "Lo pediste en la Sala"; }
// Nombres internos de las herramientas (puerta.HERRAMIENTAS y bucle) en texto que se lee bien.
// Una que no esté aquí sale tal cual: nunca se rompe la línea.
const TR_HERRAMIENTA_TEXTO = {
  listar_archivos: "ver los archivos de una carpeta", leer_archivo: "leer un archivo", mirar_imagen: "mirar una imagen", documentos: "buscar en los documentos",
  extraer: "extraer datos de un documento", resumir: "resumir un documento", comparar: "comparar documentos",
  calcular: "calcular", planificar: "ordenar los pasos", buscar_conversaciones: "buscar en las conversaciones",
  aprender_despues: "dejar un texto para aprenderlo cuando la gráfica esté libre",
  crear_imagen: "crear una imagen",
  editar_imagen: "editar una imagen creada por Sopa",
  crear_video: "crear un vídeo",
  listar_automatizaciones: "ver las automatizaciones",
  automatizacion_de_lectura: "guardar una automatización que solo lee", buscar_web: "buscar en la web", leer_web: "leer una página web",
  crear_archivo: "crear o cambiar un archivo", crear_documento: "crear un documento", escribir_archivo: "preparar un archivo", crear_carpeta: "crear una carpeta",
  renombrar: "cambiar un nombre", mover: "mover", copiar: "copiar", organizar: "organizar una carpeta", papelera: "tirar a la papelera",
  crear_automatizacion: "guardar una automatización que cambia archivos", editar_automatizacion: "cambiar una automatización",
  pausar_automatizacion: "pausar o reanudar una automatización", ejecutar_automatizacion: "lanzar una automatización guardada",
  guardar_agente: "crear o cambiar un agente", delegar_trabajo: "pasar un encargo a un compañero",
  delegar: "encargar un subtrabajo aislado",
  ejecutar_codigo: "ejecutar el código en el arenero y hacer una captura",
  escritorio_abrir: "abrir el escritorio aislado o una aplicación dentro",
  escritorio_ventanas: "ver las ventanas del escritorio aislado",
  escritorio_capturar: "capturar el escritorio aislado",
  escritorio_mover: "mover el ratón del escritorio aislado",
  escritorio_clic: "pulsar en el escritorio aislado",
  escritorio_teclear: "escribir en el escritorio aislado",
  ordenador_abrir: "encender el ordenador del agente",
  ordenador_estado: "ver el estado del ordenador del agente",
  ordenador_capturar: "capturar el ordenador del agente",
  ordenador_mover: "mover el ratón del ordenador del agente",
  ordenador_clic: "pulsar en el ordenador del agente",
  ordenador_teclear: "escribir en el ordenador del agente",
  ordenador_red: "conectar o cortar la red del ordenador del agente",
  ordenador_apagar: "apagar el ordenador del agente",
  proponer_cambio: "preparar un cambio", proponer_plan: "preparar un plan",
};
function trHerramientaTexto(nombre) {
  const n = String(nombre ?? "");
  return Object.prototype.hasOwnProperty.call(TR_HERRAMIENTA_TEXTO, n) ? TR_HERRAMIENTA_TEXTO[n] : n;
}
// «leer_archivo · Libre» → «leer un archivo · Libre»; «Sopa pregunta · mover» → «Archivos pregunta · mover».
function trEventoTexto(texto, agente) {
  let s = String(texto ?? "");
  const quien = agente ? trNombre(agente) : "";
  if (quien) s = s.replace(/^Sopa pregunta(?= · |$)/, `${quien} pregunta`);
  return s.replace(/^((?:[^·]+ pregunta · )?)([a-z][a-z0-9_]*)(?= · |$)/, (m, pre, n) => pre + trHerramientaTexto(n));
}
function trPregunta(t) { return `${trNombre(t.agente)} pregunta`; }
function trUltimo(t) {
  const u = t.ultimo_evento || { texto: "—", hace: "" };
  return Object.assign({}, u, { texto: trEventoTexto(u.texto, t.agente) });
}

// ---------- Carga ----------
async function cargarTrabajos() {
  if (typeof api !== "function") return;
  let r;
  try { r = await api().trabajos_estado(); } catch (e) { return; }
  if (!r || r.ok === false) return;
  TR.lista = r.trabajos || [];
  TR.cierre = r.cierre || null;
  TR.avisar = r.avisar_al_cerrar !== false;
  if (Array.isArray(r.agentes) && r.agentes.length) TR.agentes = r.agentes;
  TR.cargado = true;
  trPintarEncargar();
  pintarTodoTrabajos();
}
function pintarTodoTrabajos() {
  pintarTablero();
  trMarcas();
  trDecorarSala();
  trBanners();
  trInterruptor();
  if (TR.detalle && document.querySelector("#vista-trabajo.visible")) trAbrir(TR.detalle, true);
}
function trMarcas() {
  const n = TR.lista.filter((t) => t.estado === "esperando").length;
  ["trabajos-n", "taller-n"].forEach((ident) => {
    const c = document.getElementById(ident);
    if (c) { c.hidden = !n; c.textContent = n || ""; c.title = n === 1 ? "1 te pregunta" : `${n} te preguntan`; }
  });
  const p = document.getElementById("punto-tarea");
  if (p) p.classList.toggle("tr-atencion", n > 0);
}

// ---------- Tablero ----------
function trBotonesCola(t, pos, total) {
  const a = t.acciones || [];
  return `<button type="button" class="icono-btn" aria-label="Subir" data-tr="subir" data-id="${t.id}"${pos === 1 || !a.includes("subir") ? " disabled" : ""}>${trIc("arriba")}</button>`
    + `<button type="button" class="icono-btn" aria-label="Bajar" data-tr="bajar" data-id="${t.id}"${pos === total || !a.includes("bajar") ? " disabled" : ""}>${trIc("abajo")}</button>`
    + `<button type="button" class="btn texto tr-peligro" data-tr="quitar" data-id="${t.id}">Quitar</button>`;
}
function trFilaCola(t, pos, total) {
  return `<div class="tr-fila" data-agente="${trE(t.agente)}">
    <span class="tr-pos" aria-label="Posición ${pos}">${pos}</span>
    ${trCara(t.agente, "", "en_cola", true)}
    <div class="tr-txt"><b>${trE(t.encargo)}</b><span>${trE(trNombre(t.agente))} · ${trE(trOrigenCorto(t))} · en cola desde las ${trE(trHora(t.creado))}${t.paso ? " · iba por el paso " + t.paso : ""}</span></div>
    ${trChip("en_cola", pos === 1 ? "Siguiente" : "En cola")}
    <div class="tr-mini">${trBotonesCola(t, pos, total)}</div></div>`;
}
function trFilaPausada(t) {
  const p = trPaso(t);
  const linea = t.motivo_pausa === "usuario" || !t.motivo_pausa
    ? `pausado por ti a las ${trHora(t.pausado_en)} · paso ${p.n}${trDeUnos(p)}`
    : `${String(t.etiqueta || "").replace(/^Pausado: /, "").toLowerCase()} · paso ${p.n}${trDeUnos(p)}`;
  return `<div class="tr-fila sin-pos" data-agente="${trE(t.agente)}">
    ${trCara(t.agente, "", "pausado", true)}
    <div class="tr-txt"><b>${trE(t.encargo)}</b><span>${trE(trNombre(t.agente))} · ${trE(trOrigenCorto(t))} · ${trE(linea)}</span></div>
    ${trChip("pausado", t.etiqueta)}
    <div class="tr-mini"><button type="button" class="btn" data-tr="reanudar" data-id="${t.id}">${trIc("play")}Reanudar</button><button type="button" class="btn texto tr-peligro" data-tr="cancelar" data-id="${t.id}">Cancelar</button></div></div>`;
}
function trLineaCierre(t) {
  const est = t.estaba || {};
  const p = trPaso(t);
  if (est.estado === "en_cola" && !p.n) return `estaba el ${trOrdinal(est.posicion || 1)} en la cola · aún no había empezado`;
  if (est.estado === "en_cola") return `estaba el ${trOrdinal(est.posicion || 1)} en la cola · iba por el paso ${p.n}`;
  return `iba por el paso ${p.n}${trDeUnos(p)} · lo hecho está guardado`;
}
function trBloqueMarcha(t) {
  const p = trPaso(t);
  const total = Math.max(p.total_estimado || 0, p.n || 1);
  const barra = Array.from({ length: Math.min(total, 60) }, (_, i) => `<i class="${i < p.n - 1 ? "ok" : i === p.n - 1 ? "ahora" : ""}"></i>`).join("");
  const u = trUltimo(t);
  return `<h4 class="tr-bloque-t">En marcha</h4>
  <div class="tarjeta tr-marcha" data-agente="${trE(t.agente)}">
    ${trCara(t.agente, "xl", "trabajando")}
    <div>
      <div class="tr-quien"><b>${trE(trNombre(t.agente))}</b>${trChip("trabajando")}</div>
      <h3>${trE(t.encargo)}</h3>
      <div class="tr-paso"><b>Paso ${p.n}${trDeUnos(p)}</b>${p.texto ? `<span>· ${trE(p.texto)}</span>` : ""}</div>
      <div class="tr-barra" role="progressbar" aria-valuemin="0" aria-valuemax="${total}" aria-valuenow="${p.n}" aria-label="Paso ${p.n}${trDeUnos(p)}">${barra}</div>
      <div class="tr-pie-meta"><span>Último: <b>${trE(u.texto)}</b>${u.hace ? " · " + trE(u.hace) : ""}</span><span>Tiempo: <b>${trE(trTiempo(t.segundos_activo ?? t.segundos))}</b></span><span>Empezó a las <b>${trE(trHora(t.empezo))}</b></span></div>
    </div>
    <div class="tr-botones"><button type="button" class="btn primario" data-ver="${t.id}">Ver detalle</button><button type="button" class="btn" data-tr="pausar" data-id="${t.id}">${trIc("pausa")}Pausar</button><button type="button" class="btn texto tr-peligro" data-tr="cancelar" data-id="${t.id}">Cancelar</button></div>
  </div>`;
}
function trBotonesPregunta(t) {
  const pr = t.pregunta || {};
  if (pr.puede_responder === false) return `<small>Responde desde donde lo pediste</small>`;
  // Ya existe el destino: no se escribe nada hasta que lo confirmes otra vez, con el aviso a la vista.
  if (pr.sobrescribe) return `<span class="tr-sobrescribe" role="alert">${trE(pr.aviso || "Ya hay algo con ese nombre. Si sigues, lo de ahora va a la papelera de reciclaje.")}</span>`
    + `<button type="button" class="btn peligro" data-tr="sobrescribir" data-id="${t.id}">Sobrescribir</button><button type="button" class="btn" data-tr="denegar" data-id="${t.id}">${TR_BOTON_NO}</button>`;
  return `<button type="button" class="btn primario" data-tr="permitir" data-id="${t.id}">${TR_BOTON_SI}</button><button type="button" class="btn" data-tr="denegar" data-id="${t.id}">${TR_BOTON_NO}</button>`;
}
function trBloquePreguntas(lista) {
  if (!lista.length) return "";
  return `<h4 class="tr-bloque-t">Esperan tu respuesta <span class="tr-cuenta">${lista.length}</span></h4>
  <div class="tr-lista tr-pregunta-lista">${lista.map((t) => `<div class="tr-fila" data-agente="${trE(t.agente)}">
    ${trCara(t.agente, "", "esperando", true)}
    <div class="tr-txt"><span class="tr-q">${trE(trPregunta(t))}: ¿${trE(String((t.pregunta || {}).etiqueta || "").replace(/[?¿]/g, ""))}?</span><span>${trE(trNombre(t.agente))} · ${trE(String(t.encargo).replace(/\.$/, ""))} · desde las ${trE(trHora((t.pregunta || {}).desde))} · sin respuesta, el trabajo sigue en espera y no se mueve nada</span></div>
    <div class="tr-mini">${trBotonesPregunta(t)}<button type="button" class="btn texto" data-ver="${t.id}">Ver qué hará</button></div></div>`).join("")}</div>`;
}
function trHistLinea(t) {
  const r = t.resultado || {};
  if (t.estado === "fallido") return r.error || "No ha podido terminar";
  if (t.estado === "cancelado") return `Cancelado por ti en el paso ${t.paso || 0}`;
  return r.resumen || "Hecho";
}
// Terminados, como en la maqueta: Abrir carpeta o Reintentar a la vista; Repetir y el detalle en «…».
// Reanudar todos y Borrar el historial van en el «…» de la sección.
function trFilaTerminado(t, n) {
  const pildora = t.estado === "hecho" ? `<span class="pildora ok">Hecho</span>`
    : t.estado === "fallido" ? `<span class="pildora aviso">No terminó</span>` : `<span class="pildora">Cancelado</span>`;
  const cuando = t.estado === "hecho" ? `hecho ${trCuandoFrase(t.terminado)}` : t.estado === "fallido" ? `se detuvo ${trCuandoFrase(t.terminado)}` : `cancelado ${trCuandoFrase(t.terminado)}`;
  const a = t.acciones || [];
  const principal = a.includes("reintentar") ? `<button type="button" class="btn" data-tr="reintentar" data-id="${t.id}">${trIc("reintentar")}Reintentar</button>`
    : (t.carpetas || []).length ? `<button type="button" class="btn" data-tr-carpeta="${trE(t.id)}">${trIc("carpeta")}Abrir carpeta</button>`
    : `<button type="button" class="btn" data-ver="${t.id}">Ver resultado</button>`;
  return `<div class="fila" data-agente="${trE(t.agente)}">${trCara(t.agente, "")}
    <div class="txt"><b>${trE(t.encargo)}</b><span>${trE(trNombre(t.agente))} · ${trE(cuando)} · ${trE(trHistLinea(t))}</span></div>${pildora}${principal}
    <div class="ancla"><button type="button" class="icono-btn" data-menu="menu-tr-h${n}" aria-haspopup="menu" aria-expanded="false" aria-label="Más opciones" title="Más opciones">${svg("mas")}</button>
      <div class="menu abajo derecha" id="menu-tr-h${n}" role="menu"><button type="button" class="menu-item" role="menuitem" data-ver="${t.id}">${svg("info")}${t.estado === "fallido" ? "Ver qué pasó" : "Ver detalle"}</button>
        <button type="button" class="menu-item" role="menuitem" data-tr="repetir" data-id="${t.id}">${trIc("reintentar")}Repetir</button></div></div></div>`;
}
function trCuandoFrase(iso) {
  const d = trFecha(iso); if (!d) return "";
  const n = trDia(d);
  return n === 0 ? `a las ${trHora(iso)}` : n === 1 ? `ayer a las ${trHora(iso)}` : `el ${d.getDate()} de ${TR_MESES[d.getMonth()]}`;
}
function trBloqueHistorial(lista) {
  const pausados = TR.lista.some((t) => t.estado === "pausado");
  return `<section><div class="seccion-titulo"><h2>Terminados <span class="contador neutro">${lista.length}</span></h2>
    <div class="ancla"><button type="button" class="icono-btn" data-menu="menu-tr-hechos" aria-haspopup="menu" aria-expanded="false" aria-label="Opciones de Terminados" title="Opciones">${svg("mas")}</button>
      <div class="menu abajo derecha" id="menu-tr-hechos" role="menu">${pausados ? `<button type="button" class="menu-item" role="menuitem" data-tr="reanudar-todos">${trIc("play")}Reanudar todos los pausados</button><div class="menu-sep"></div>` : ""}
        <button type="button" class="menu-item peligro" role="menuitem" data-tr="borrar-historial">Borrar el historial</button></div></div></div>
  <div class="tarjeta cola tr-terminados">${lista.map(trFilaTerminado).join("")}</div></section>`;
}
// Solo el nombre: la carpeta ya va en la ficha.
function trBase(ruta) { return String(ruta || "").split(/[\\/]/).filter(Boolean).pop() || String(ruta || ""); }
function trFiltroHTML(todos) {
  const n = {}; todos.forEach((t) => { n[t.agente] = (n[t.agente] || 0) + 1; });
  const ids = TR.agentes.slice();
  todos.forEach((t) => { if (!ids.includes(t.agente)) ids.push(t.agente); });
  // Un agente sin trabajos no se ofrece como filtro (salvo si es el filtro puesto).
  const con = ids.filter((id) => n[id] || TR.filtro === id);
  return `<div class="filtros tr-filtro" role="group" aria-label="Filtrar por agente"><button type="button" class="chip sin-cara todos" data-filtro="" aria-pressed="${!TR.filtro}">Todos <span class="n">${todos.length}</span></button>${con.map((id) => `<button type="button" class="chip" data-filtro="${trE(id)}" aria-pressed="${TR.filtro === id}">${trCara(id, "s")}${trE(trNombre(id))} <span class="n">${n[id] || 0}</span></button>`).join("")}</div>`;
}
// La cabecera (título y «Encargar un trabajo») es fija en index.html; el tablero va debajo.
function trCabeza() { return ""; }
function trVacio() {
  return trCabeza() + `<div class="tarjeta tr-vacio">
    <div class="tr-caras">${["investigacion", "documentos", "archivos"].map((a) => trCara(a, "l")).join("")}</div>
    <h3>Aún no hay trabajos</h3>
    <p>Un trabajo es un encargo largo que un agente hace solo mientras tú sigues con lo tuyo.</p>
    <ol><li>Pulsa <b>Encargar un trabajo</b>, arriba, o en la Sala enciende <b>En segundo plano</b> junto a Enviar.</li><li>Escribe el encargo: «Resume los PDF de Recetas en una tabla».</li><li>Lo verás aquí paso a paso. Si necesita permiso, te pregunta.</li></ol>
    <button type="button" class="btn" data-vista="chat">Ir a la Sala</button>
    <p class="terciario tr-nota-pie">Solo avanzan con Sopa abierta. Nada sale de este equipo.</p></div>`;
}
function pintarTablero() {
  const caja = document.getElementById("tablero-trabajos");
  if (!caja) return;
  const todos = TR.lista;
  if (!todos.length) { caja.innerHTML = trVacio(); return; }
  const lista = TR.filtro ? todos.filter((t) => t.agente === TR.filtro) : todos;
  const marcha = lista.find((t) => t.estado === "trabajando");
  const pregs = lista.filter((t) => t.estado === "esperando");
  const cola = lista.filter((t) => t.estado === "en_cola").sort((a, b) => (a.posicion || 0) - (b.posicion || 0));
  const cierre = lista.filter((t) => trVis(t) === "pausado_cierre").sort(trOrdenCierre);
  const pausados = lista.filter((t) => trVis(t) === "pausado");
  const hist = lista.filter((t) => ["hecho", "fallido", "cancelado"].includes(t.estado))
    .sort((a, b) => String(b.terminado || "").localeCompare(String(a.terminado || "")));
  let html = trCabeza() + trFiltroHTML(todos);
  if (cierre.length) {
    html += `<h4 class="tr-bloque-t">Pendientes de reanudar <span class="tr-cuenta">${cierre.length}</span><span class="tr-mas"><button type="button" class="btn primario" data-tr="reanudar-todos">${trIc("play")}Reanudar todos</button></span></h4>
    <div class="tr-lista tr-reanudar">${cierre.map((t) => `<div class="tr-fila" data-agente="${trE(t.agente)}">${trCara(t.agente, "", "pausado_cierre", true)}
      <div class="tr-txt"><b>${trE(t.encargo)}</b><span>${trE(trNombre(t.agente))} · ${trE(trLineaCierre(t))}</span></div>
      ${trChip("pausado_cierre")}<div class="tr-mini"><button type="button" class="btn" data-tr="reanudar" data-id="${t.id}">${trIc("play")}Reanudar</button><button type="button" class="btn texto tr-peligro" data-tr="cancelar" data-id="${t.id}">Cancelar</button></div></div>`).join("")}
      <div class="tr-cola-pausa">${trE(trCierreFrase((TR.cierre && TR.cierre.cerrado_en) || cierre[0].pausado_en))} con estos trabajos sin terminar. Nada sigue solo al abrir: tú decides cuándo.</div></div>`;
  }
  if (marcha) html += trBloqueMarcha(marcha);
  else if (cierre.length) html += `<h4 class="tr-bloque-t">En marcha</h4><div class="tr-lista"><div class="tr-cola-pausa sin-borde">Nada en marcha. La gráfica está libre para el chat.</div></div>`;
  html += trBloquePreguntas(pregs);
  if (cola.length) html += `<h4 class="tr-bloque-t">En cola <span class="tr-cuenta">${cola.length}</span></h4><div class="tr-lista">${cola.map((t, i) => trFilaCola(t, i + 1, cola.length)).join("")}<div class="tr-cola-pausa">De uno en uno: el 1 empieza cuando termine ${marcha ? trE(trNombre(marcha.agente)) : "el que está en marcha"}. Mientras uno espera tu respuesta, la cola sigue.</div></div>`;
  if (pausados.length) html += `<h4 class="tr-bloque-t">${pausados.every((t) => (t.motivo_pausa || "usuario") === "usuario") ? "Pausados por ti" : "Pausados"} <span class="tr-cuenta">${pausados.length}</span></h4><div class="tr-lista">${pausados.map(trFilaPausada).join("")}</div>`;
  if (hist.length) html += trBloqueHistorial(hist);
  caja.innerHTML = html;
}

// ---------- Acciones ----------
async function trAccion(accion, id, boton) {
  const A = api();
  const llamadas = {
    pausar: () => A.trabajo_pausar(id), reanudar: () => A.trabajo_reanudar(id), cancelar: () => A.trabajo_cancelar(id),
    reintentar: () => A.trabajo_reintentar(id), quitar: () => A.trabajo_quitar(id),
    permitir: () => A.trabajo_responder(id, true, ((trPorId(id) || {}).pregunta || {}).id || null),
    denegar: () => A.trabajo_responder(id, false, ((trPorId(id) || {}).pregunta || {}).id || null),
    sobrescribir: () => A.trabajo_responder(id, true, ((trPorId(id) || {}).pregunta || {}).id || null, true),
    subir: () => A.trabajo_mover(id, Math.max(1, ((trPorId(id) || {}).posicion || 1) - 1)),
    bajar: () => A.trabajo_mover(id, ((trPorId(id) || {}).posicion || 1) + 1),
    "reanudar-todos": () => A.trabajos_reanudar_todos(),
    "borrar-historial": () => A.trabajos_borrar_historial(),
    repetir: () => { const t = trPorId(id) || {}; return A.trabajo_crear(t.agente, t.encargo, false); },
  };
  if (!llamadas[accion]) return;
  if (accion === "cancelar" && !confirm("¿Cancelar este trabajo? Lo hecho hasta ahora queda en el historial.")) return;
  if (accion === "borrar-historial" && !confirm("¿Borrar el historial de trabajos terminados? Los resúmenes siguen en los hilos.")) return;
  if (boton) boton.disabled = true;
  let r;
  try { r = await llamadas[accion](); } catch (e) { r = { ok: false, error: String(e) }; }
  if (r && r.ok === false && typeof toast === "function") toast(r.error || "No se ha podido.");
  if (accion === "reanudar-todos") TR.bannerFuera = true;
  await cargarTrabajos();
}
document.addEventListener("click", (ev) => {
  const ver = ev.target.closest("[data-ver]");
  if (ver && ver.closest("#vista-trabajos, #vista-trabajo, #mensajes, #toast, .tr-banner")) { ev.preventDefault(); trAbrir(ver.dataset.ver); return; }
  const b = ev.target.closest("[data-tr]");
  if (b && b.closest("#vista-trabajos, #vista-trabajo, #mensajes, .tr-banner")) { ev.preventDefault(); trAccion(b.dataset.tr, b.dataset.id, b); return; }
  const f = ev.target.closest("#vista-trabajos [data-filtro]");
  if (f) { TR.filtro = f.dataset.filtro; pintarTablero(); return; }
  const ir = ev.target.closest("[data-tr-ir]");
  if (ir) { ev.preventDefault(); mostrarVista("trabajos"); return; }
  const carpeta = ev.target.closest("[data-tr-carpeta]");
  if (carpeta) { ev.preventDefault(); trAbrirCarpeta(carpeta.dataset.trCarpeta); return; }
  const modelo = ev.target.closest("[data-tr-modelo]");
  if (modelo) { ev.preventDefault(); trModeloMasPequeno(); return; }
  const fuera = ev.target.closest("[data-tr-banner-fuera]");
  if (fuera) { TR.bannerFuera = true; trBanners(); }
});
function trAbrirCarpeta(id) {
  const t = trPorId(id);
  const c = t && t.carpetas && t.carpetas[0];
  if (c && api().abrir_carpeta) api().abrir_carpeta(c);
}

// ---------- Detalle ----------
function trAgrupar(pasos) {
  const salida = [];
  pasos.forEach((p) => {
    const ultimo = salida[salida.length - 1];
    if (p.tipo === "herramienta" && ultimo && ultimo.tipo === "herramienta" && ultimo.herramienta === p.herramienta && ultimo.nivel === p.nivel) {
      ultimo.grupo = ultimo.grupo || [Object.assign({}, ultimo)];
      ultimo.grupo.push(p); ultimo.fin = p.fin; ultimo.nHasta = p.n;
    } else salida.push(Object.assign({}, p));
  });
  return salida;
}
// Vista previa: si cada línea es «qué  cuánto» (dos o más espacios), en columnas; si no, tal cual.
function trVistaPrevia(texto) {
  const lineas = String(texto || "").split("\n").filter((l) => l.trim());
  const filas = lineas.map((l) => l.match(/^(.*?)\s{2,}(\S.*)$/));
  if (!lineas.length || filas.some((m) => !m)) return `<pre>${trE(texto)}</pre>`;
  return `<table class="tr-vista">${filas.slice(0, 40).map((m) => {
    const lados = m[1].split(/\s*→\s*/);
    return `<tr>${lados.length === 2 ? `<td>${trE(lados[0])}</td><td class="tr-flecha">→</td><td>${trE(lados[1])}</td>` : `<td colspan="3">${trE(m[1])}</td>`}<td class="tr-num">${trE(m[2])}</td></tr>`;
  }).join("")}</table>`;
}
function trNodo(p, t) {
  const ico = { pensar: "pensar", herramienta: "herramienta", resultado: "resultado", pregunta: "pregunta", respondida: "pregunta", ahora: "herramienta", futuro: "cola", fallo: "x" }[p.tipo];
  let nivel = p.nivel ? `<span class="tr-nivel" data-n="${trE(p.nivel)}">${TR_NIVEL[p.nivel] || trE(p.nivel)}</span>` : "";
  let cab = "", cuerpo = "", cuando = p.inicio ? trHora(p.inicio) : "";
  if (p.tipo === "pensar") { cab = "Pensar"; cuerpo = trE(p.texto); }
  else if (p.tipo === "herramienta") {
    if (p.grupo) {
      cab = `<code>${trE(p.herramienta)}</code> × ${p.grupo.length}`;
      cuando = `${trHora(p.inicio)}–${trHora(p.fin)}`;
      cuerpo = p.n === p.nHasta ? `Paso ${p.n}` : `Pasos ${p.n} a ${p.nHasta}`;
      cuerpo = trE(cuerpo) + `<details><summary>${trE(`${p.grupo.length} llamadas · ver cuáles`)}</summary><ol>${p.grupo.map((g) => `<li>${trE(g.texto || g.herramienta)}</li>`).join("")}</ol></details>`;
    } else { cab = `<span title="${trE(p.herramienta)}">${trE(trHerramientaTexto(p.herramienta))}</span> ${trE(String(p.texto || "").split("\n")[0].slice(0, 90))}`; cuerpo = ""; }
  } else if (p.tipo === "pregunta") {
    cab = trPregunta(t);
    const pr = t.pregunta && t.pregunta.id === p.pregunta_id ? t.pregunta : null;
    if (pr) {
      nivel = "";  // el nivel ya va en la tarjeta
      cuerpo = `<div class="tr-sopa-pregunta"><b>${trE(trPregunta(t))}: ¿${trE(String(pr.etiqueta || "").replace(/[?¿]/g, ""))}?</b>${pr.vista ? trVistaPrevia(pr.vista) : ""}
        <div class="tr-fila tr-fila-suelta"><span class="tr-nivel" data-n="preguntar">Preguntar</span><small>${pr.herramienta ? `Herramienta <b>${trE(trHerramientaTexto(pr.herramienta))}</b> · ` : ""}vale solo para esta llamada</small></div>
        <div class="tr-botones">${trBotonesPregunta(t)}<small class="tr-a-la-derecha">Sin respuesta, el trabajo sigue en espera y no se mueve nada.</small></div></div>`;
    } else cuerpo = trE(p.etiqueta || p.texto);
  } else if (p.tipo === "respondida") {
    cab = `Sopa preguntó: ¿${trE(String(p.etiqueta || p.herramienta || "").replace(/[?¿]/g, ""))}?`;
    const si = p.respuesta === "permitido";
    cuerpo = `<b>${si ? "Permitido por ti" : "Denegado por ti"}</b> a las ${trE(trHora(p.fin))}, ${p.respondida_desde === "movil" ? "desde el móvil" : "desde este ordenador"}. ${si ? "Vale solo para esa llamada." : "Siguió sin hacerlo."}`;
  } else if (p.tipo === "resultado") { cab = "Resultado"; cuerpo = trE(p.texto); }
  else if (p.tipo === "fallo") { cab = "No ha podido terminar"; cuerpo = trE(p.texto); }
  else if (p.tipo === "ahora") {
    cab = p.herramienta ? `<code>${trE(p.herramienta)}</code> ${trE(String(p.linea || "").split("\n")[0].slice(0, 90))}` : trE(p.cab);
    cuerpo = trE(p.texto); cuando = "ahora";
  }
  else if (p.tipo === "futuro") { cab = trE(p.cab); cuando = ""; }
  const cuerpoHtml = cuerpo ? (p.tipo === "pregunta" && cuerpo.startsWith("<div") ? cuerpo : `<div class="tr-cuerpo-paso">${cuerpo}</div>`) : "";
  const c = cuando === "ahora" ? `<span class="tr-cuando tr-ahora-linea"><span class="tr-pulso"></span>ahora</span>` : cuando ? `<span class="tr-cuando">${trE(cuando)}</span>` : "";
  return `<li data-t="${p.tipo}"><span class="tr-nodo">${ico ? trIc(ico) : ""}</span><div><div class="tr-cab"><b>${cab}</b>${nivel}${c}</div>${cuerpoHtml}</div></li>`;
}
// La llamada en curso es el último nodo de herramienta mientras el último evento sea esa herramienta.
function trLlamadaEnCurso(t) {
  const pasos = t.pasos || [], ult = pasos[pasos.length - 1];
  return t.estado === "trabajando" && ult && ult.tipo === "herramienta" && (t.ultimo_evento || {}).tipo === "herramienta" ? ult : null;
}
function trTraza(t) {
  const vivo = trLlamadaEnCurso(t);
  const nodos = trAgrupar(vivo ? t.pasos.slice(0, -1) : (t.pasos || []));
  const p = trPaso(t);
  const sigue = `Paso ${p.n + 1}${p.texto ? " · " + p.texto : ""}`;
  if (vivo) nodos.push({ tipo: "ahora", herramienta: vivo.herramienta, nivel: vivo.nivel, linea: vivo.texto, texto: sigue });
  else if (t.estado === "trabajando") nodos.push({ tipo: "ahora", cab: trEventoTexto((t.ultimo_evento || {}).texto, t.agente) || "Pensando", texto: sigue });
  if (!["hecho", "fallido", "cancelado"].includes(t.estado)) {
    const quedan = (p.total_estimado || 0) - (p.n || 0) - (t.estado === "trabajando" ? 1 : 0);
    if (quedan > 0) nodos.push({ tipo: "futuro", cab: `Quedan unos ${quedan} pasos` });
    nodos.push({ tipo: "futuro", cab: `Al final: resumen en el hilo de ${trNombre(t.agente)}` });
  }
  if (!nodos.length) return `<p class="sub">Aún no ha empezado.</p>`;
  return `<ol class="tr-traza">${nodos.map((n) => trNodo(n, t)).join("")}</ol>`;
}
function trBotonesDetalle(t) {
  const a = t.acciones || [];
  let h = "";
  if (a.includes("reanudar")) h += `<button type="button" class="btn primario" data-tr="reanudar" data-id="${t.id}">${trIc("play")}Reanudar</button>`;
  if (a.includes("reintentar")) h += `<button type="button" class="btn primario" data-tr="reintentar" data-id="${t.id}">${trIc("reintentar")}Reintentar desde el paso ${(t.resultado || {}).paso_fallo || (t.paso || 0) + 1}</button>`;
  if (a.includes("pausar")) h += `<button type="button" class="btn" data-tr="pausar" data-id="${t.id}">${trIc("pausa")}Pausar</button>`;
  if (a.includes("cancelar")) h += `<button type="button" class="btn texto tr-peligro" data-tr="cancelar" data-id="${t.id}">Cancelar</button>`;
  return h;
}
function trResultadoDato(t) {
  const r = t.resultado || {};
  if (t.estado === "hecho") return r.resumen || "Hecho";
  if (t.estado === "fallido") return r.error || "No ha podido terminar";
  if (t.estado === "cancelado") return "Cancelado";
  return "Al terminar, en el hilo de " + trNombre(t.agente);
}
async function trAbrir(id, silencioso) {
  let t = trPorId(id);
  try { const r = await api().trabajo_detalle(id); if (r && r.ok !== false && r.trabajo) t = r.trabajo; } catch (e) { /* con lo de la lista */ }
  if (!t) { if (!silencioso && typeof toast === "function") toast("Ese trabajo ya no está."); return; }
  TR.detalle = id;
  const v = trVis(t), p = trPaso(t), u = trUltimo(t);
  const caja = document.getElementById("vista-trabajo");
  const abiertos = [...caja.querySelectorAll("details")].map((d) => d.open);
  const r = t.resultado || {};
  caja.innerHTML = `<button type="button" class="btn texto tr-volver" data-vista="trabajos">${trIc("atras")}Trabajos</button>
    <div class="tr-det-cabeza" data-agente="${trE(t.agente)}">${trCara(t.agente, "l", v)}
      <div><div class="tr-quien"><b class="tr-nombre">${trE(trNombre(t.agente))}</b>${trChip(v, t.etiqueta)}<span>${trE(trOrigenLargo(t))}</span></div><h1>${trE(t.encargo)}</h1></div>
      <div class="tr-botones">${trBotonesDetalle(t)}</div></div>
    <div class="tr-det-cuerpo">
      <div class="tarjeta tr-pasos"><h3>Pasos</h3>${trTraza(t)}${r.texto ? `<h3 class="tr-resultado-t">Resultado</h3><div class="tr-cuerpo">${typeof markdownSeguro === "function" ? markdownSeguro(r.texto) : trE(r.texto)}</div>` : ""}</div>
      <aside class="tarjeta tr-datos"><dl>
        <div><dt>Estado</dt><dd>${trE(t.etiqueta || TR_ESTADO[v])}</dd></div>
        <div><dt>Paso actual</dt><dd>${p.n ? `${p.n}${trDeUnos(p)}` : "—"}</dd></div>
        <div><dt>Último evento</dt><dd>${trE(u.texto)}<small>${trE(u.hace || "")}</small></dd></div>
        <div><dt>Tiempo trabajando</dt><dd>${trE(trTiempo(t.segundos_activo ?? t.segundos))}${t.empezo ? " · empezó a las " + trE(trHora(t.empezo)) : ""}</dd></div>
        <div><dt>Carpetas</dt><dd>${(t.carpetas || []).map(trE).join(", ") || "—"}</dd></div>
        <div><dt>Resultado</dt><dd>${trE(trResultadoDato(t))}${(r.archivos || []).length ? `<small>${r.archivos.map((a) => trE(trBase(a))).join(", ")}</small>` : ""}</dd></div>
      </dl></aside>
    </div>`;
  caja.querySelectorAll("details").forEach((d, i) => { if (abiertos[i]) d.open = true; });
  if (!silencioso) mostrarVista("trabajo");
}

// ---------- Sala: anillos y líneas ----------
// El que antes sale de la cola entre los de un agente (menor posición).
function trPrimeroEnCola(lista) {
  return lista.filter((t) => t.estado === "en_cola").sort((a, b) => (a.posicion || 1e9) - (b.posicion || 1e9))[0];
}
function trLineaSala(id) {
  const suyos = TR.lista.filter((t) => t.agente === id);
  const vivo = suyos.find((t) => t.estado === "trabajando") || suyos.find((t) => t.estado === "esperando")
    || suyos.find((t) => trVis(t) === "pausado_cierre") || trPrimeroEnCola(suyos) || suyos.find((t) => t.estado === "pausado");
  if (vivo) {
    const v = trVis(vivo);
    const pv = trPaso(vivo);
    const txt = v === "trabajando" ? `Trabajando · paso ${pv.n || 1}${trDeUnos(pv)}` : v === "esperando" ? "Te pregunta algo"
      : v === "en_cola" ? `En cola · ${(vivo.posicion || 1) === 1 ? "primero" : trOrdinal(vivo.posicion)}` : v === "pausado_cierre" ? "En pausa al cerrar Sopa" : "En pausa";
    return [v, txt];
  }
  const fin = suyos.filter((t) => ["hecho", "fallido"].includes(t.estado) && trFecha(t.terminado) && (Date.now() - trFecha(t.terminado)) < 30 * 60000)
    .sort((a, b) => String(b.terminado).localeCompare(String(a.terminado)))[0];
  if (fin) return fin.estado === "hecho" ? ["hecho", "Terminó · " + (trUltimo(fin).hace || "hace un momento")] : ["fallido", "No pudo terminar"];
  return null;
}
function trDecorarSala() {
  document.querySelectorAll("#sala-agentes .sala-item").forEach((b) => {
    const st = trLineaSala(b.dataset.sala);
    if (!st) return;
    const [v, txt] = st;
    // Lavado de cara: la cara no cambia; el estado va en la segunda línea, con su color.
    const pv = b.querySelector(".sala-preview");
    if (!pv) return;
    pv.className = "sala-preview tr-linea"; pv.dataset.estado = v;
    pv.textContent = txt;
  });
}
if (typeof window.pintarSala === "function") {
  const trPintarSala = window.pintarSala;
  window.pintarSala = function () { const r = trPintarSala.apply(this, arguments); trDecorarSala(); return r; };
}

// ---------- Hilo: tarjetas en lugar de los enlaces ----------
function trTarjetaHilo(tipo, id, m) {
  const t = trPorId(id) || { id, agente: m.agente || "chat", estado: "hecho", encargo: "", resultado: {} };
  const r = t.resultado || {};
  if (tipo === "trabajo-cola") {
    const pos = t.estado === "en_cola" ? (t.posicion || 1) : null;
    const quien = trNombre(t.agente);
    const texto = pos ? `<b>Encargo en cola · posición ${pos}</b> · ${trE(quien)} empieza cuando terminen los de delante. Puedes seguir hablando.`
      : `<b>Encargo en segundo plano</b> · ${trE(t.etiqueta || TR_ESTADO[trVis(t)] || "")}.`;
    return `<div class="tr-aviso-cola" data-agente="${trE(t.agente)}">${trIc("cola")}<span>${texto}</span><a class="tr-enlace" href="#" data-tr-ir="1">Ver en Trabajos</a></div>`;
  }
  if (tipo === "trabajo-delega") {
    const v = trVis(t);
    const chip = v === "en_cola" ? trChip("en_cola", `En cola · posición ${t.posicion || 1}`) : trChip(v, t.etiqueta);
    return `<div class="tr-hilo tr-delega" data-agente="${trE(t.agente)}"><div class="tr-fila"><span class="tr-pareja">${trCara(t.delegado_por || "director", "")}<span class="tr-flecha">${trIc("flecha")}</span>${trCara(t.agente, "", v, true)}</span><span class="tr-titulo">${trE(trNombre(t.delegado_por || "director"))} se lo encarga a ${trE(trNombre(t.agente))}</span>${chip}</div>
      <p class="tr-encargo">${trE(t.encargo)}</p>
      ${(t.carpetas || []).length ? `<div class="tr-fila tr-meta">En ${trE(t.carpetas.join(", "))} · si quiere cambiar algo, te pregunta</div>` : `<div class="tr-fila tr-meta">Si quiere cambiar algo, te pregunta</div>`}<div class="tr-fila"><a class="tr-enlace" href="#" data-ver="${trE(id)}">Ver el trabajo</a></div></div>`;
  }
  // trabajo-fin: el resumen con el que termina
  const cuerpo = String(m.content || "").replace(TR_MARCA, "").replace(/^\*\*[^*]+\*\*[^\n]*\n/, "").replace(/^Encargo:[^\n]*\n?/, "").replace(/^\s*Error:[^\n]*/, "").trim();
  const cuerpoSin = r.resumen && cuerpo.split("\n")[0].replace(/^[#*\-• ]+/, "").trim() === r.resumen ? cuerpo.split("\n").slice(1).join("\n").trim() : cuerpo;
  const meta = `${trTiempo(t.segundos_activo ?? t.segundos)} · ${t.paso || 0} pasos · ${t.estado === "fallido" ? "falló" : "terminó"} a las ${trHora(t.terminado)}${t.preguntas_respondidas ? ` · ${t.preguntas_respondidas} ${t.preguntas_respondidas === 1 ? "pregunta respondida" : "preguntas respondidas"} por ti` : ""}`;
  if (t.estado === "fallido") {
    const metaFallo = `${trTiempo(t.segundos_activo ?? t.segundos)} · falló a las ${trHora(t.terminado)}${r.sin_cambios ? " · no se ha cambiado ningún archivo" : ""}`;
    return `<div class="tr-hilo tr-fallo" data-agente="${trE(t.agente)}"><div class="tr-fila tr-una-linea">${trChip("fallido", "No ha podido terminar")}<span class="tr-titulo" title="${trE(t.encargo)}">${trE(trTituloCorto(t.encargo))}</span></div>
      <p class="tr-motivo">${trE(r.error || "No ha podido terminar.")}${t.paso ? " Lo hecho hasta ahí está guardado." : ""}</p>
      <div class="tr-meta">${trE(metaFallo)}</div>
      <div class="tr-acc">${(t.acciones || []).includes("reintentar") ? `<button type="button" class="btn primario" data-tr="reintentar" data-id="${trE(id)}">${trIc("reintentar")}Reintentar desde el paso ${r.paso_fallo || (t.paso || 0) + 1}</button>` : ""}<button type="button" class="btn" data-ver="${trE(id)}">Ver detalle</button>${trFalloDeMemoria(r.error) ? `<button type="button" class="btn texto" data-tr-modelo="1">Usar un modelo más pequeño</button>` : ""}</div></div>`;
  }
  const archivos = (r.archivos || []).map((a) => `<span class="tr-archivo" title="${trE(a)}">${trIc("archivo")}${trE(trBase(a))}</span>`).join("")
    + ((t.carpetas || []).length ? `<span class="tr-archivo">${trIc("carpeta")}en ${trE(t.carpetas[0])}</span>` : "");
  return `<div class="tr-hilo tr-resultado" data-agente="${trE(t.agente)}"><div class="tr-fila">${trChip(t.estado === "cancelado" ? "cancelado" : "hecho")}<span class="tr-titulo">${trE(r.resumen || t.encargo)}</span></div>
    <div class="tr-cuerpo">${typeof markdownSeguro === "function" ? markdownSeguro(cuerpoSin) : trE(cuerpoSin)}</div>
    <div class="tr-meta">${trE(meta)}</div>
    ${archivos ? `<div class="tr-archivos">${archivos}</div>` : ""}
    <div class="tr-acc"><button type="button" class="btn primario" data-ver="${trE(id)}">Ver detalle</button>${(t.carpetas || []).length ? `<button type="button" class="btn" data-tr-carpeta="${trE(id)}">Abrir carpeta</button>` : ""}</div></div>`;
}
if (typeof window.htmlDelMensaje === "function") {
  const trHtmlDelMensaje = window.htmlDelMensaje;
  window.htmlDelMensaje = function (m) {
    const c = String((m && m.content) || "");
    const hit = !m.enCurso && c.match(TR_MARCA);
    if (!hit) return trHtmlDelMensaje.apply(this, arguments);
    const [, tipo, id] = hit;
    const antes = tipo === "trabajo-delega" ? trHtmlDelMensaje.call(this, Object.assign({}, m, { content: c.replace(TR_MARCA, "").replace(/Lo ves en Taller › Trabajos\.\s*$/, "").trim() })) : "";
    return antes + `<template class="tr-hueco" data-tipo="${tipo}" data-id="${trE(id)}" data-burbuja="${tipo === "trabajo-delega" ? "1" : ""}">${trTarjetaHilo(tipo, id, m)}</template>`;
  };
}
function trSacarTarjetas() {
  document.querySelectorAll("#mensajes template.tr-hueco").forEach((tp) => {
    const msg = tp.closest(".msg");
    const frag = tp.content.cloneNode(true);
    if (msg) {
      msg.after(frag);
      if (!tp.dataset.burbuja) msg.classList.add("tr-sin-burbuja");
    }
    tp.remove();
  });
}
if (typeof window.pintarMensajes === "function") {
  const trPintarMensajes = window.pintarMensajes;
  window.pintarMensajes = function () { const r = trPintarMensajes.apply(this, arguments); trSacarTarjetas(); return r; };
}

// Título corto de una tarjeta: la primera parte del encargo, sin repetirlo entero.
function trTituloCorto(encargo, max = 48) {
  const limpio = String(encargo || "").replace(/\s+/g, " ").trim();
  let corto = limpio.split(/[.,;:]\s| y | e /)[0].replace(/[.,;:]$/, "").trim() || limpio;
  if (corto.length > max) corto = corto.slice(0, max).replace(/\s+\S*$/, "") + "…";
  return corto;
}
// Si el fallo fue por memoria, se ofrece cambiar a un modelo más pequeño en el chat.
function trFalloDeMemoria(error) { return /memoria|memory|vram|cuda/i.test(String(error || "")); }
function trModeloMasPequeno() {
  const sel = document.getElementById("chat-modelo");
  if (!sel) return;
  // El modelo se elige en el menú de modelo de la Sala; se carga solo al elegirlo.
  if (typeof mostrarVista === "function") mostrarVista("chat");
  const boton = document.getElementById("boton-modelo");
  if (boton && typeof abrirMenu === "function") setTimeout(() => abrirMenu("menu-modelo"), 0);
  else if (boton) boton.focus();
  if (typeof toast === "function") toast("No hay memoria libre para este trabajo. Elige un modelo más pequeño en la Sala y pulsa «Reintentar».");
}

// ---------- «Encargar un trabajo» ----------
// Un solo diálogo para los de serie y los agentes que has creado tú: todos van a la cola de Trabajos.
function trEsPropio(id) { const f = trFicha(id); return !!(f && f.propio); }
function trPintarEncargar(elegido) {
  const sel = document.getElementById("enc-agente");
  if (!sel) return;
  const previo = elegido || sel.value;
  sel.innerHTML = TR.agentes.map((id) => `<option value="${trE(id)}">${trE(trNombre(id))}${trEsPropio(id) ? " (tuyo)" : ""}</option>`).join("");
  if (previo && TR.agentes.includes(previo)) sel.value = previo;
}
function abrirEncargar(agente) {
  if (typeof mostrarVista === "function" && !document.querySelector("#vista-trabajos.visible")) mostrarVista("trabajos");
  trPintarEncargar(TR.agentes.includes(agente) ? agente : "");
  const aviso = document.getElementById("enc-aviso");
  if (aviso) aviso.innerHTML = agente && !TR.agentes.includes(agente)
    ? `<p class="terciario">${trE(trNombre(agente))} no hace trabajos largos; elige otro agente.</p>` : "";
  // Después del clic que lo pide: el clic en un menú cierra los menús abiertos.
  setTimeout(() => {
    if (typeof abrirMenu === "function") abrirMenu("encargar");
    const q = document.getElementById("enc-que"); if (q) q.focus();
  }, 0);
}
window.abrirEncargar = abrirEncargar;
document.addEventListener("submit", async (ev) => {
  if (!ev.target || ev.target.id !== "encargar") return;
  ev.preventDefault();
  const agente = document.getElementById("enc-agente").value;
  const que = document.getElementById("enc-que");
  const aviso = document.getElementById("enc-aviso");
  const texto = que.value.trim();
  if (!agente || !texto) { aviso.innerHTML = `<p class="terciario">Elige un agente y escribe qué debe hacer.</p>`; que.focus(); return; }
  const boton = document.getElementById("agentes-lanzar");
  boton.disabled = true;
  let r;
  try { r = await api().trabajo_crear(agente, texto, false); } catch (e) { r = { ok: false, error: String(e) }; }
  boton.disabled = false;
  if (!r || r.ok === false) { aviso.innerHTML = `<p class="terciario" role="alert">${trE((r && r.error) || "No se ha podido encargar.")}</p>`; return; }
  que.value = ""; aviso.innerHTML = "";
  if (typeof cerrarMenus === "function") cerrarMenus();
  if (typeof toast === "function") toast(`Encargado a ${trNombre(agente)}. Lo verás aquí paso a paso.`);
  await cargarTrabajos();
});
document.addEventListener("click", (ev) => {
  if (ev.target.closest && ev.target.closest("#abrir-encargar")) setTimeout(() => trPintarEncargar(), 0);
});

// ---------- Sala: «En segundo plano» ----------
function trAgenteSala() { return (document.getElementById("chat-agente") && document.getElementById("chat-agente").value) || "chat"; }
function trInterruptor() {
  const web = document.getElementById("chat-web");
  if (!web) return;
  let b = document.getElementById("chat-fondo");
  if (!b) {
    web.insertAdjacentHTML("afterend", `<button type="button" id="chat-fondo" class="btn" aria-pressed="false">En segundo plano</button>`);
    b = document.getElementById("chat-fondo");
  }
  if (!b.dataset.enlazado) {
    b.dataset.enlazado = "1";
    b.title = "Convierte el mensaje en un encargo que sigue solo";
    b.onclick = () => trFondo(b.getAttribute("aria-pressed") !== "true");
  }
  const puede = TR.agentes.includes(trAgenteSala());
  // Los agentes que no hacen trabajos no enseñan el botón (desactivado no se leía bien).
  b.hidden = !puede;
  b.disabled = !puede;
  if (!puede && b.getAttribute("aria-pressed") === "true") trFondo(false);
  else if (b.getAttribute("aria-pressed") === "true") trFondo(true);
}
function trFondo(on) {
  const b = document.getElementById("chat-fondo"), form = document.getElementById("chat-form");
  if (!b || !form) return;
  b.setAttribute("aria-pressed", on ? "true" : "false");
  form.classList.toggle("en-fondo", on);
  const txt = document.getElementById("chat-texto"), env = document.getElementById("chat-enviar");
  if (on) {
    if (!txt.dataset.trPlaceholder) txt.dataset.trPlaceholder = txt.placeholder;
    txt.placeholder = "Describe el encargo. Lo hará paso a paso mientras sigues hablando.";
    if (!env.dataset.trIcono) env.dataset.trIcono = env.innerHTML;
    env.classList.add("con-texto");
    env.textContent = "Encargar";
    const enCola = TR.lista.filter((t) => ["trabajando", "en_cola"].includes(t.estado)).length;
    const nota = `<b>En segundo plano:</b> ${trE(trNombre(trAgenteSala()))} lo hará solo y te avisa al terminar. ${enCola ? `Irá el ${trOrdinal(enCola + (TR.lista.some((t) => t.estado === "trabajando") ? 0 : 1))} en la cola.` : "Empieza en cuanto lo encargues."}`;
    const n = document.getElementById("tr-fondo-nota");
    if (n) n.querySelector("span").innerHTML = nota;
    else form.insertAdjacentHTML("beforebegin", `<p class="tr-fondo-nota" id="tr-fondo-nota">${trIc("fondo")}<span>${nota}</span></p>`);
  } else {
    if (txt.dataset.trPlaceholder) txt.placeholder = txt.dataset.trPlaceholder;
    if (env.dataset.trIcono) env.innerHTML = env.dataset.trIcono;
    env.classList.remove("con-texto");
    const n = document.getElementById("tr-fondo-nota"); if (n) n.remove();
  }
}
document.addEventListener("submit", async (ev) => {
  if (!ev.target || ev.target.id !== "chat-form") return;
  const b = document.getElementById("chat-fondo");
  if (!b || b.getAttribute("aria-pressed") !== "true") return;
  ev.preventDefault(); ev.stopImmediatePropagation();
  const txt = document.getElementById("chat-texto");
  const texto = txt.value.trim();
  const agente = trAgenteSala();
  if (!texto) return;
  let r;
  try { r = await api().trabajo_crear(agente, texto, true); } catch (e) { r = { ok: false, error: String(e) }; }
  if (!r || r.ok === false) { if (typeof toast === "function") toast((r && r.error) || "No se ha podido encargar."); return; }
  txt.value = "";
  trFondo(false);
  if (estado.hilos) delete estado.hilos[agente];
  estado.hiloToken = (estado.hiloToken || 0) + 1;
  await cargarTrabajos();
  if (typeof abrirHilo === "function") abrirHilo(agente, estado.hiloToken);
}, true);
document.addEventListener("change", (ev) => { if (ev.target && ev.target.id === "chat-agente") setTimeout(trInterruptor, 0); });

// ---------- Avisos: al terminar, banners de reanudar y cierre ----------
function trAvisoTerminado(t) {
  const caja = document.getElementById("toast");
  if (!caja) return;
  const r = t.resultado || {};
  const fallo = t.estado === "fallido";
  const titulo = fallo ? `${trNombre(t.agente)} no ha podido terminar` : `${trNombre(t.agente)} ha terminado${r.resumen ? ": " + r.resumen.replace(/\.$/, "").replace(/^./, (c) => c.toLowerCase()) : ""}`;
  const n = (r.archivos || []).length;
  const sub = `${trTiempo(t.segundos_activo ?? t.segundos)}${n ? ` · ${n} ${n === 1 ? "archivo" : "archivos"}${(t.carpetas || []).length ? " en " + t.carpetas[0] : ""}` : ""}`;
  caja.className = "tr-toast";
  caja.innerHTML = `${trCara(t.agente, "")}<span class="tr-toast-txt"><b>${trE(titulo)}</b><small>${trE(sub)}</small></span><button type="button" class="btn" data-ver="${trE(t.id)}">Ver</button>`;
  clearTimeout(window.toast && window.toast.t);
  if (window.toast) window.toast.t = setTimeout(() => caja.classList.add("oculto"), 8000);
}
if (typeof window.toast === "function") {
  const trToast = window.toast;
  window.toast = function () { const c = document.getElementById("toast"); if (c) c.classList.remove("tr-toast"); return trToast.apply(this, arguments); };
}
function trBannerHTML(lista) {
  const partes = lista.slice(0, 3).map((t) => {
    const est = t.estaba || {}, p = trPaso(t);
    return p.n && est.estado !== "en_cola" ? `${trNombre(t.agente)} iba por el paso ${p.n}` : `${trNombre(t.agente)} no había empezado`;
  });
  const frase = partes.length > 1 ? partes.slice(0, -1).join("; ") + "; " + partes[partes.length - 1] : partes[0];
  const n = lista.length;
  return `<div class="aviso info tr-banner">${trIc("apagado")}<div><b>Hay ${n} ${n === 1 ? "trabajo pausado" : "trabajos pausados"} al cerrar Sopa.</b> ${trE(frase)}. No ${n === 1 ? "sigue solo" : "siguen solos"}.</div><span class="accion"><button type="button" class="btn primario" data-tr="reanudar-todos">${n === 1 ? "Reanudar" : "Reanudar todos"}</button><button type="button" class="btn texto" data-tr-ir="1">Ver en Trabajos</button></span></div>`;
}
function trBanners() {
  const lista = TR.lista.filter((t) => trVis(t) === "pausado_cierre").sort(trOrdenCierre);
  const html = lista.length && !TR.bannerFuera ? trBannerHTML(lista) : "";
  [["tr-banner-inicio", "avisos-inicio"], ["tr-banner-sala", "aviso-chat"]].forEach(([id, ancla]) => {
    let c = document.getElementById(id);
    const a = document.getElementById(ancla);
    if (!c && a) { a.insertAdjacentHTML("beforebegin", `<div id="${id}"></div>`); c = document.getElementById(id); }
    if (c) c.innerHTML = html;
  });
}
// La ventana pregunta esto al cerrar con trabajos vivos. Devuelve true si se encarga del diálogo.
window.trabajosPreguntarCierre = function (datos) {
  datos = datos || {};
  const marcha = (datos.trabajando || [])[0];
  if (!marcha && !datos.en_cola && !datos.esperando) return false;
  const viejo = document.getElementById("tr-velo-cierre"); if (viejo) viejo.remove();
  const p = marcha ? trPaso(marcha) : null;
  const resto = [];
  if (datos.en_cola) resto.push(`${datos.en_cola} en la cola (se ${datos.en_cola === 1 ? "pausa" : "pausan"} igual)`);
  if (datos.esperando) resto.push(`${datos.esperando} esperando tu respuesta (la pregunta se guarda)`);
  const frase = marcha ? "Hay un trabajo en marcha; se pausará y lo podrás reanudar al volver, desde Taller › Trabajos."
    : "Hay trabajos sin terminar; se pausarán y los podrás reanudar al volver, desde Taller › Trabajos.";
  document.body.insertAdjacentHTML("beforeend", `<div class="tr-velo" id="tr-velo-cierre"><div class="tr-dialogo" role="alertdialog" aria-modal="true" aria-labelledby="tr-cerrar-t">
    <h2 id="tr-cerrar-t">¿Cerrar Sopa?</h2>
    <p>${frase}</p>
    ${marcha ? `<div class="tr-fila">${trCara(marcha.agente, "", "trabajando")}<div class="tr-txt"><b>${trE(marcha.encargo)}</b><span>${trE(trNombre(marcha.agente))} · paso ${p.n}${trDeUnos(p)} · lo hecho se guarda</span></div>${trChip("trabajando")}</div>` : ""}
    ${resto.length ? `<p class="tr-pequeno">${marcha ? "También " : ""}${(datos.en_cola || 0) + (datos.esperando || 0) > 1 ? (marcha ? "quedan" : "Quedan") : (marcha ? "queda" : "Queda")} ${trE(resto.join(" y "))}.</p>` : ""}
    <label><input type="checkbox" id="tr-no-preguntar"> No volver a preguntar</label>
    <div class="tr-botones"><button type="button" class="btn texto" id="tr-seguir">Seguir con Sopa abierta</button><button type="button" class="btn primario" id="tr-pausar-cerrar">Pausar y cerrar</button></div></div></div>`);
  const velo = document.getElementById("tr-velo-cierre");
  document.getElementById("tr-seguir").onclick = () => velo.remove();
  document.getElementById("tr-pausar-cerrar").onclick = () => {
    const no = document.getElementById("tr-no-preguntar").checked;
    document.getElementById("tr-pausar-cerrar").disabled = true;
    api().trabajos_cerrar_app(no);
  };
  velo.addEventListener("keydown", (e) => { if (e.key === "Escape") velo.remove(); });
  setTimeout(() => document.getElementById("tr-seguir").focus(), 0);
  return true;
};

// ---------- Eventos del motor ----------
let trRecarga = 0;
function eventoTrabajo(ev) {
  if (!ev) return;
  if (ev.tipo === "trabajos_pausados_al_cerrar") TR.bannerFuera = false;
  const fin = ev.tipo === "trabajo_aviso" && ev.id && ["hecho", "fallido"].includes(ev.estado) && !TR.terminados[ev.id];
  if (fin) {
    TR.terminados[ev.id] = true;
    cargarTrabajos().then(() => { if (trPorId(ev.id)) trAvisoTerminado(trPorId(ev.id)); });
    return;
  }
  clearTimeout(trRecarga);
  trRecarga = setTimeout(cargarTrabajos, 150);
}

// Vista de detalle: la pestaña Trabajos sigue marcada.
if (typeof window.mostrarVista === "function") {
  const trMostrarVista = window.mostrarVista;
  window.mostrarVista = function (n) {
    const r = trMostrarVista.apply(this, arguments);
    if (n === "trabajo") { const p = document.getElementById("pestana-trabajos"); if (p) p.setAttribute("aria-selected", "true"); }
    if (n === "trabajos") TR.detalle = null;
    if (n === "chat") setTimeout(() => { trDecorarSala(); trInterruptor(); }, 0);
    return r;
  };
}
window.addEventListener("pywebviewready", () => setTimeout(cargarTrabajos, 300));
