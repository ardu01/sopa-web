// Copyright (C) 2026 Miguel Rodríguez Saiz
// SPDX-License-Identifier: GPL-3.0-only
// Vídeos creados en este equipo (Wan2.2 con stable-diffusion.cpp). La tarjeta sale bajo la respuesta que lo
// pidió, como Trabajo con progreso, Pausar, Cancelar, Guardar (diálogo de Windows) y Deshacer.
// Mientras se crea, el chat está parado: un pesado a la vez.

const vids = { cache: new Map(), sondeo: 0 };

function vidTamano(b) { return b >= 1e9 ? gbComa(b / 1e9) : `${Math.max(1, Math.round(b / 1e6))} MB`; }
function vidSeg(n) { return String(n).replace(".", ","); }

function tarjetasVideo(h) {
  if (!h || !Array.isArray(h.videos)) return "";
  return h.videos
    .filter((x) => x && /^[a-f0-9]{12}$/.test(String(x.id || "")))
    .map((x) => `<figure class="video-creado" data-video="${esc(x.id)}">${vidCuerpo(vids.cache.get(x.id))}</figure>`)
    .join("");
}

function vidCuerpo(d) {
  if (!d) return `<div class="vid-espera"><span class="vid-texto">Preparando el vídeo…</span></div>`;
  if (d.quitado) return `<div class="vid-espera"><span class="vid-texto">Vídeo quitado.</span></div>`;
  const id = esc(d.id);
  const boton = (a, t) => `<button type="button" class="btn texto" data-vid-accion="${a}" data-id="${id}">${t}</button>`;
  if (d.estado === "en_cola") {
    return `<div class="vid-espera"><span class="vid-texto">En cola: lo creo con ${esc(d.modelo)} (${vidSeg(d.segundos)} s) en cuanto acabe la respuesta.</span>${boton("cancelar", "Cancelar")}</div>`;
  }
  if (d.estado === "creando" || d.estado === "pausado") {
    const pausa = d.estado === "pausado";
    const fase = pausa ? "En pausa" : (d.fase === "montando" ? "Montando el vídeo" : "Creando el vídeo");
    return `<div class="vid-espera"><span class="vid-texto">${fase} · paso ${d.paso || 0} de ${d.pasos} · ${vidSeg(d.segundos)} s · ${esc(d.modelo)}</span>`
      + `<progress class="vid-barra" max="${d.pasos || 1}" value="${d.paso || 0}" aria-label="Progreso del vídeo"></progress>`
      + `<small>${pausa ? "Congelado: la gráfica sigue ocupada hasta que lo reanudes o lo canceles." : "El chat vuelve cuando acabe."}</small>`
      + `<span class="vid-botones">${pausa ? boton("reanudar", "Reanudar") : boton("pausar", "Pausar")}${boton("cancelar", "Cancelar")}</span></div>`;
  }
  const quitar = boton("deshacer", d.estado === "listo" ? "Deshacer" : "Quitar");
  if (d.estado === "listo" && d.src) {
    const guardado = d.guardado ? `<span class="pildora ok">Guardado: ${esc(d.guardado.nombre)}</span>` : "";
    const meta = [d.tamano ? `${d.tamano[0]}×${d.tamano[1]}` : "", `${vidSeg(d.segundos)} s`, d.tardo ? `creado en ${vidSeg(d.tardo)} s` : "", esc(d.modelo)].filter(Boolean).join(" · ");
    return `<video src="${d.src}" controls loop muted playsinline preload="auto" aria-label="${esc(d.descripcion)}"></video>`
      + `<figcaption><span class="vid-desc" title="${esc(d.descripcion)}">${esc(d.descripcion)}</span><small class="meta">${meta}</small>`
      + `<span class="vid-acciones">${guardado}<button type="button" class="btn" data-vid-accion="guardar" data-id="${id}">Guardar</button>${quitar}</span></figcaption>`;
  }
  const texto = d.estado === "cancelado" ? (d.error || "Cancelado.") : (d.error || "No he podido crear el vídeo.");
  return `<div class="vid-espera"><span class="vid-texto">${esc(texto)}</span>${quitar}</div>`;
}

function vidPintar(id) {
  document.querySelectorAll(`figure.video-creado[data-video="${id}"]`).forEach((f) => { f.innerHTML = vidCuerpo(vids.cache.get(id)); });
}

const vidVivo = (d) => d && (d.estado === "en_cola" || d.estado === "creando" || d.estado === "pausado");

async function vidActualizar(id) {
  let r;
  try { r = await api().video_ver(id, true); } catch (_) { return; }
  if (!r) return;
  if (!r.ok) { vids.cache.set(id, r.descartado ? { id, quitado: true } : { id, estado: "error", error: r.error }); vidPintar(id); return; }
  const antes = vids.cache.get(id);
  vids.cache.set(id, r.video);
  if (!antes || antes.estado !== r.video.estado || antes.paso !== r.video.paso || antes.fase !== r.video.fase || (antes.guardado || null) !== (r.video.guardado || null)) vidPintar(id);
}

async function videoHidratar() {
  const ids = new Set();
  document.querySelectorAll("figure.video-creado[data-video]").forEach((f) => ids.add(f.dataset.video));
  for (const id of ids) {
    const d = vids.cache.get(id);
    if (!d || vidVivo(d)) await vidActualizar(id);
    else vidPintar(id);
  }
  clearTimeout(vids.sondeo);
  if ([...ids].some((id) => vidVivo(vids.cache.get(id)))) vids.sondeo = setTimeout(videoHidratar, 1500);
}

async function vidAccion(b) {
  const id = b.dataset.id, que = b.dataset.vidAccion;
  b.disabled = true;
  let r;
  try {
    const a = api();
    r = await ({ guardar: a.video_guardar, deshacer: a.video_deshacer, pausar: a.video_pausar, reanudar: a.video_reanudar, cancelar: a.video_cancelar }[que]).call(a, id);
  } catch (_) { r = null; }
  b.disabled = false;
  if (!r || (!r.ok && !r.cancelado)) {
    const c = $("#aviso-chat");
    if (c) c.innerHTML = aviso("err", esc((r && r.error) || "No he podido hacerlo."));
    return;
  }
  if (r.cancelado) return;
  if (que === "deshacer") {
    vids.cache.set(id, { id, quitado: true });
    vidPintar(id);
    if (r.aviso) { const c = $("#aviso-chat"); if (c) c.innerHTML = aviso("warn", esc(r.aviso)); }
    return;
  }
  await vidActualizar(id);
  videoHidratar();
}

document.addEventListener("click", (e) => {
  const b = e.target.closest && e.target.closest("[data-vid-accion]");
  if (b) { e.preventDefault(); vidAccion(b); }
});

document.addEventListener("DOMContentLoaded", () => {
  const m = $("#mensajes");
  if (m && "MutationObserver" in window) {
    let pendiente = 0;
    new MutationObserver(() => {
      if (pendiente) return;
      pendiente = setTimeout(() => { pendiente = 0; if (document.querySelector("figure.video-creado .vid-espera, figure.video-creado:empty")) videoHidratar(); }, 50);
    }).observe(m, { childList: true, subtree: false });
  }
});

// ---- Ajustes › General › Vídeo ------------------------------------------------------------------------
async function videoPintarAjustes() {
  const ctrl = $("#vid-ctrl"), det = $("#vid-det");
  if (!ctrl || !det) return;
  let r;
  try { r = await api().video_estado(); } catch (_) { return; }
  if (!r || !r.ok) return;
  const d = r.video;
  det.textContent = d.soportado ? `${d.modelo}, en el ${d.variante}, hasta ${d.segundos_max} s.` : "Aún no disponible en este equipo.";
  if (!d.soportado) { ctrl.innerHTML = ""; return; }
  if (d.listo) ctrl.innerHTML = `<span class="pildora ok">Listo</span>`;
  else if (d.descargando) {
    const total = d.progreso + d.bytes_pendientes;
    const pct = total ? Math.min(99, Math.floor(100 * d.progreso / total)) : 0;
    ctrl.innerHTML = `<span class="pildora">Descargando… ${pct} %</span><button type="button" class="btn texto" data-vid-ajuste="cancelar">Cancelar</button>`;
    clearTimeout(vids.ajustes);
    vids.ajustes = setTimeout(videoPintarAjustes, 1500);
  } else {
    ctrl.innerHTML = `${d.error ? `<small class="vid-error">${esc(d.error)}</small>` : ""}<button type="button" class="btn" data-vid-ajuste="activar">Descargar (${esc(vidTamano(d.bytes_pendientes))})</button>`;
  }
}

document.addEventListener("click", async (e) => {
  const b = e.target.closest && e.target.closest("[data-vid-ajuste]");
  if (!b) return;
  b.disabled = true;
  const r = b.dataset.vidAjuste === "activar" ? await api().video_activar() : await api().video_cancelar_descarga();
  if (r && !r.ok) { const c = $("#aviso-ajustes-video"); if (c) c.innerHTML = aviso("err", esc(r.error)); }
  videoPintarAjustes();
});
window.addEventListener("pywebviewready", () => setTimeout(videoPintarAjustes, 500));
