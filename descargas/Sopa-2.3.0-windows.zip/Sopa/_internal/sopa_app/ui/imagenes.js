// Copyright (C) 2026 Miguel Rodríguez Saiz
// SPDX-License-Identifier: GPL-3.0-only
// Imágenes creadas en este equipo (stable-diffusion.cpp). La tarjeta sale bajo la respuesta que la pidió,
// con Guardar (diálogo de Windows) y Deshacer. Mientras se crea, el chat está parado: un pesado a la vez.

const imgs = { cache: new Map(), sondeo: 0 };

function imgTamano(b) { return b >= 1e9 ? gbComa(b / 1e9) : `${Math.max(1, Math.round(b / 1e6))} MB`; }

function tarjetasImagen(h) {
  if (!h || !Array.isArray(h.imagenes)) return "";
  return h.imagenes
    .filter((x) => x && /^[a-f0-9]{12}$/.test(String(x.id || "")))
    .map((x) => `<figure class="imagen-creada" data-imagen="${esc(x.id)}">${imgCuerpo(imgs.cache.get(x.id))}</figure>`)
    .join("");
}

function imgCuerpo(d) {
  if (!d) return `<div class="img-espera"><span class="img-texto">Preparando la imagen…</span></div>`;
  if (d.quitada) return `<div class="img-espera"><span class="img-texto">Imagen quitada.</span></div>`;
  const id = esc(d.id);
  const cancelar = `<button type="button" class="btn texto" data-img-accion="cancelar" data-id="${id}">Cancelar</button>`;
  if (d.estado === "en_cola") {
    return `<div class="img-espera"><span class="img-texto">En cola: la creo con ${esc(d.modelo)} en cuanto acabe la respuesta.</span>${cancelar}</div>`;
  }
  if (d.estado === "creando") {
    return `<div class="img-espera"><span class="img-texto">${d.que === "editar" ? "Editando" : "Creando"} la imagen · paso ${d.paso || 0} de ${d.pasos} · ${esc(d.modelo)}</span>`
      + `<progress class="img-barra" max="${d.pasos || 1}" value="${d.paso || 0}" aria-label="Progreso de la imagen"></progress>`
      + `<small>El chat vuelve cuando acabe.</small>${cancelar}</div>`;
  }
  const quitar = `<button type="button" class="btn texto" data-img-accion="deshacer" data-id="${id}">${d.estado === "lista" ? "Deshacer" : "Quitar"}</button>`;
  if (d.estado === "lista" && d.src) {
    const guardada = d.guardada ? `<span class="pildora ok">Guardada: ${esc(d.guardada.nombre)}</span>` : "";
    const meta = [d.tamano ? `${d.tamano[0]}×${d.tamano[1]}` : "", d.segundos ? `${String(d.segundos).replace(".", ",")} s` : "", esc(d.modelo)].filter(Boolean).join(" · ");
    return `<img src="${d.src}" alt="${esc(d.descripcion)}" width="${d.tamano ? d.tamano[0] : 512}" height="${d.tamano ? d.tamano[1] : 512}">`
      + `<figcaption><span class="img-desc" title="${esc(d.descripcion)}">${esc(d.descripcion)}</span><small class="meta">${meta}</small>`
      + `<span class="img-acciones">${guardada}<button type="button" class="btn" data-img-accion="guardar" data-id="${id}">Guardar</button>${quitar}</span></figcaption>`;
  }
  const texto = d.estado === "cancelada" ? (d.error || "Cancelada.") : (d.error || "No he podido crear la imagen.");
  return `<div class="img-espera"><span class="img-texto">${esc(texto)}</span>${quitar}</div>`;
}

function imgPintar(id) {
  document.querySelectorAll(`figure.imagen-creada[data-imagen="${id}"]`).forEach((f) => { f.innerHTML = imgCuerpo(imgs.cache.get(id)); });
}

async function imgActualizar(id) {
  let r;
  try { r = await api().imagen_ver(id, true); } catch (_) { return; }
  if (!r) return;
  if (!r.ok) { imgs.cache.set(id, r.descartada ? { id, quitada: true } : { id, estado: "error", error: r.error }); imgPintar(id); return; }
  const antes = imgs.cache.get(id);
  imgs.cache.set(id, r.imagen);
  if (!antes || antes.estado !== r.imagen.estado || antes.paso !== r.imagen.paso || (antes.guardada || null) !== (r.imagen.guardada || null)) imgPintar(id);
}

async function imagenesHidratar() {
  const ids = new Set();
  document.querySelectorAll("figure.imagen-creada[data-imagen]").forEach((f) => ids.add(f.dataset.imagen));
  for (const id of ids) {
    const d = imgs.cache.get(id);
    if (!d || d.estado === "en_cola" || d.estado === "creando") await imgActualizar(id);
    else imgPintar(id);
  }
  clearTimeout(imgs.sondeo);
  const vivas = [...ids].some((id) => { const d = imgs.cache.get(id); return d && (d.estado === "en_cola" || d.estado === "creando"); });
  if (vivas) imgs.sondeo = setTimeout(imagenesHidratar, 1500);
}

async function imgAccion(b) {
  const id = b.dataset.id, que = b.dataset.imgAccion;
  b.disabled = true;
  let r;
  try {
    if (que === "guardar") r = await api().imagen_guardar(id);
    else if (que === "deshacer") r = await api().imagen_deshacer(id);
    else r = await api().imagen_cancelar(id);
  } catch (_) { r = null; }
  b.disabled = false;
  if (!r || (!r.ok && !r.cancelado)) {
    const c = $("#aviso-chat");
    if (c) c.innerHTML = aviso("err", esc((r && r.error) || "No he podido hacerlo."));
    return;
  }
  if (r.cancelado) return;
  if (que === "deshacer") {
    imgs.cache.set(id, { id, quitada: true });
    imgPintar(id);
    if (r.aviso) { const c = $("#aviso-chat"); if (c) c.innerHTML = aviso("warn", esc(r.aviso)); }
    return;
  }
  await imgActualizar(id);
  imagenesHidratar();
}

document.addEventListener("click", (e) => {
  const b = e.target.closest && e.target.closest("[data-img-accion]");
  if (b) { e.preventDefault(); imgAccion(b); }
});

document.addEventListener("DOMContentLoaded", () => {
  const m = $("#mensajes");
  if (m && "MutationObserver" in window) {
    let pendiente = 0;
    new MutationObserver(() => {
      if (pendiente) return;
      pendiente = setTimeout(() => { pendiente = 0; if (document.querySelector("figure.imagen-creada .img-espera, figure.imagen-creada:empty")) imagenesHidratar(); }, 50);
    }).observe(m, { childList: true, subtree: false });
  }
});

// ---- Ajustes › General › Imágenes ---------------------------------------------------------------------
// Cada fila es el modelo de siempre. Debajo, la opción «Más calidad, lento en 12 GB» (Qwen): nunca por
// defecto, con un aviso del tamaño total antes de descargar y un interruptor para usarla.
const IMG_LICENCIA_CALIDAD = {
  qwen_image: "Qwen-Image (Qwen, Alibaba) y Qwen2.5-VL 7B Instruct, licencia Apache-2.0.",
  qwen_image_edit: "Qwen-Image-Edit-2511 (Qwen, Alibaba) y Qwen2.5-VL 7B Instruct con su mmproj, licencia Apache-2.0.",
};

function imgFilaCalidad(que, d, o) {
  const id = esc(o.id);
  let ctrl;
  if (!o.soportado) ctrl = `<small>Necesita una gráfica NVIDIA de 12 GB o más.</small>`;
  else if (o.descargando) {
    const total = o.progreso + o.bytes_pendientes;
    const pct = total ? Math.min(99, Math.floor(100 * o.progreso / total)) : 0;
    ctrl = `<span class="pildora">Descargando… ${pct} %</span><button type="button" class="btn texto" data-img-ajuste="cancelar" data-que="${id}">Cancelar</button>`;
  } else if (o.listo) {
    ctrl = `<input type="checkbox" role="switch" class="sw" id="img-usar-${id}" data-img-usar="${id}" data-que="${esc(que)}" aria-label="Usar ${esc(o.modelo)}"${d.elegido === o.id ? " checked" : ""}>`;
  } else if (imgs.confirmar === o.id) {
    const falta = o.bytes_pendientes > o.bytes_total ? ` (con el motor, ${imgTamano(o.bytes_pendientes)} por descargar)` : (o.bytes_pendientes < o.bytes_total ? ` (faltan ${imgTamano(o.bytes_pendientes)})` : "");
    ctrl = `<span class="img-confirma" role="alert">${esc(o.modelo)} ocupa ${imgTamano(o.bytes_total)} en total${falta}. En una gráfica de 12 GB tarda bastante más que ${esc(d.modelo)}.</span>`
      + `<button type="button" class="btn" data-img-ajuste="activar" data-que="${id}">Sí, descargar</button><button type="button" class="btn texto" data-img-ajuste="no">Cancelar</button>`;
  } else {
    ctrl = `${o.error ? `<small class="img-error">${esc(o.error)}</small>` : ""}<button type="button" class="btn" data-img-ajuste="pedir" data-que="${id}">Descargar (${esc(imgTamano(o.bytes_total))})</button>`;
  }
  const uso = o.listo ? (d.elegido === o.id ? `Se usa para ${que === "editar" ? "editar" : "crear"}.` : `Descargado. Ahora se usa ${esc(d.modelo)}.`) : `Opcional. Por defecto se usa ${esc(d.modelo)}.`;
  return `<div class="txt"><b><label for="img-usar-${id}">${esc(o.modelo)}</label></b> <span class="pildora aviso">${esc(o.etiqueta || "")}</span>`
    + `<span>${uso}</span><span class="det-licencia">${esc(IMG_LICENCIA_CALIDAD[o.id] || "")}</span></div><div class="ctrl">${ctrl}</div>`;
}

async function imagenesPintarAjustes() {
  const caja = $("#ajustes-imagenes");
  if (!caja) return;
  let r;
  try { r = await api().imagenes_estado(); } catch (_) { return; }
  if (!r || !r.ok) return;
  const e = r.imagenes;
  let sigue = false;
  for (const que of ["crear", "editar"]) {
    const d = e[que];
    const ctrl = $(`#img-${que}-ctrl`);
    const det = $(`#img-${que}-det`);
    if (!ctrl || !det) continue;
    const otro = (d.opciones || []).find((o) => o.id === d.elegido && o.id !== d.id);
    const donde = e.variante === "procesador" ? "en el procesador" : `en la ${e.variante}`;
    det.textContent = d.soportado ? `${d.modelo}, ${donde}.${otro ? ` Ahora se usa ${otro.modelo}.` : ""}` : "Aún no disponible en este equipo.";
    const filas = $(`#img-${que}-calidad`);
    if (filas) {
      const calidad = (d.opciones || []).filter((o) => o.calidad);
      filas.innerHTML = calidad.map((o) => `<div class="fila-ajuste img-calidad">${imgFilaCalidad(que, d, o)}</div>`).join("");
      if (calidad.some((o) => o.descargando)) sigue = true;
    }
    if (!d.soportado) { ctrl.innerHTML = ""; continue; }
    if (d.listo) ctrl.innerHTML = `<span class="pildora ok">Listo</span>`;
    else if (d.descargando) {
      const total = d.progreso + d.bytes_pendientes;
      const pct = total ? Math.min(99, Math.floor(100 * d.progreso / total)) : 0;
      ctrl.innerHTML = `<span class="pildora">Descargando… ${pct} %</span><button type="button" class="btn texto" data-img-ajuste="cancelar" data-que="${esc(d.id)}">Cancelar</button>`;
      sigue = true;
    } else {
      ctrl.innerHTML = `${d.error ? `<small class="img-error">${esc(d.error)}</small>` : ""}<button type="button" class="btn" data-img-ajuste="activar" data-que="${esc(d.id)}">Descargar (${esc(imgTamano(d.bytes_pendientes))})</button>`;
    }
  }
  clearTimeout(imgs.ajustes);
  if (sigue) imgs.ajustes = setTimeout(imagenesPintarAjustes, 1500);
}

document.addEventListener("click", async (e) => {
  const b = e.target.closest && e.target.closest("[data-img-ajuste]");
  if (!b) return;
  const accion = b.dataset.imgAjuste;
  // «pedir» solo enseña el aviso del tamaño; la descarga empieza con «Sí, descargar».
  if (accion === "pedir" || accion === "no") { imgs.confirmar = accion === "pedir" ? b.dataset.que : null; imagenesPintarAjustes(); return; }
  b.disabled = true;
  const confirmado = imgs.confirmar === b.dataset.que;
  const r = accion === "activar" ? await api().imagenes_activar(b.dataset.que, confirmado) : await api().imagenes_cancelar_descarga(b.dataset.que);
  imgs.confirmar = null;
  if (r && !r.ok) { const c = $("#aviso-ajustes-imagenes"); if (c) c.innerHTML = aviso("err", esc(r.error)); }
  imagenesPintarAjustes();
});

document.addEventListener("change", async (e) => {
  const sw = e.target.closest && e.target.closest("[data-img-usar]");
  if (!sw) return;
  sw.disabled = true;
  const r = await api().imagenes_elegir(sw.dataset.que, sw.checked ? sw.dataset.imgUsar : null);
  if (r && !r.ok) { const c = $("#aviso-ajustes-imagenes"); if (c) c.innerHTML = aviso("err", esc(r.error)); }
  imagenesPintarAjustes();
});
window.addEventListener("pywebviewready", () => setTimeout(imagenesPintarAjustes, 500));
