// Copyright (C) 2026 Miguel Rodríguez Saiz
// SPDX-License-Identifier: GPL-3.0-only
// Voz local: micrófono en el cuadro del chat (whisper.cpp) y «Leer en voz alta» en los mensajes
// (Piper, castellano de España). Todo pasa en este equipo; la grabación no se guarda.
"use strict";

const voz = { grab: null, audio: null, leyendo: -1, sondeo: 0 };
const VOZ_MAX_SEGUNDOS = 120;

function vozTamano(b) { return b >= 1e9 ? gbComa(b / 1e9) : `${Math.max(1, Math.round(b / 1e6))} MB`; }
function vozChip(texto) {
  const c = $("#voz-chip");
  if (!c) return;
  c.textContent = texto || "";
  c.hidden = !texto;
}
function vozAviso(tipo, html, accion) {
  const c = $("#aviso-chat");
  if (c) c.innerHTML = html ? aviso(tipo, html, accion || "") : "";
}

async function vozEstado() {
  try {
    const r = await api().voz_estado();
    return r && r.ok ? r.voz : null;
  } catch (_) { return null; }
}

// ---- activar (descarga con un clic) ---------------------------------------------------------
function vozOfrecer(que, e) {
  const d = e[que];
  if (que === "dictado") {
    if (!d.soportado) { vozAviso("info", "El dictado aún no está disponible en este equipo."); return; }
    vozAviso("info", `Para dictar hace falta descargar <b>${esc(d.modelo)}</b> una vez (${esc(vozTamano(d.bytes_pendientes))}). Funciona con el ${esc(d.variante)} y se queda en este equipo.`,
      `<button type="button" class="btn primario" id="voz-activar-dictado">Descargar (${esc(vozTamano(d.bytes_pendientes))})</button>`);
    $("#voz-activar-dictado").onclick = () => vozActivar("dictado");
  } else {
    const nombre = (d.voces.find((v) => v.id === d.voz) || {}).nombre || d.voz;
    vozAviso("info", `Para leer en voz alta hace falta descargar la voz <b>${esc(nombre)}</b> (castellano de España) y el lector Piper una vez (${esc(vozTamano(d.bytes_pendientes))}).`,
      `<button type="button" class="btn primario" id="voz-activar-lectura">Descargar (${esc(vozTamano(d.bytes_pendientes))})</button>`);
    $("#voz-activar-lectura").onclick = () => vozActivar("lectura");
  }
}

async function vozActivar(que) {
  const r = await api().voz_activar(que);
  if (!r || !r.ok) { vozAviso("err", esc((r && r.error) || "No he podido empezar la descarga.")); return; }
  vozSeguir(que);
}

function vozSeguir(que) {
  clearTimeout(voz.sondeo);
  const paso = async () => {
    const e = await vozEstado();
    if (!e) return;
    const d = e[que];
    if (d.descargando) {
      const total = d.progreso + d.bytes_pendientes;
      const pct = total ? Math.min(99, Math.floor(100 * d.progreso / total)) : 0;
      vozAviso("info", `${que === "dictado" ? "Descargando el dictado" : "Preparando la lectura en voz alta"}… ${pct} %`,
        `<button type="button" class="btn" id="voz-cancelar">Cancelar</button>`);
      $("#voz-cancelar").onclick = () => api().voz_cancelar(que);
      voz.sondeo = setTimeout(paso, 1000);
      return;
    }
    if (d.error) { vozAviso("err", esc(d.error)); return; }
    if (d.listo) vozAviso("ok", que === "dictado" ? "Dictado listo. Pulsa el micrófono y habla." : "Lectura en voz alta lista.");
    if (typeof vozPintarAjustes === "function") vozPintarAjustes();
  };
  paso();
}

// ---- dictado ------------------------------------------------------------------------------------------
function vozWav(trozos, frecuencia) {
  let total = 0;
  for (const t of trozos) total += t.length;
  let datos = new Float32Array(total);
  let p = 0;
  for (const t of trozos) { datos.set(t, p); p += t.length; }
  if (frecuencia !== 16000) {  // remuestreo lineal a 16 kHz si el navegador no lo hizo
    const n = Math.floor(datos.length * 16000 / frecuencia);
    const salida = new Float32Array(n);
    const paso = frecuencia / 16000;
    for (let i = 0; i < n; i++) {
      const x = i * paso, a = Math.floor(x), b = Math.min(a + 1, datos.length - 1);
      salida[i] = datos[a] + (datos[b] - datos[a]) * (x - a);
    }
    datos = salida;
  }
  const buf = new ArrayBuffer(44 + datos.length * 2);
  const v = new DataView(buf);
  const txt = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  txt(0, "RIFF"); v.setUint32(4, 36 + datos.length * 2, true); txt(8, "WAVE"); txt(12, "fmt ");
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true); v.setUint32(24, 16000, true);
  v.setUint32(28, 32000, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); txt(36, "data");
  v.setUint32(40, datos.length * 2, true);
  for (let i = 0; i < datos.length; i++) {
    const s = Math.max(-1, Math.min(1, datos[i]));
    v.setInt16(44 + i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return new Uint8Array(buf);
}

function vozBase64(bytes) {
  let bin = "";
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}

function vozBoton(grabando) {
  const b = $("#chat-microfono");
  if (!b) return;
  b.setAttribute("aria-pressed", grabando ? "true" : "false");
  b.classList.toggle("grabando", !!grabando);
  b.title = grabando ? "Parar y pasar a texto" : "Dictar: pulsa, habla y vuelve a pulsar";
  b.setAttribute("aria-label", grabando ? "Parar el dictado" : "Dictar");
}

async function vozEmpezar() {
  const e = await vozEstado();
  if (!e) { vozAviso("err", "No he podido usar la voz ahora."); return; }
  if (!e.dictado.listo) {
    if (e.dictado.descargando) vozSeguir("dictado"); else vozOfrecer("dictado", e);
    return;
  }
  let flujo;
  try {
    flujo = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true } });
  } catch (_) {
    vozAviso("warn", "No puedo usar el micrófono. En Windows, revisa Configuración › Privacidad y seguridad › Micrófono.");
    return;
  }
  let ctx;
  try { ctx = new AudioContext({ sampleRate: 16000 }); } catch (_) { ctx = new AudioContext(); }
  const fuente = ctx.createMediaStreamSource(flujo);
  const nodo = ctx.createScriptProcessor(4096, 1, 1);
  const trozos = [];
  nodo.onaudioprocess = (ev) => { trozos.push(new Float32Array(ev.inputBuffer.getChannelData(0))); };
  fuente.connect(nodo); nodo.connect(ctx.destination);
  const inicio = Date.now();
  voz.grab = { flujo, ctx, nodo, fuente, trozos, reloj: 0 };
  vozBoton(true);
  vozAviso("", "");
  const tic = () => {
    if (!voz.grab) return;
    const s = Math.floor((Date.now() - inicio) / 1000);
    vozChip(`Escuchando · ${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`);
    if (s >= VOZ_MAX_SEGUNDOS) { vozParar(); return; }
    voz.grab.reloj = setTimeout(tic, 250);
  };
  tic();
}

async function vozParar() {
  const g = voz.grab;
  if (!g) return;
  voz.grab = null;
  clearTimeout(g.reloj);
  try { g.nodo.disconnect(); g.fuente.disconnect(); } catch (_) { /* ya estaba suelto */ }
  g.flujo.getTracks().forEach((t) => t.stop());
  const frecuencia = g.ctx.sampleRate;
  try { await g.ctx.close(); } catch (_) { /* nada */ }
  vozBoton(false);
  if (!g.trozos.length) { vozChip(""); return; }
  vozChip("Pasando a texto…");
  const b = $("#chat-microfono");
  if (b) b.disabled = true;
  try {
    const r = await api().voz_dictar(vozBase64(vozWav(g.trozos, frecuencia)));
    if (!r || !r.ok) { vozAviso("err", esc((r && r.error) || "No he podido pasar la grabación a texto.")); return; }
    const caja = $("#chat-texto");
    const texto = String(r.texto || "").trim();
    if (!texto) { vozAviso("info", "No he entendido nada. Prueba a hablar más cerca del micrófono."); return; }
    caja.value = caja.value.trim() ? caja.value.replace(/\s*$/, " ") + texto : texto;
    caja.dispatchEvent(new Event("input", { bubbles: true }));
    caja.focus();
  } finally {
    if (b) b.disabled = false;
    vozChip("");
  }
}

// ---- leer en voz alta ----------------------------------------------------------------------------
function botonLeerVoz(m, i, etiqueta) {
  if (!m || m.enCurso || !String(m.content || "").trim()) return "";
  const activo = voz.leyendo === i;
  return `<button type="button" class="leer-voz" data-leer="${i}" aria-pressed="${activo}">`
    + `<svg class="i s" aria-hidden="true"><use href="#i-${activo ? "pausa" : "altavoz"}"/></svg>`
    + `${esc(etiqueta || (activo ? "Parar" : "Leer en voz alta"))}</button>`;
}

function vozPararLectura() {
  if (voz.audio) { try { voz.audio.pause(); } catch (_) { /* nada */ } }
  voz.audio = null;
  const antes = voz.leyendo;
  voz.leyendo = -1;
  if (antes >= 0) vozPintarBoton(antes);
}

function vozPintarBoton(i, texto) {
  const b = document.querySelector(`#mensajes .leer-voz[data-leer="${i}"]`);
  if (!b) return;
  const lista = estado.listaPintada || [];
  b.outerHTML = botonLeerVoz(lista[i], i, texto);
}

function alPulsarLeerVoz(ev) {
  const b = ev.target.closest && ev.target.closest(".leer-voz");
  if (!b) return false;
  const i = Number(b.dataset.leer);
  if (voz.leyendo === i) { vozPararLectura(); return true; }
  vozLeer(i);
  return true;
}

async function vozLeer(i) {
  vozPararLectura();
  const m = (estado.listaPintada || [])[i];
  if (!m) return;
  const e = await vozEstado();
  if (!e) { vozAviso("err", "No he podido usar la voz ahora."); return; }
  if (!e.lectura.listo) {
    if (e.lectura.descargando) vozSeguir("lectura"); else vozOfrecer("lectura", e);
    return;
  }
  voz.leyendo = i;
  vozPintarBoton(i, "Preparando…");
  const r = await api().voz_leer(String(m.content || ""));
  if (voz.leyendo !== i) return;
  if (!r || !r.ok) { vozPararLectura(); vozAviso("err", esc((r && r.error) || "No he podido leerlo en voz alta.")); return; }
  const audio = new Audio(`data:${r.tipo || "audio/wav"};base64,${r.audio}`);
  voz.audio = audio;
  audio.onended = () => { if (voz.audio === audio) vozPararLectura(); };
  vozPintarBoton(i);
  try { await audio.play(); } catch (_) { vozPararLectura(); }
}

document.addEventListener("DOMContentLoaded", () => {
  const b = $("#chat-microfono");
  if (b) b.addEventListener("click", () => (voz.grab ? vozParar() : vozEmpezar()));
});

// ---- Ajustes › General › Voz --------------------------------------------------------------------
async function vozPintarAjustes() {
  const sel = $("#voz-elegir");
  if (!sel) return;
  const e = await vozEstado();
  if (!e) return;
  const d = e.dictado, l = e.lectura;
  $("#voz-dictado-det").textContent = d.soportado
    ? `${d.modelo}, en el ${d.variante}. El micrófono del chat pasa lo que dices a texto en este equipo. La grabación no se guarda.`
    : "El dictado aún no está disponible en este equipo.";
  $("#voz-dictado-ctrl").innerHTML = !d.soportado ? "" : d.listo ? `<span class="pildora ok">Listo</span>`
    : d.descargando ? `<span class="pildora">Descargando…</span>`
    : `<button type="button" class="btn" id="voz-ajustes-dictado">Descargar (${esc(vozTamano(d.bytes_pendientes))})</button>`;
  sel.innerHTML = l.voces.map((v) => `<option value="${esc(v.id)}"${v.id === l.voz ? " selected" : ""}>${esc(v.nombre)}</option>`).join("");
  const elegida = l.voces.find((v) => v.id === l.voz);
  $("#voz-licencia").textContent = elegida ? `Licencia de la voz: ${elegida.licencia}` : "";
  $("#voz-lectura-ctrl").innerHTML = l.listo ? `<span class="pildora ok">Lista</span>`
    : l.descargando ? `<span class="pildora">Descargando…</span>`
    : `<button type="button" class="btn" id="voz-ajustes-lectura">Descargar (${esc(vozTamano(l.bytes_pendientes))})</button>`;
  const bd = $("#voz-ajustes-dictado");
  if (bd) bd.onclick = async () => { await api().voz_activar("dictado"); vozPintarAjustes(); vozSeguirAjustes(); };
  const bl = $("#voz-ajustes-lectura");
  if (bl) bl.onclick = async () => { await api().voz_activar("lectura"); vozPintarAjustes(); vozSeguirAjustes(); };
}

function vozSeguirAjustes() {
  setTimeout(async () => {
    const e = await vozEstado();
    vozPintarAjustes();
    if (e && (e.dictado.descargando || e.lectura.descargando)) vozSeguirAjustes();
  }, 1500);
}

document.addEventListener("DOMContentLoaded", () => {
  const sel = $("#voz-elegir");
  if (sel) sel.addEventListener("change", async () => {
    vozPararLectura();
    const r = await api().voz_elegir(sel.value);
    if (r && !r.ok) vozAviso("err", esc(r.error || "No he podido cambiar la voz."));
    vozPintarAjustes();
  });
});
window.addEventListener("pywebviewready", () => setTimeout(vozPintarAjustes, 400));
