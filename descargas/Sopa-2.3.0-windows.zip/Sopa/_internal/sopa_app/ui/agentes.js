// Pestaña Agentes. La lógica vive en Python.
"use strict";
const ag = {
  editando: null,
  carrera: null,
  propuesta: null,
  sobrescribir: false,
  ocupado: false,
  carpetas: [],
  equipo: [],
  avatares: [],
};
const EQUIPO_VISTO = "sopa-equipo-visto";
const ESTADO_EQUIPO = { listo: "Listo", trabajando: "Trabajando", error: "Error" };

function fichaEquipo(id) {
  const lista = (estado && estado.equipo && estado.equipo.length) ? estado.equipo : ag.equipo;
  return (lista || []).find((a) => a.id === (id || "chat")) || null;
}

function htmlAvatar(ficha, vivo) {
  const emoji = (ficha && ficha.emoji) || "🥣";
  const anim = (ficha && ficha.animacion) || "vapor";
  const id = (ficha && ficha.avatar) || "sprout";
  const base = (ficha && ficha.cara) || ("avatares/" + id);
  const grande = vivo === "grande" ? " grande" : "";
  // El emoji es el respaldo. montarAvatares pone la foto fija (también en vistas ocultas) y, en pantalla, el clip.
  return `<span class="avatar avatar-vivo${grande}" data-anim="${esc(anim)}" data-avatar="${esc(id)}" data-cara="${esc(base)}" aria-hidden="true"><span class="avatar-emoji">${esc(emoji)}</span></span>`;
}

function marcarClipAvatar(nodo, el) {
  nodo.classList.add("tiene-clip");
  nodo.replaceChildren(el);
}

function cargarImagenAvatar(nodo, url, alFallar) {
  const img = new Image();
  img.alt = "";
  img.className = "avatar-clip";
  img.onload = () => {
    if (nodo.querySelector("video")) return;
    marcarClipAvatar(nodo, img);
  };
  img.onerror = () => { if (typeof alFallar === "function") alFallar(); };
  img.src = url;
}

function cargarVideoAvatar(nodo, url, poster) {
  const video = document.createElement("video");
  video.className = "avatar-clip";
  video.muted = true;
  video.loop = true;
  video.autoplay = true;
  video.playsInline = true;
  video.preload = "auto";
  video.setAttribute("playsinline", "");
  video.setAttribute("aria-hidden", "true");
  if (poster) video.poster = poster;
  video.addEventListener("loadeddata", () => {
    marcarClipAvatar(nodo, video);
    video.play().catch(() => {});
  }, { once: true });
  video.addEventListener("error", () => {
    if (poster) cargarImagenAvatar(nodo, poster);
  }, { once: true });
  video.src = url;
}

const clipsHilo = [];

function rescatarClipsHilo() {
  clipsHilo.length = 0;
  const caja = document.getElementById("mensajes");
  if (!caja) return;
  caja.querySelectorAll(".avatar-vivo video.avatar-clip").forEach((video) => {
    const nodo = video.closest(".avatar-vivo");
    clipsHilo.push({ id: (nodo && nodo.dataset.avatar) || "", video: video });
    video.remove();
  });
}

function tomarClipHilo(id) {
  const i = clipsHilo.findIndex((c) => c.id === id);
  if (i < 0) return null;
  return clipsHilo.splice(i, 1)[0].video;
}

function soltarClipsHiloSobrantes() {
  clipsHilo.splice(0).forEach((c) => {
    c.video.pause();
    c.video.removeAttribute("src");
    c.video.load();
  });
}

const INTRO_POOL = "avatares/sopa-pool-dive.webm";
let introPoolVista = false;

function reproducirIntroAgentes() {
  if (introPoolVista) return;
  if (estado && estado.e2e) return;
  if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const caja = document.getElementById("intro-agentes");
  const video = document.getElementById("intro-pool");
  if (!caja || !video) return;
  introPoolVista = true;
  const cerrar = () => {
    video.pause();
    video.removeAttribute("src");
    video.load();
    caja.hidden = true;
  };
  video.loop = false;
  video.addEventListener("ended", cerrar, { once: true });
  video.addEventListener("error", cerrar, { once: true });
  caja.hidden = false;
  video.src = INTRO_POOL;
  video.play().catch(cerrar);
}

function avatarEnPantalla(nodo) {
  for (let n = nodo; n && n.nodeType === 1; n = n.parentElement) {
    if (n.hidden) return false;
    const estilo = window.getComputedStyle(n);
    if (estilo.display === "none" || estilo.visibility === "hidden") return false;
  }
  return true;
}

function montarAvatares(raiz) {
  if (!raiz || !raiz.querySelectorAll) return;
  const quieto = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  raiz.querySelectorAll(".avatar-vivo:not([data-listo])").forEach((nodo) => {
    const id = nodo.dataset.avatar || "";
    const base = nodo.dataset.cara || ("avatares/" + id);
    const info = (estado && estado.caras && estado.caras[id]) || null;
    const quietoExt = (info && info.quieto) || "png";
    const png = base + "." + quietoExt;
    const conFoto = nodo.dataset.foto === "1";
    // Vista oculta (Sala o Equipo sin abrir, chips del chat): foto fija ya, sin WebM.
    // Así la cara no se queda en emoji. Al enseñar la vista, mostrarVista vuelve a
    // montar y entonces llega el clip. Siete WebM ocultos eran descodificaciones de más.
    if (!avatarEnPantalla(nodo)) {
      if (!conFoto) {
        nodo.dataset.foto = "1";
        cargarImagenAvatar(nodo, png);
      }
      return;
    }
    nodo.dataset.listo = "1";
    // En la e2e el 27B va en CPU. Un WebM por cara no deja salir el relato.
    if (nodo.closest("#mensajes")) {
      const vivo = tomarClipHilo(id);
      if (vivo) {
        marcarClipAvatar(nodo, vivo);
        vivo.play().catch(() => {});
        return;
      }
    }
    if (quieto || (estado && estado.e2e)) {
      if (!conFoto) cargarImagenAvatar(nodo, png);
      return;
    }
    if (!conFoto) cargarImagenAvatar(nodo, png);
    cargarVideoAvatar(nodo, base + ".webm", png);
  });
  if (raiz.id === "mensajes") soltarClipsHiloSobrantes();
}

function pintarChipsEquipo() {
  const caja = $("#equipo-chat");
  const sel = $("#chat-agente");
  if (!caja || !sel) return;
  const lista = estado.equipo || [];
  if (!lista.length) {
    caja.innerHTML = "";
    return;
  }
  const activo = sel.value || "chat";
  const marca = estado.equipoEstado || "listo";
  caja.innerHTML = lista.map((a) => {
    const elegido = a.id === activo;
    const estadoTexto = elegido ? (ESTADO_EQUIPO[marca] || "Listo") : "";
    return `<button type="button" class="equipo-chip" role="option" data-id="${esc(a.id)}" aria-selected="${elegido ? "true" : "false"}" data-estado="${elegido ? esc(marca) : "listo"}">`
      + htmlAvatar(a)
      + `<span class="textos"><b>${esc(a.nombre)}</b><small>${esc(a.rol || a.descripcion || "")}</small>`
      + (estadoTexto ? `<small class="estado-agente">${esc(estadoTexto)}</small>` : "")
      + `</span></button>`;
  }).join("");
  montarAvatares(caja);
  caja.querySelectorAll(".equipo-chip").forEach((b) => {
    b.onclick = () => {
      sel.value = b.dataset.id;
      estado.equipoEstado = "listo";
      pintarAgenteActivo();
    };
  });
}

function marcarEstadoEquipo(valor) {
  estado.equipoEstado = valor === "trabajando" || valor === "error" ? valor : "listo";
  pintarAgenteActivo();
}

function pintarOnboardingEquipo() {
  const caja = $("#equipo-onboarding");
  if (!caja) return;
  let visto = false;
  try { visto = localStorage.getItem(EQUIPO_VISTO) === "1"; } catch (e) { visto = true; }
  caja.hidden = visto;
}

function cerrarOnboardingEquipo() {
  try { localStorage.setItem(EQUIPO_VISTO, "1"); } catch (e) { /* sin almacén, se vuelve a enseñar */ }
  const caja = $("#equipo-onboarding");
  if (caja) caja.hidden = true;
}

function pintarAgentes() {
  api().agentes_estado().then(pintarEstadoAgentes).catch(() => {
    $("#agentes-aviso").innerHTML = aviso("err", esc("No he podido abrir los agentes."));
  });
}

function pintarEstadoAgentes(r) {
  if (!r) return;
  const avisoCaja = $("#agentes-aviso");
  const permitido = r.permitido !== false && r.ok !== false;
  if (!permitido) {
    avisoCaja.innerHTML = aviso("warn", esc(r.aviso || r.error || "No he podido abrir los agentes."));
  } else if (r.error) {
    avisoCaja.innerHTML = aviso("err", esc(r.error));
  } else {
    avisoCaja.innerHTML = "";
  }
  ag.carpetas = r.carpetas || [];
  pintarPlanAgente(r);
  const cajaPlan = $("#agentes-plan");
  if (cajaPlan && r.habilidades && $("#ag-plan-detalles")) {
    const nombres = Array.isArray(r.habilidades.nombres) ? r.habilidades.nombres : [];
    const texto = nombres.length
      ? `Habilidades locales (${nombres.length}): ${nombres.join(", ")}. Están en este equipo y no salen a la red.`
      : "Habilidades locales: ninguna todavía. Puedes dejar un SKILL.md en la carpeta de datos, sin red.";
    $("#ag-plan-detalles").insertAdjacentHTML("beforeend", `<p class="terciario">${esc(texto)}</p>`);
  }
  ag.equipo = r.equipo || ag.equipo || [];
  ag.avatares = r.avatares || ag.avatares || [];
  if (estado && Array.isArray(r.equipo) && r.equipo.length) estado.equipo = r.equipo;
  if (estado && Array.isArray(r.avatares)) estado.avatares = r.avatares;
  if (estado && r.caras && typeof r.caras === "object") estado.caras = r.caras;
  if (typeof pintarColoresAgentes === "function") pintarColoresAgentes(ag.equipo);
  pintarEquipoPagina();
  pintarSelectorAgentes(r.agentes || []);
  ["agentes-tarea"].forEach((id) => {
    const nodo = document.getElementById(id);
    if (nodo) nodo.classList.toggle("oculto", !permitido);
  });
}

function pintarPlanAgente(r) {
  const caja = $("#agentes-plan");
  if (!caja) return;
  if (!r || r.permitido === false) {
    caja.innerHTML = "";
    return;
  }
  const plan = r.plan;
  const fila = (det, ctrl, extra = "") => `<div class="txt"><b>Modelo del equipo</b><span>${det}</span></div><div class="ctrl">${ctrl}</div>${extra}`;
  if (!r.motor_ligero) {
    caja.innerHTML = fila("Los agentes usan el modelo del chat. No hace falta instalar nada más.", '<span class="secundario-texto">El del chat</span>');
    return;
  }
  if (!plan) {
    caja.innerHTML = fila("Hay un modelo aparte en este equipo, pero no he podido leer sus datos.", '<button type="button" class="btn" id="ag-plan">Volver a leer</button>');
  } else {
    const filas = [
      ["Modelo", plan.modelo],
      ["Cuantización", plan.cuantizacion],
      ["Régimen", plan.regimen],
      ["Estimación", plan.estimacion],
    ].filter((par) => par[1]);
    const lista = filas.map((par) => `<dt>${esc(par[0])}</dt><dd>${esc(par[1])}</dd>`).join("");
    const args = plan.argumentos
      ? `<p class="mono">${esc(plan.argumentos)}</p><small>Argumentos de llama-server. Sopa los enseña y no los lanza.</small>`
      : "";
    const equipo = (r.hardware || []).map((d) => `${esc(d.clave)}: ${esc(d.valor)}`).join(" · ");
    caja.innerHTML = fila("Los agentes usan el modelo del chat. Hay uno aparte, más ligero, para que no esperen.",
      '<span class="secundario-texto">El del chat</span><button type="button" class="btn" id="ag-plan-ver" aria-expanded="false" aria-controls="ag-plan-detalles">Ver detalles</button>',
      `<div class="fila-panel" id="ag-plan-detalles" hidden><dl class="detalles-modelo">${lista}</dl>${args}`
      + (equipo ? `<small>${equipo}</small>` : "")
      + '<div class="fila-botones izquierda"><button type="button" class="btn texto" id="ag-plan">Volver a leer el plan</button></div></div>');
    const ver = $("#ag-plan-ver");
    if (ver) ver.onclick = () => { const d = $("#ag-plan-detalles"); d.hidden = !d.hidden; ver.setAttribute("aria-expanded", d.hidden ? "false" : "true"); };
  }
  const boton = $("#ag-plan");
  if (boton) boton.onclick = async () => {
    const nuevo = await api().agentes_plan();
    if (!nuevo || nuevo.ok === false) {
      $("#agentes-aviso").innerHTML = aviso("err", esc((nuevo && nuevo.error) || "No he podido leer el plan."));
      return;
    }
    pintarPlanAgente({ permitido: true, motor_ligero: nuevo.motor_ligero, plan: nuevo.plan, hardware: nuevo.hardware });
  };
}

function pintarSelectorAgentes(agentes) {
  const sel = $("#ag-elegido");
  if (!sel) return;
  const previo = sel.value;
  sel.innerHTML = agentes.map((a) => `<option value="${esc(a.id)}">${esc(a.nombre)}</option>`).join("");
  if (previo && agentes.some((a) => a.id === previo)) sel.value = previo;
}

function pintarEventosAgente(eventos) {
  const caja = $("#agentes-eventos");
  if (!caja) return;
  const texto = {
    paso: (e) => `Paso ${e.n} de ${e.de}.`,
    herramienta: (e) => e.que || (e.hecho ? "He usado una herramienta." : "No he usado esa herramienta."),
    vista_previa: () => "Hay una vista previa para confirmar.",
    final: (e) => e.texto || "",
  };
  caja.innerHTML = (eventos || []).map((e) => `<small>${esc((texto[e.tipo] || (() => ""))(e))}</small>`).join("");
}

function pintarPropuestaAgente(p) {
  const caja = $("#agentes-propuesta");
  if (!caja) return;
  if (!p || !p.id || p.rechazada) {
    caja.innerHTML = p && p.que ? aviso("info", esc(p.que)) : "";
    return;
  }
  ag.propuesta = p;
  const rutas = (p.rutas || []).map((r) => `<li>${esc(r.donde || "")} ${esc(r.carpeta || "")} / ${esc(r.ruta || "")}</li>`).join("");
  const contenido = p.contenido != null ? `<pre class="vista-previa">${esc(p.contenido)}</pre>` : "";
  // crear_documento: el texto es Markdown; esto dice cómo se maqueta (Word, Excel, PowerPoint o PDF).
  const doc = p.documento && p.documento.texto ? `<p class="propuesta-documento">Se crea como ${esc(p.documento.texto)}.</p>` : "";
  const sobre = p.sobrescribe || ag.sobrescribir
    ? `<p>${esc(p.aviso || "Ya hay algo con ese nombre. Si confirmas otra vez, lo de ahora va a la papelera de reciclaje.")}</p>` : "";
  caja.innerHTML = `<div class="tarjeta propuesta-accion"><b>${esc(p.que || "Tienes una acción para revisar.")}</b>`
    + `<ul>${rutas}</ul>${doc}${contenido}${sobre}`
    + '<div class="fila-botones"><button class="btn texto" type="button" id="ag-no">Cancelar</button>'
    + '<button class="btn primario" type="button" id="ag-si">Confirmar</button></div></div>';
  $("#ag-si").onclick = () => resolverPropuestaAgente(true);
  $("#ag-no").onclick = () => resolverPropuestaAgente(false);
}

async function lanzarAgente(ev) {
  ev.preventDefault();
  if (ag.ocupado) return;
  const ident = $("#ag-elegido").value;
  const tarea = $("#ag-tarea").value.trim();
  if (!ident || !tarea) {
    $("#agentes-aviso").innerHTML = aviso("err", esc("Elige un agente y escribe la tarea."));
    return;
  }
  ag.ocupado = true;
  ag.sobrescribir = false;
  ag.eventos = [];
  $("#agentes-propuesta").innerHTML = "";
  $("#agentes-eventos").innerHTML = aviso("info", "Trabajando…");
  const r = await api().agentes_lanzar(ident, tarea);
  ag.ocupado = false;
  if (!r || r.ok === false) {
    $("#agentes-eventos").innerHTML = "";
    $("#agentes-aviso").innerHTML = aviso("err", esc((r && r.error) || "No he podido lanzarlo."));
    return;
  }
  aplicarResultadoAgente(r);
}

function aplicarResultadoAgente(r) {
  ag.carrera = r.carrera || ag.carrera;
  $("#agentes-aviso").innerHTML = "";
  ag.eventos = (ag.eventos || []).concat(r.eventos || []);
  pintarEventosAgente(ag.eventos);
  if (r.necesita_sobrescribir) {
    ag.sobrescribir = true;
    pintarPropuestaAgente({ ...(ag.propuesta || {}), id: (r.propuesta && r.propuesta.id) || (ag.propuesta && ag.propuesta.id), sobrescribe: true, aviso: r.texto });
    return;
  }
  if (r.estado === "esperando" && r.propuesta) {
    pintarPropuestaAgente(r.propuesta);
    return;
  }
  ag.propuesta = null;
  ag.sobrescribir = false;
  const finales = (ag.eventos || []).filter((e) => e.tipo === "final");
  const ultimo = finales[finales.length - 1];
  const mal = ultimo && (ultimo.motivo === "error" || ultimo.motivo === "rechazo");
  $("#agentes-propuesta").innerHTML = r.texto ? aviso(mal ? "err" : "ok", esc(r.texto)) : "";
}

async function resolverPropuestaAgente(aceptar) {
  if (!ag.carrera || !ag.propuesta || ag.ocupado) return;
  ag.ocupado = true;
  const r = aceptar
    ? await api().agentes_confirmar(ag.carrera, ag.propuesta.id, ag.sobrescribir)
    : await api().agentes_cancelar(ag.carrera, ag.propuesta.id);
  ag.ocupado = false;
  if (!r || r.ok === false) {
    $("#agentes-aviso").innerHTML = aviso("err", esc((r && r.error) || "No he podido hacerlo."));
    return;
  }
  if (!r.necesita_sobrescribir) ag.propuesta = null;
  aplicarResultadoAgente(r);
}

// E07: el subtítulo de la tarjeta es la descripción. El rol solo si no hay descripción. «· tuyo» se queda.
function subtituloTarjeta(a) {
  const desc = String((a && a.descripcion) || "").trim();
  const rol = String((a && a.rol) || "").trim();
  const base = desc || rol;
  if (a && a.propio) return base ? `${base} · tuyo` : "tuyo";
  return base;
}

function pintarEquipoPagina() {
  const caja = $("#equipo-lista");
  if (!caja) return;
  const lista = ag.equipo || [];
  if (!lista.length) {
    caja.innerHTML = "<p>El equipo aparece al abrir esta pantalla.</p>";
    return;
  }
  // Tarjetas como en la maqueta: toda la tarjeta abre el chat; el «…» de la esquina lleva el resto.
  // «+ Nuevo agente» va la última; crear y editar abren el mismo panel (creador.js).
  const nueva = `<button type="button" class="tarjeta-nueva" id="cr-ficha-nueva"><span class="circulo">${svg("nuevo")}</span>Nuevo agente</button>`;
  caja.innerHTML = lista.map((a, n) => {
    const borrar = a.propio
      ? `<div class="menu-sep"></div><button type="button" class="menu-item peligro" role="menuitem" data-borrar-agente="${esc(a.id)}">${svg("borrar")}Borrar agente</button>` : "";
    const encargar = a.propio
      ? `${svg("encargar")}<span>Encargar un trabajo<span class="det">Usa sus herramientas paso a paso</span></span>` : `${svg("encargar")}Encargar un trabajo`;
    return `<div class="tarjeta tarjeta-agente" data-agente="${esc(a.id)}"><button type="button" class="cubre" data-abrir="${esc(a.id)}" aria-label="Abrir chat con ${esc(a.nombre)}"></button>${htmlAvatar(a, "grande")}`
      + `<span class="nombre">${esc(a.nombre)}</span><span class="rol descripcion">${esc(subtituloTarjeta(a))}</span>`
      + `<div class="esquina ancla"><button type="button" class="icono-btn" data-menu="menu-ag-${n}" aria-haspopup="menu" aria-expanded="false" aria-label="Opciones de ${esc(a.nombre)}" title="Opciones">${svg("mas")}</button>`
      + `<div class="menu abajo derecha" id="menu-ag-${n}" role="menu"><button type="button" class="menu-item" role="menuitem" data-abrir="${esc(a.id)}">${svg("chat-abrir")}Abrir chat</button>`
      + `<button type="button" class="menu-item" role="menuitem" data-encargar="${esc(a.id)}">${encargar}</button>`
      + `<button type="button" class="menu-item" role="menuitem" data-equipo="${esc(a.id)}">${svg("editar")}Editar</button>`
      + `<button type="button" class="menu-item" role="menuitem" data-recuerdos="${esc(a.id)}">${svg("recuerdos")}Recuerdos</button>${borrar}</div></div></div>`;
  }).join("") + nueva;
  montarAvatares(caja);
  caja.querySelectorAll("[data-abrir]").forEach((b) => {
    b.onclick = () => entrarEnAgente(b.dataset.abrir);
  });
  caja.querySelectorAll("[data-equipo]").forEach((b) => {
    b.onclick = () => abrirEquipo(b.dataset.equipo);
  });
  caja.querySelectorAll("[data-encargar]").forEach((b) => {
    b.onclick = () => { if (typeof abrirEncargar === "function") abrirEncargar(b.dataset.encargar); };
  });
  caja.querySelectorAll("[data-recuerdos]").forEach((b) => {
    b.onclick = () => { entrarEnAgente(b.dataset.recuerdos); const panel = $("#sala-panel-recuerdos"); if (panel) { panel.hidden = false; pintarRecuerdos(); } };
  });
  caja.querySelectorAll("[data-borrar-agente]").forEach((b) => {
    // Mismo borrado que el pie del creador, con su confirmación en el botón.
    b.onclick = () => { abrirEquipo(b.dataset.borrarAgente); const x = document.getElementById("cr-borrar"); if (x && !x.hidden) { x.focus(); x.click(); } };
  });
  const mas = $("#cr-ficha-nueva");
  if (mas) mas.onclick = () => abrirEquipo(null);
}

function entrarEnAgente(ident) {
  const sel = $("#chat-agente");
  if (sel && [...sel.options].some((o) => o.value === ident)) {
    sel.value = ident;
    if (window.pywebview) sel.dispatchEvent(new Event("change"));
    else if (typeof pintarAgenteActivo === "function") pintarAgenteActivo();
  }
  if (!window.pywebview) {
    document.querySelectorAll(".vista").forEach((v) => v.classList.toggle("visible", v.id === "vista-chat"));
    marcarNav("chat");
    if (typeof pintarMensajes === "function") pintarMensajes();
    return;
  }
  if (typeof mostrarVista === "function") mostrarVista("chat");
}

function textoPreview(texto) {
  const limpio = String(texto || "").replace(/\s+/g, " ").trim();
  if (!limpio) return "";
  return limpio.length > 84 ? limpio.slice(0, 83).trim() + "…" : limpio;
}

// El compositor dice a quién escribes: «Escribe a Documentos…». Sin ficha, «Escribe a Sopa…».
function pintarPlaceholderChat() {
  const t = $("#chat-texto");
  if (!t) return;
  const id = ($("#chat-agente") && $("#chat-agente").value) || "chat";
  const f = typeof fichaEquipo === "function" ? fichaEquipo(id) : null;
  t.placeholder = `Escribe a ${(f && f.nombre) || "Sopa"}…`;
}
function pintarSala() {
  pintarPlaceholderChat();
  const caja = $("#sala-agentes");
  if (!caja) return;
  const lista = (estado.equipo && estado.equipo.length) ? estado.equipo : [];
  const activo = ($("#chat-agente") && $("#chat-agente").value) || "chat";
  const previews = estado.previews || {};
  caja.innerHTML = lista.map((a) => {
    const prev = previews[a.id] || "Aún no habéis hablado";
    const on = a.id === activo;
    return `<button type="button" class="fila-agente sala-item${on ? " activa" : ""}" role="option" data-sala="${esc(a.id)}" data-agente="${esc(a.id)}" aria-selected="${on ? "true" : "false"}">`
      + htmlAvatar(a, true)
      + `<span class="txt sala-textos"><span class="nombre sala-nombre">${esc(a.nombre)}</span>`
      + `<span class="linea sala-preview">${esc(prev)}</span></span></button>`;
  }).join("");
  caja.querySelectorAll("[data-sala]").forEach((b) => {
    b.onclick = () => {
      const sel = $("#chat-agente");
      if (!sel || sel.value === b.dataset.sala) return;
      sel.value = b.dataset.sala;
      sel.dispatchEvent(new Event("change"));
    };
  });
  montarAvatares(caja);
  const quien = $("#sala-quien");
  const ficha = fichaEquipo(activo) || { nombre: "Sopa", rol: "Conversación", emoji: "🥣", animacion: "vapor", avatar: "sprout", cara: "avatares/sprout" };
  if (quien) {
    quien.innerHTML = htmlAvatar(ficha, true) + `<div><h1 class="nombre-quien">${esc(ficha.nombre)}</h1><span class="rol">${esc(ficha.rol || "")}</span></div>`;
    montarAvatares(quien);
  }
  const elegido = caja.querySelector('[aria-selected="true"]');
  if (elegido && elegido.scrollIntoView) elegido.scrollIntoView({ block: "nearest" });
}

function recordarHiloLocal(agente) {
  const id = agente || (($("#chat-agente") && $("#chat-agente").value) || "chat");
  estado.hilos = estado.hilos || {};
  estado.hilos[id] = {
    id: estado.conversacion,
    mensajes: (estado.mensajes || []).slice(),
    documentos: (estado.docs || []).slice(),
    version: estado.versionConv || 0,
  };
  const ultima = [...(estado.mensajes || [])].reverse().find((m) => m.role === "assistant" && String(m.content || "").trim());
  if (ultima) {
    estado.previews = estado.previews || {};
    estado.previews[id] = textoPreview(ultima.content);
  }
  pintarSala();
}

function aplicarHilo(r) {
  estado.conversacion = r.id;
  estado.versionConv = r.version || 0;
  estado.mensajes = r.mensajes || [];
  estado.docs = r.documentos || [];
  const id = r.agente || (($("#chat-agente") && $("#chat-agente").value) || "chat");
  estado.hilos = estado.hilos || {};
  estado.hilos[id] = {
    id: r.id, mensajes: estado.mensajes.slice(), documentos: estado.docs.slice(), version: estado.versionConv,
  };
  if (r.preview) {
    estado.previews = estado.previews || {};
    estado.previews[id] = r.preview;
  }
  if (typeof pintarDocs === "function") pintarDocs();
  if (typeof pintarMensajes === "function") pintarMensajes();
  pintarSala();
}

async function abrirHilo(ident, token) {
  if (typeof api !== "function") return;
  const local = estado.hilos && estado.hilos[ident];
  const r = await api().hilo_abrir(ident);
  if (token !== estado.hiloToken || !r || r.ok === false) return;
  if ((($("#chat-agente") && $("#chat-agente").value) || "chat") !== ident) return;
  // «Nueva» acaba de dejar un hilo vacío. No recuperes el anterior: el 27B se atasca con el prefill.
  if (local && local.fresco && !(local.mensajes || []).length) {
    api().hilo_fijar(ident, local.id);
    return;
  }
  aplicarHilo(r);
  if (typeof adoptarModeloEnUso === "function") adoptarModeloEnUso();
}

async function cargarPreviews() {
  if (typeof api !== "function") return;
  try {
    const r = await api().hilos_resumen();
    estado.previews = estado.previews || {};
    (r && r.hilos || []).forEach((h) => {
      if (h && h.id && h.preview) estado.previews[h.id] = h.preview;
    });
  } catch (e) { /* la lista sigue con lo que haya */ }
  pintarSala();
}

function prepararHilo() {
  estado.hiloToken = (estado.hiloToken || 0) + 1;
  const id = ($("#chat-agente") && $("#chat-agente").value) || "chat";
  const cache = estado.hilos && estado.hilos[id];
  if (cache && cache.id) {
    estado.conversacion = cache.id;
    estado.mensajes = (cache.mensajes || []).slice();
    estado.docs = cache.documentos || [];
    estado.versionConv = cache.version || 0;
    if (typeof pintarDocs === "function") pintarDocs();
    if (typeof pintarMensajes === "function") pintarMensajes();
  }
  abrirHilo(id, estado.hiloToken);
  cargarPreviews();
}

function cambiarAgenteVisible() {
  estado.trasRecarga = false;
  estado.equipoEstado = "listo";
  estado.hiloToken = (estado.hiloToken || 0) + 1;
  const token = estado.hiloToken;
  const sel = $("#chat-agente");
  const id = (sel && sel.value) || "chat";
  estado.agenteTurno = id;
  const panel = $("#sala-panel-recuerdos");
  if (panel && !panel.hidden) pintarRecuerdos();
  const cache = estado.hilos && estado.hilos[id];
  if (cache && cache.id) {
    estado.conversacion = cache.id;
    estado.mensajes = (cache.mensajes || []).slice();
    estado.docs = cache.documentos || [];
    estado.versionConv = cache.version || 0;
    if (typeof pintarDocs === "function") pintarDocs();
    if (typeof pintarMensajes === "function") pintarMensajes();
    pintarSala();
  } else {
    estado.mensajes = [];
    estado.conversacion = null;
    estado.docs = [];
    if (typeof pintarDocs === "function") pintarDocs();
    if (typeof pintarMensajes === "function") pintarMensajes();
    pintarSala();
  }
  if (typeof pintarAgenteActivo === "function") pintarAgenteActivo();
  abrirHilo(id, token);
}

function empezarHilo() {
  estado.trasRecarga = false;
  const agente = ($("#chat-agente") && $("#chat-agente").value) || "chat";
  estado.hiloToken = (estado.hiloToken || 0) + 1;
  estado.mensajes = [];
  estado.docs = [];
  estado.conversacion = "conv-" + Date.now();
  estado.versionConv = 0;
  estado.hilos = estado.hilos || {};
  estado.hilos[agente] = { id: estado.conversacion, mensajes: [], documentos: [], version: 0, fresco: true };
  estado.previews = estado.previews || {};
  estado.previews[agente] = "";
  if (typeof pintarDocs === "function") pintarDocs();
  if (typeof pintarMensajes === "function") pintarMensajes();
  document.querySelectorAll("[data-conv]").forEach((e) => e.classList.remove("activa"));
  pintarSala();
  if (typeof api === "function") api().hilo_fijar(agente, estado.conversacion);
}

async function pintarRecuerdos() {
  const panel = $("#sala-panel-recuerdos");
  if (!panel || panel.hidden) return;
  const id = ($("#chat-agente") && $("#chat-agente").value) || "chat";
  const ficha = fichaEquipo(id);
  const nombre = (ficha && ficha.nombre) || "este agente";
  let r = null;
  try { r = await api().memoria_agente(id); } catch (e) { r = null; }
  const entradas = (r && r.entradas) || [];
  const tope = (r && r.tope_entradas) || 40;
  const topeTexto = (r && r.tope_texto) || 240;
  const estadoHecho = { comprobado: "Comprobado", no_cuadra: "No cuadra", sin_comprobar: "Sin comprobar" };
  const lista = entradas.length
    ? entradas.map((e) => {
      const marca = estadoHecho[e.estado] || "Sin comprobar";
      const ancla = e.ancla ? ` · ancla «${esc(e.ancla)}»` : "";
      return `<li><div class="sala-hecho"><span>${esc(e.texto)}</span><small>${esc(marca)}${ancla}</small></div>`
        + `<span class="sala-hecho-acciones"><button type="button" class="btn texto" data-comprobar="${esc(e.id)}">Comprobar</button>`
        + `<button type="button" class="btn texto" data-olvido="${esc(e.id)}">Quitar</button></span></li>`;
    }).join("")
    : `<li class="sala-vacio">Todavía no hay hechos. En el chat: «Recuerda que…». Luego se pueden comprobar.</li>`;
  panel.innerHTML = `<div class="sala-recuerdos-cabeza"><b>Hechos de ${esc(nombre)}</b><button type="button" class="icono-btn" id="sala-recuerdos-cerrar" aria-label="Cerrar" title="Cerrar">${svg("cerrar")}</button></div>`
    + `<p class="secundario-texto">${entradas.length} de ${tope} hechos. En el turno solo entran los que encajan con la pregunta.</p>`
    + `<ul>${lista}</ul>`
    + `<form id="sala-recuerdo-form" class="fila-botones izquierda"><input class="campo crece" id="sala-recuerdo-texto" maxlength="${topeTexto}" placeholder="Un hecho comprobable…" aria-label="Nuevo hecho"><button class="btn primario" type="submit">Guardar</button></form>`;
  const cerrar = $("#sala-recuerdos-cerrar");
  if (cerrar) cerrar.onclick = () => { panel.hidden = true; };
  panel.querySelectorAll("[data-comprobar]").forEach((b) => {
    b.onclick = () => {
      const li = b.closest("li");
      if (!li || li.querySelector(".sala-comprobar")) return;
      const fila = document.createElement("form");
      fila.className = "sala-comprobar";
      fila.innerHTML = `<input class="campo crece" maxlength="2000" aria-label="Texto para comprobar el hecho" placeholder="Pega un texto donde debería aparecer la ancla"><button class="btn" type="submit">Comprobar</button>`;
      fila.onsubmit = async (ev) => {
        ev.preventDefault();
        const evidencia = fila.querySelector("input").value.trim();
        const hecho = await api().memoria_agente_verificar(id, b.dataset.comprobar, evidencia);
        if (!hecho || hecho.ok === false) {
          $("#aviso-chat").innerHTML = aviso("err", esc((hecho && hecho.error) || "No he podido comprobarlo."));
          return;
        }
        pintarRecuerdos();
      };
      li.append(fila);
      fila.querySelector("input").focus();
    };
  });
  panel.querySelectorAll("[data-olvido]").forEach((b) => {
    b.onclick = async () => {
      await api().memoria_agente_borrar(id, b.dataset.olvido);
      pintarRecuerdos();
    };
  });
  const form = $("#sala-recuerdo-form");
  if (form) form.onsubmit = async (ev) => {
    ev.preventDefault();
    const texto = $("#sala-recuerdo-texto").value.trim();
    if (!texto) return;
    const hecho = await api().memoria_agente_añadir(id, texto);
    if (!hecho || hecho.ok === false) {
      $("#aviso-chat").innerHTML = aviso("err", esc((hecho && hecho.error) || "No he podido guardarlo."));
      return;
    }
    pintarRecuerdos();
  };
}

function alternarRecuerdos() {
  const panel = $("#sala-panel-recuerdos");
  if (!panel) return;
  panel.hidden = !panel.hidden;
  if (!panel.hidden) pintarRecuerdos();
}

function abrirEquipo(ident) {
  // Un solo editor para compañeros y agentes propios: el panel de creador.js.
  if (typeof abrirCreador === "function") abrirCreador(ident || null);
}

(function () {
  const previa = window.mostrarVista;
  if (typeof previa === "function") {
    window.mostrarVista = function (nombre) {
      if (nombre !== "agentes") {
        const intro = document.getElementById("intro-pool");
        const caja = document.getElementById("intro-agentes");
        if (intro) { intro.pause(); intro.removeAttribute("src"); intro.load(); }
        if (caja) caja.hidden = true;
      }
      window.__verAjustesAgente = false;
      previa(nombre);
      if (nombre === "agentes") {
        reproducirIntroAgentes();
        if (window.pywebview) pintarAgentes();
        else if (ag.equipo && ag.equipo.length) pintarEquipoPagina();
      }
    };
    window.__abrirAjustesAgente = async function (id) {
      window.__verAjustesAgente = true;
      previa("agentes");
      reproducirIntroAgentes();
      try {
        pintarEstadoAgentes(await api().agentes_estado());
      } catch (e) { /* la página sigue */ }
      const ficha = id && document.querySelector(`#equipo-lista [data-agente="${id}"]`);
      if (ficha && ficha.scrollIntoView) ficha.scrollIntoView({ block: "nearest" });
    };
  }
  window.addEventListener("pywebviewready", () => {
    const lanzar = $("#agentes-lanzar");
    if (lanzar) lanzar.onsubmit = lanzarAgente;
    const entendido = $("#equipo-entendido");
    if (entendido) entendido.onclick = cerrarOnboardingEquipo;
    const ajustes = $("#sala-ajustes");
    const editarSala = $("#sala-editar");
    const recuerdos = $("#sala-recuerdos");
    if (ajustes) ajustes.onclick = () => window.__abrirAjustesAgente(($("#chat-agente") && $("#chat-agente").value) || "chat");
    const encargarSala = $("#sala-encargar");
    if (encargarSala) encargarSala.onclick = () => { if (typeof abrirEncargar === "function") abrirEncargar(($("#chat-agente") && $("#chat-agente").value) || "chat"); };
    if (editarSala) editarSala.onclick = () => abrirEquipo(($("#chat-agente") && $("#chat-agente").value) || "chat");
    if (recuerdos) recuerdos.onclick = alternarRecuerdos;
    const nueva = $("#chat-nueva");
    if (nueva) nueva.onclick = () => { empezarHilo(); if (typeof pintarMenuModelo === "function") pintarMenuModelo(); };
    const sel = $("#chat-agente");
    if (sel) sel.onchange = () => { cambiarAgenteVisible(); if (typeof pintarMenuConversacion === "function") { pintarMenuConversacion(); pintarHistorial(); pintarMenuModelo(); } };
  });
  document.addEventListener("DOMContentLoaded", () => {
    if (window.pywebview) return;
    const params = new URLSearchParams(location.search);
    if (params.get("tema") === "oscuro" || params.get("tema") === "claro") document.documentElement.dataset.tema = params.get("tema");
    if (params.get("muestra") !== "equipo") return;
    const ver = $("#version");
    if (ver) ver.textContent = "Versión 2.3.0";
    estado.equipo = [
      { id: "chat", nombre: "Sopa", rol: "Conversación", descripcion: "Habla contigo en este equipo.", emoji: "🥣", animacion: "vapor", avatar: "sprout" },
      { id: "director", nombre: "Director", rol: "Coordinador", descripcion: "Entiende el pedido y lo hace, sin quedarse en el plan.", emoji: "🎭", animacion: "saludo", avatar: "saturn", persona: true },
      { id: "codigo", nombre: "Código", rol: "Programar", descripcion: "Escribe y revisa código en este equipo.", emoji: "💻", animacion: "tecleo", avatar: "circuit", persona: true },
      { id: "documentos", nombre: "Documentos", rol: "Leer documentos", descripcion: "Resume, compara y saca datos de PDF, Word y Excel.", emoji: "📄", animacion: "hojeo", avatar: "mirage" },
      { id: "archivos", nombre: "Archivos", rol: "Ordenar carpetas", descripcion: "Ordena, renombra y mueve, y espera tu confirmación.", emoji: "📁", animacion: "orden", avatar: "alloy" },
      { id: "investigacion", nombre: "Investigación", rol: "Buscar y citar", descripcion: "Busca fuera o en tus documentos y cita las fuentes.", emoji: "🔎", animacion: "busqueda", avatar: "proton" },
      { id: "automatizaciones", nombre: "Automatizaciones", rol: "Tareas repetidas", descripcion: "Prepara tareas que se confirman antes de guardarse.", emoji: "⚙️", animacion: "engranaje", avatar: "volt" },
    ];
    estado.agenteTurno = "director";
    estado.equipoEstado = "trabajando";
    const sel = $("#chat-agente");
    if (sel) sel.value = "director";
    estado.mensajes = [
      { role: "user", content: "Programa la pantalla de inicio, entera.", origen: "escritorio" },
      { role: "assistant", content: "Soy Director. Empiezo por el escritorio y te dejo el código en este turno, sin repetir el plan.", agente: "director", agente_nombre: "Director", origen: "escritorio" },
    ];
    ag.equipo = estado.equipo;
    const vista = params.get("vista") === "agentes" ? "agentes" : "chat";
    document.querySelectorAll(".vista").forEach((v) => v.classList.toggle("visible", v.id === "vista-" + vista));
    marcarNav(vista);
    estado.previews = {
      chat: "Puedo ayudarte con lo que tengas en este equipo.",
      director: "Soy Director. Empiezo por el escritorio y te dejo el código en este turno, sin repetir el plan.",
      codigo: "La pantalla de inicio queda en un solo archivo, lista para revisar.",
      documentos: "Puedo resumir un PDF, un Word o un Excel de tus carpetas.",
      archivos: "Dime la carpeta y te enseño el plan antes de mover nada.",
      investigacion: "Puedo buscar y citar las fuentes, si enciendes la web.",
      automatizaciones: "Una tarea se guarda solo después de que la confirmes.",
    };
    pintarChipsEquipo();
    pintarAgenteActivo();
    pintarSala();
    pintarMensajes();
    if (vista === "agentes") {
      pintarEquipoPagina();
      reproducirIntroAgentes();
    }
  });
})();
