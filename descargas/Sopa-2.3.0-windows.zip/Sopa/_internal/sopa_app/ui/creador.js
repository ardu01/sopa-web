// Creador de agentes: un solo panel para crear y editar, compañeros y agentes propios.
// La validación y la escritura viven en Python (agente_guardar). Aquí solo se pinta.
"use strict";
const CR_HERR = [
  ["leer", "Leer", "Abre tus documentos"],
  ["buscar", "Buscar", "En tus documentos y, si lo activas, en la web"],
  ["resumir", "Resumir", "Textos largos y PDF"],
  ["archivos", "Cambiar archivos", "Siempre te pide confirmación"],
];
const CR_HERR_DEFECTO = ["leer", "buscar", "resumir"];
const CR_TOPE = { nombre: 40, rol: 40, descripcion: 200, instrucciones: 4000 };
const CR_TOPE_COMPANERO = { instrucciones: 1500 };
const CR_COMPANEROS = ["chat", "director", "codigo", "documentos", "archivos", "investigacion", "automatizaciones"];
const CR_TEXTO = {
  nombre: "Ponle un nombre para encontrarlo en la Sala.",
  repetido: (n) => `Ya hay un agente que se llama «${n}». Elige otro nombre.`,
  instrucciones: "Escribe al menos una frase sobre cómo quieres que trabaje.",
};
// Dónde sale cada error que manda Python.
const CR_ERROR_EN = {
  nombre: "nombre", rol: "rol", descripcion: "descripcion", instrucciones: "instrucciones",
  avatar: "cara", color: "color", herramientas: "herr", carpetas: "carpetas", modelo: "avanzado",
  modo: "avanzado", motor: "avanzado", max_pasos: "avanzado", max_tokens: "avanzado", _: "general",
};
const cr = {
  editando: null, ficha: null, companero: false, cara: "zen", color: "indigo",
  carpetas: [], modelos: [], colores: [], caras: [], borrar: false, original: false, ocupado: false, modeloChat: null,
};
const crq = (s, r) => (r || document).querySelector(s);

function crLista() {
  if (typeof estado === "object" && estado && Array.isArray(estado.equipo) && estado.equipo.length) return estado.equipo;
  return (typeof ag === "object" && ag && ag.equipo) || [];
}
function crNormal(t) {
  return String(t || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toLowerCase().replace(/\s+/g, " ");
}
function crVarColor(color, ident) {
  if (color) return `var(--ag-c-${color})`;
  if (ident && CR_COMPANEROS.includes(ident)) return `var(--ag-${ident})`;
  return "var(--ag-propio)";
}
function crQuienUsa(cara) {
  return crLista().filter((a) => a.avatar === cara && a.id !== cr.editando);
}

// Color de cada agente con color propio: una regla por data-agente, después de tokens.css.
function pintarColoresAgentes(lista) {
  let st = document.getElementById("cr-colores-agentes");
  if (!st) { st = document.createElement("style"); st.id = "cr-colores-agentes"; document.head.appendChild(st); }
  st.textContent = (lista || crLista())
    .filter((a) => a && /^[a-z0-9-]+$/.test(a.id || "") && /^[a-z]+$/.test(a.color || ""))
    .map((a) => `[data-agente="${a.id}"]{--agente:var(--ag-c-${a.color})}`).join("\n");
}

function montarCreador() {
  if (crq("#cr-panel")) return;
  const html = `
<div class="cr-velo" id="cr-velo" hidden></div>
<aside class="cr-panel" id="cr-panel" role="dialog" aria-modal="true" aria-labelledby="cr-titulo" hidden>
  <header class="cr-cabeza"><div><h2 id="cr-titulo">Nuevo agente</h2><p id="cr-sub"></p></div>
    <button type="button" class="fantasma cr-cerrar" id="cr-cerrar" aria-label="Cerrar">×</button></header>
  <div class="cr-cuerpo" id="cr-cuerpo">
    <form class="cr-form" id="cr-form" novalidate>
      <div class="cr-fila2">
        <div class="cr-campo"><label for="cr-nombre"><span>Nombre<span class="cr-obl" aria-hidden="true">*</span></span><span class="cr-cuenta" data-cuenta="nombre"></span></label>
          <input type="text" id="cr-nombre" maxlength="40" required aria-describedby="cr-err-nombre" placeholder="Ej.: Recetas" autocomplete="off">
          <p class="cr-error" id="cr-err-nombre" hidden></p></div>
        <div class="cr-campo"><label for="cr-rol"><span>Rol corto</span><span class="cr-cuenta" data-cuenta="rol"></span></label>
          <input type="text" id="cr-rol" maxlength="40" placeholder="Ej.: Cocina de diario" autocomplete="off" aria-describedby="cr-err-rol">
          <p class="cr-ayuda">Sale bajo el nombre, en la Sala y en su ficha.</p>
          <p class="cr-error" id="cr-err-rol" hidden></p></div>
      </div>
      <div class="cr-campo"><label for="cr-descripcion"><span>Qué hace</span><span class="cr-cuenta" data-cuenta="descripcion"></span></label>
        <textarea id="cr-descripcion" rows="2" maxlength="200" aria-describedby="cr-err-descripcion" placeholder="Una o dos frases. Ej.: Propone menús con lo que hay en casa."></textarea>
        <p class="cr-error" id="cr-err-descripcion" hidden></p></div>
      <div class="cr-campo"><label for="cr-instrucciones"><span>Instrucciones<span class="cr-obl" id="cr-obl-instr" aria-hidden="true">*</span></span><span class="cr-cuenta" data-cuenta="instrucciones"></span></label>
        <p class="cr-ayuda" id="cr-ayuda-instr">Cómo quieres que trabaje: tono, qué debe preguntarte antes y qué no debe hacer nunca. Se lo recuerda en cada mensaje.</p>
        <textarea id="cr-instrucciones" rows="4" maxlength="4000" aria-describedby="cr-ayuda-instr cr-nota-instr cr-err-instrucciones" placeholder="Ej.: Responde en pasos cortos. Pregunta cuántas personas sois y si hay alergias."></textarea>
        <p class="cr-ayuda" id="cr-nota-instr" hidden>Si lo dejas vacío, usa las de siempre.</p>
        <p class="cr-error" id="cr-err-instrucciones" hidden></p></div>
      <fieldset class="cr-seccion"><legend><span>Cara</span><small><span class="cr-uso-leyenda">●</span> ya la lleva otro agente</small></legend>
        <div class="cr-caras" id="cr-caras" role="radiogroup" aria-label="Cara"></div>
        <p class="cr-error" id="cr-err-cara" hidden></p></fieldset>
      <fieldset class="cr-seccion"><legend><span>Color</span></legend>
        <div class="cr-colores" id="cr-colores" role="radiogroup" aria-label="Color"></div>
        <p class="cr-ayuda cr-aviso-color" id="cr-aviso-color" hidden></p>
        <p class="cr-error" id="cr-err-color" hidden></p></fieldset>
      <fieldset class="cr-capacidades" id="cr-capacidades">
        <p class="cr-ayuda cr-bloqueo" id="cr-bloqueo" hidden>Esto no se cambia en un compañero: sus herramientas, sus carpetas y su modelo vienen de serie.</p>
        <div class="cr-seccion"><p class="cr-etiqueta">Qué puede hacer</p><div class="cr-interruptores" id="cr-herr"></div>
          <p class="cr-ayuda" id="cr-nota-sala">En la Sala solo conversa; sus herramientas se usan en Trabajos.</p>
          <p class="cr-error" id="cr-err-herr" hidden></p></div>
        <div class="cr-seccion"><p class="cr-etiqueta">Carpetas que puede leer <small>Solo las que ya autorizaste</small></p>
          <div class="cr-carpetas" id="cr-carpetas"></div>
          <p class="cr-error" id="cr-err-carpetas" hidden></p></div>
      </fieldset>
      <details class="cr-avanzado" id="cr-avanzado"><summary><span>Avanzado<small id="cr-avanzado-resumen"></small></span></summary>
        <fieldset class="cr-avanzado-cuerpo" id="cr-avanzado-campos">
          <div class="cr-campo"><label for="cr-motor">Motor</label><select id="cr-motor"><option value="llama">El modelo del chat</option><option value="ligero">Motor ligero, si está en este equipo</option></select></div>
          <div class="cr-campo"><label for="cr-modelo">Modelo</label><select id="cr-modelo"></select></div>
          <div class="cr-campo"><label for="cr-modo">Respuestas</label><select id="cr-modo"><option value="">Como el chat</option><option value="rapido">Breves</option><option value="equilibrado">Equilibradas</option><option value="calidad">Con detalle</option></select></div>
          <div class="cr-campo"><label for="cr-pasos"><span>Pasos como máximo</span><span class="cr-cuenta">1–12</span></label>
            <div class="cr-paso"><button type="button" data-menos="cr-pasos" aria-label="Menos pasos">−</button><input type="number" id="cr-pasos" min="1" max="12" value="8"><button type="button" data-mas="cr-pasos" aria-label="Más pasos">+</button></div></div>
          <div class="cr-campo"><label for="cr-tokens"><span>Largo de respuesta</span><span class="cr-cuenta">32–4096 tokens</span></label>
            <div class="cr-paso"><button type="button" data-menos="cr-tokens" aria-label="Menos">−</button><input type="number" id="cr-tokens" min="32" max="4096" step="32" value="1024"><button type="button" data-mas="cr-tokens" aria-label="Más">+</button></div></div>
          <p class="cr-error cr-ancho" id="cr-err-avanzado" hidden></p>
        </fieldset></details>
      <p class="cr-error" id="cr-err-general" hidden></p>
    </form>
    <aside class="cr-vista" aria-label="Vista previa"><p class="cr-kicker">Vista previa</p><div id="cr-ficha"></div>
      <p class="cr-kicker">En la Sala</p><div class="sala-muestra" id="cr-fila"></div>
      <p class="cr-vista-nota" id="cr-vista-nota"></p></aside>
  </div>
  <footer class="cr-pie"><span class="cr-pie-nota" id="cr-pie-nota"><span class="cr-obl">*</span> Obligatorio</span>
    <button type="button" class="fantasma peligro" id="cr-borrar" hidden>Borrar agente</button>
    <button type="button" class="fantasma" id="cr-original" hidden>Volver al original</button>
    <button type="button" class="fantasma" id="cr-cancelar">Cancelar</button>
    <button type="button" class="primario" id="cr-crear">Crear agente</button></footer>
</aside>`;
  document.body.insertAdjacentHTML("beforeend", html);
  crq("#cr-cerrar").onclick = cerrarCreador;
  crq("#cr-cancelar").onclick = cerrarCreador;
  crq("#cr-velo").onclick = cerrarCreador;
  crq("#cr-crear").onclick = guardarCreador;
  crq("#cr-original").onclick = volverAlOriginal;
  crq("#cr-borrar").onclick = borrarDesdeCreador;
  crq("#cr-form").onsubmit = (ev) => { ev.preventDefault(); guardarCreador(); };
  ["nombre", "rol", "descripcion", "instrucciones"].forEach((k) => crq("#cr-" + k).addEventListener("input", () => { crLimpiarError(k); crVista(); }));
  crq("#cr-avanzado").addEventListener("toggle", crResumenAvanzado);
  ["cr-modelo", "cr-pasos", "cr-tokens"].forEach((id) => crq("#" + id).addEventListener("change", crResumenAvanzado));
  document.querySelectorAll("#cr-panel [data-menos], #cr-panel [data-mas]").forEach((b) => {
    b.onclick = () => {
      const i = crq("#" + (b.dataset.menos || b.dataset.mas));
      const paso = Number(i.step) || 1;
      i.value = Math.min(Number(i.max), Math.max(Number(i.min), Number(i.value) + (b.dataset.mas ? paso : -paso)));
      crResumenAvanzado();
    };
  });
  document.addEventListener("keydown", (ev) => {
    if (ev.key === "Escape" && !crq("#cr-panel").hidden) cerrarCreador();
  });
}

function crPintarCaras() {
  crq("#cr-caras").innerHTML = cr.caras.map((c) => {
    const usa = crQuienUsa(c)[0];
    const uso = usa ? `<span class="cr-uso" data-uso-color="${esc(crVarColor(usa.color, usa.id))}" title="La lleva ${esc(usa.nombre)}"></span>` : "";
    return `<button type="button" class="cr-cara" role="radio" data-cara="${esc(c)}" aria-checked="${c === cr.cara}" aria-label="${esc(c)}${usa ? ", la lleva " + esc(usa.nombre) : ""}"><img src="avatares/${esc(c)}.png" alt="">${uso}</button>`;
  }).join("");
  crq("#cr-caras").querySelectorAll("[data-uso-color]").forEach((n) => n.style.setProperty("--uso", n.dataset.usoColor));
  crq("#cr-caras").querySelectorAll("[data-cara]").forEach((b) => {
    b.onclick = () => { cr.cara = b.dataset.cara; crLimpiarError("cara"); crPintarCaras(); crVista(); };
  });
}

function crPintarColores() {
  const opciones = (cr.companero ? [{ id: "", nombre: "El suyo", parecido: null }] : []).concat(cr.colores);
  crq("#cr-colores").innerHTML = opciones.map((c) =>
    `<button type="button" class="cr-color" role="radio" data-color="${esc(c.id)}" aria-checked="${c.id === cr.color}" aria-label="${esc(c.nombre)}" title="${esc(c.nombre)}"></button>`).join("")
    + `<span class="cr-color-nombre">${esc((opciones.find((c) => c.id === cr.color) || { nombre: "" }).nombre)}</span>`;
  crq("#cr-colores").querySelectorAll("[data-color]").forEach((b) => b.style.setProperty("--c", crVarColor(b.dataset.color, cr.editando)));
  crq("#cr-colores").querySelectorAll("[data-color]").forEach((b) => {
    b.onclick = () => { cr.color = b.dataset.color; crLimpiarError("color"); crPintarColores(); crVista(); };
  });
  // Aviso suave: lo decide Python (AVISO_COLOR_PARECIDO); si viene «parecido», se dice y ya.
  const elegido = cr.colores.find((c) => c.id === cr.color);
  const otro = elegido && elegido.parecido && elegido.parecido !== cr.editando ? crLista().find((a) => a.id === elegido.parecido) : null;
  const nota = crq("#cr-aviso-color");
  nota.hidden = !otro;
  nota.textContent = otro ? `Se parece al color de ${otro.nombre}. Puedes usarlo igual.` : "";
}

function crPintarHerr(sel) {
  crq("#cr-herr").innerHTML = CR_HERR.map(([id, n, d]) =>
    `<label class="cr-interruptor"><input type="checkbox" role="switch" value="${id}"${sel.includes(id) ? " checked" : ""}><span><b>${esc(n)}</b><small>${esc(d)}</small></span></label>`).join("");
}

function crPintarCarpetas(sel) {
  const lista = cr.carpetas;
  crq("#cr-carpetas").innerHTML = (lista.length
    ? lista.map((x) => `<label class="cr-carpeta"><input type="checkbox" value="${esc(x.id)}"${sel.includes(x.id) ? " checked" : ""}>${esc(x.nombre)}</label>`).join("")
    : `<span class="cr-ayuda">Aún no hay carpetas autorizadas.</span>`)
    + ` <a href="#" class="cr-enlace" data-cr-ajustes>Autorizar otra en Ajustes</a>`;
  const enlace = crq("#cr-carpetas [data-cr-ajustes]");
  if (enlace) enlace.onclick = (ev) => {
    ev.preventDefault();
    cerrarCreador();
    if (typeof mostrarVista === "function") mostrarVista("ajustes");
    const caja = document.getElementById("carpetas-autorizadas");
    if (caja && caja.scrollIntoView) caja.scrollIntoView({ block: "start" });
  };
}

function crPintarModelos(sel) {
  const lista = cr.modelos;
  const elegido = sel || "";
  const falta = elegido && !lista.some((x) => x.id === elegido) ? `<option value="${esc(elegido)}">${esc(elegido)}</option>` : "";
  const delChat = cr.modeloChat ? `El del chat (${esc(cr.modeloChat)})` : "El del chat";
  crq("#cr-modelo").innerHTML = `<option value="">${delChat}</option>` + falta
    + lista.map((x) => `<option value="${esc(x.id)}">${esc(x.id)}</option>`).join("");
  crq("#cr-modelo").value = elegido;
}

function crPlural(n, uno, varios) { return `${n} ${n === 1 ? uno : varios}`; }

function crResumenAvanzado() {
  const r = crq("#cr-avanzado-resumen");
  if (!r) return;
  if (cr.companero) { r.textContent = crq("#cr-avanzado").open ? "" : "De serie"; return; }
  const sel = crq("#cr-modelo");
  const mod = sel.value || (sel.options[0] ? sel.options[0].textContent : "El del chat");
  const pasos = Number(crq("#cr-pasos").value) || 0;
  r.textContent = crq("#cr-avanzado").open ? "" : `${mod} · ${crPlural(pasos, "paso", "pasos")} · ${crq("#cr-tokens").value} tokens`;
}

function crVista() {
  const nombre = crq("#cr-nombre").value.trim();
  const rol = crq("#cr-rol").value.trim();
  const desc = crq("#cr-descripcion").value.trim();
  const col = crVarColor(cr.color, cr.editando);
  crq("#cr-panel").style.setProperty("--cr-color", col);
  const cara = `<span class="avatar avatar-vivo grande tiene-clip" aria-hidden="true"><img class="avatar-clip" alt="" src="avatares/${esc(cr.cara)}.png"></span>`;
  const nom = nombre ? `<b>${esc(nombre)}</b>` : `<b class="vacio-nombre">Sin nombre</b>`;
  // Sin rol no se inventa uno: la línea queda vacía.
  const rolFicha = rol ? `<small>${esc(rol)}</small>` : "";
  crq("#cr-ficha").innerHTML = `<article class="equipo-ficha">${cara}<div class="equipo-textos">${nom}${rolFicha}<small>${esc(desc || "Aún no habéis hablado")}</small></div>`
    + `<div class="acciones"><button type="button" class="primario" tabindex="-1">Abrir chat</button><button type="button" class="fantasma" tabindex="-1">Editar</button></div></article>`;
  crq("#cr-fila").innerHTML = `<div class="sala-item" aria-selected="true">${cara.replace(" grande", "")}<span class="sala-textos"><span class="sala-nombre">${nombre ? esc(nombre) : "<i>Sin nombre</i>"}</span>${rol ? `<span class="sala-rol">${esc(rol)}</span>` : ""}</span></div>`;
  [crq("#cr-ficha .equipo-ficha"), crq("#cr-fila .sala-item")].forEach((n) => { if (n) n.style.setProperty("--agente", col); });
  Object.keys(CR_TOPE).forEach((k) => {
    const n = crq(`[data-cuenta="${k}"]`);
    const i = crq("#cr-" + k);
    if (n && i) n.textContent = `${i.value.length}/${i.maxLength}`;
  });
}

function crPonerError(donde, texto) {
  const campo = crq("#cr-" + donde);
  const p = crq("#cr-err-" + donde);
  if (campo && campo.matches("input, textarea, select")) campo.setAttribute("aria-invalid", "true");
  if (donde === "avanzado") crq("#cr-avanzado").open = true;
  if (p) { p.textContent = texto; p.hidden = false; }
}
function crLimpiarError(donde) {
  const campo = crq("#cr-" + donde);
  const p = crq("#cr-err-" + donde);
  if (campo) campo.removeAttribute("aria-invalid");
  if (p) { p.hidden = true; p.textContent = ""; }
  if (!document.querySelector("#cr-form .cr-error:not([hidden])")) crNotaPie("");
}
function crLimpiarTodo() {
  ["nombre", "rol", "descripcion", "instrucciones", "cara", "color", "herr", "carpetas", "avanzado", "general"].forEach(crLimpiarError);
}
function crNotaPie(texto) {
  const n = crq("#cr-pie-nota");
  if (!texto) { n.className = "cr-pie-nota"; n.innerHTML = '<span class="cr-obl">*</span> Obligatorio'; return; }
  n.className = "cr-pie-nota err";
  n.textContent = texto;
}

async function abrirCreador(ident) {
  montarCreador();
  let est = null;
  try { est = await api().agentes_estado(); } catch (e) { est = null; }
  if (est && Array.isArray(est.equipo) && est.equipo.length) {
    if (typeof estado === "object" && estado) estado.equipo = est.equipo;
    if (typeof ag === "object" && ag) ag.equipo = est.equipo;
  }
  const a = ident ? crLista().find((x) => x.id === ident) : null;
  cr.editando = a ? a.id : null;
  cr.ficha = a;
  cr.companero = !!(a && !a.propio);
  cr.borrar = false;
  cr.original = false;
  cr.carpetas = (est && est.carpetas) || [];
  cr.colores = (est && est.colores) || [];
  cr.caras = ((est && est.avatares) || (typeof estado === "object" && estado.avatares) || []).map((x) => x.id);
  try { cr.modelos = ((await api().modelos_locales()) || {}).modelos || []; } catch (e) { cr.modelos = []; }
  try { cr.modeloChat = ((await api().modelo_del_chat()) || {}).modelo || null; } catch (e) { cr.modeloChat = null; }
  const nuevo = !a;
  crq("#cr-titulo").textContent = nuevo ? "Nuevo agente" : `Editar a ${a.nombre}`;
  crq("#cr-sub").textContent = nuevo
    ? "Vive en este equipo, con su cara, su color y su propio chat. Puedes cambiarlo cuando quieras."
    : "Los cambios se ven en la Sala al momento. Su chat y sus recuerdos no se tocan.";
  crq("#cr-crear").textContent = nuevo ? "Crear agente" : "Guardar cambios";
  crq("#cr-original").hidden = !cr.companero;
  crq("#cr-borrar").hidden = !(a && a.propio);
  crq("#cr-borrar").textContent = "Borrar agente";
  crq("#cr-original").textContent = "Volver al original";
  // En un compañero las instrucciones pueden quedar vacías: son las de siempre.
  crq("#cr-obl-instr").hidden = cr.companero;
  crq("#cr-nota-instr").hidden = !cr.companero;
  crq("#cr-instrucciones").required = !cr.companero;
  crq("#cr-vista-nota").textContent = nuevo
    ? "Tendrá su propio chat en la Sala. Nada sale de este equipo."
    : "Su chat sigue igual. Nada sale de este equipo.";
  crq("#cr-nombre").value = a ? a.nombre || "" : "";
  crq("#cr-rol").value = a ? a.rol || "" : "";
  crq("#cr-descripcion").value = a ? a.descripcion || "" : "";
  crq("#cr-instrucciones").maxLength = cr.companero ? CR_TOPE_COMPANERO.instrucciones : CR_TOPE.instrucciones;
  crq("#cr-instrucciones").value = a ? a.instrucciones || "" : "";
  cr.cara = a ? a.avatar || "zen" : "zen";
  cr.color = a ? (a.color || (cr.companero ? "" : "indigo")) : "indigo";
  crPintarCaras();
  crPintarColores();
  crPintarHerr(a && a.propio ? (a.herramientas || []) : CR_HERR_DEFECTO);
  crPintarCarpetas(a && a.propio ? (a.carpetas || []) : []);
  crPintarModelos(a && a.propio ? a.modelo : "");
  crq("#cr-motor").value = (a && a.motor) || "llama";
  crq("#cr-modo").value = (a && a.modo) || "";
  crq("#cr-pasos").value = (a && a.max_pasos) || 8;
  crq("#cr-tokens").value = (a && a.max_tokens) || 1024;
  // Compañero: herramientas, carpetas y modelo vienen de serie y no se tocan.
  crq("#cr-avanzado-campos").disabled = cr.companero;
  crq("#cr-capacidades").disabled = cr.companero;
  crq("#cr-avanzado").classList.toggle("cr-bloqueado", cr.companero);
  crq("#cr-bloqueo").hidden = !cr.companero;
  crq("#cr-nota-sala").hidden = cr.companero;
  crq("#cr-avanzado").open = false;
  crLimpiarTodo();
  crResumenAvanzado();
  crVista();
  crq("#cr-velo").hidden = false;
  crq("#cr-panel").hidden = false;
  crq("#cr-cuerpo").scrollTop = 0;
  crq("#cr-nombre").focus({ preventScroll: true });
}

function cerrarCreador() {
  const panel = crq("#cr-panel");
  if (!panel) return;
  panel.hidden = true;
  crq("#cr-velo").hidden = true;
}

function crDatos() {
  const datos = {
    nombre: crq("#cr-nombre").value.trim(),
    rol: crq("#cr-rol").value.trim(),
    descripcion: crq("#cr-descripcion").value.trim(),
    instrucciones: crq("#cr-instrucciones").value.trim(),
    avatar: cr.cara,
    color: cr.color,
  };
  if (cr.companero) return datos;
  return Object.assign(datos, {
    herramientas: [...document.querySelectorAll("#cr-herr input:checked")].map((i) => i.value),
    carpetas: [...document.querySelectorAll("#cr-carpetas input:checked")].map((i) => i.value),
    motor: crq("#cr-motor").value,
    modelo: crq("#cr-modelo").value || null,
    modo: crq("#cr-modo").value || null,
    max_pasos: Number(crq("#cr-pasos").value),
    max_tokens: Number(crq("#cr-tokens").value),
  });
}

function crRevisar(d) {
  const err = {};
  if (!d.nombre) err.nombre = CR_TEXTO.nombre;
  else {
    const mismo = crLista().find((a) => a.id !== cr.editando && crNormal(a.nombre) === crNormal(d.nombre));
    if (mismo) err.nombre = CR_TEXTO.repetido(mismo.nombre);
  }
  if (!d.instrucciones && !cr.companero) err.instrucciones = CR_TEXTO.instrucciones;
  return err;
}

function crEnsenarErrores(err) {
  const claves = Object.keys(err);
  const sitios = [];
  claves.forEach((k) => {
    const donde = CR_ERROR_EN[k] || "general";
    crPonerError(donde, err[k]);
    if (!sitios.includes(donde)) sitios.push(donde);
  });
  crNotaPie(sitios.length === 1 ? "Revisa el campo marcado." : `Revisa los ${sitios.length} campos marcados.`);
  const primero = crq("#cr-err-" + sitios[0]);
  const foco = crq("#cr-" + sitios[0]);
  if (foco && foco.focus) foco.focus({ preventScroll: true });
  if (primero && primero.scrollIntoView) primero.scrollIntoView({ block: "center" });
}

async function guardarCreador() {
  if (cr.ocupado) return;
  crLimpiarTodo();
  const d = crDatos();
  const err = crRevisar(d);
  if (Object.keys(err).length) { crEnsenarErrores(err); return; }
  cr.ocupado = true;
  crq("#cr-crear").disabled = true;
  let r = null;
  try { r = await api().agente_guardar(cr.editando, d); } catch (e) { r = null; }
  cr.ocupado = false;
  crq("#cr-crear").disabled = false;
  if (!r || r.ok === false) {
    crEnsenarErrores((r && r.errores) || { _: (r && r.error) || "No he podido guardar el agente." });
    return;
  }
  const ficha = r.agente;
  const creado = r.creado === true;
  if (Array.isArray(r.agentes)) {
    if (typeof estado === "object" && estado) estado.equipo = r.agentes;
    if (typeof ag === "object" && ag) ag.equipo = r.agentes;
  }
  cerrarCreador();
  await crTrasGuardar(ficha && ficha.id, creado);
  if (typeof toast === "function") toast(creado ? `${ficha.nombre} ya está en tu equipo.` : "Cambios guardados.");
}

async function crTrasGuardar(ident, entrar) {
  if (typeof cargarAgentesChat === "function") await cargarAgentesChat();
  pintarColoresAgentes();
  if (typeof pintarAgentes === "function") pintarAgentes();
  if (typeof pintarSala === "function") pintarSala();
  if (!entrar || !ident) return;
  // Recién creado: a la Sala, elegido y con su hilo (y el saludo) abierto.
  const sel = crq("#chat-agente");
  if (typeof mostrarVista === "function") mostrarVista("chat");
  if (sel && [...sel.options].some((o) => o.value === ident && !o.disabled)) {
    sel.value = ident;
    sel.dispatchEvent(new Event("change"));
  }
}

async function volverAlOriginal() {
  if (!cr.companero || !cr.editando) return;
  const boton = crq("#cr-original");
  if (!cr.original) {
    // La misma confirmación en línea que «Borrar agente».
    cr.original = true;
    boton.textContent = "Sí, volver al original";
    crNotaPie("Pulsa otra vez para volver a como venía. Su chat no se toca.");
    return;
  }
  const r = await api().equipo_restablecer(cr.editando);
  if (!r || r.ok === false) {
    cr.original = false;
    boton.textContent = "Volver al original";
    crEnsenarErrores({ _: (r && r.error) || "No he podido volver al original." });
    return;
  }
  cerrarCreador();
  await crTrasGuardar(cr.editando, false);
  if (typeof toast === "function") toast("Ha vuelto a como venía.");
}

async function borrarDesdeCreador() {
  if (!cr.editando || cr.companero) return;
  const boton = crq("#cr-borrar");
  if (!cr.borrar) {
    // Confirmación en el propio botón, sin ventanas del sistema.
    cr.borrar = true;
    boton.textContent = "Sí, borrar";
    crNotaPie("Pulsa otra vez para borrarlo. No borra archivos de tus carpetas.");
    return;
  }
  const ident = cr.editando;
  const r = await api().agentes_borrar(ident);
  if (!r || r.ok === false) {
    cr.borrar = false;
    boton.textContent = "Borrar agente";
    crEnsenarErrores({ _: (r && r.error) || "No he podido borrarlo." });
    return;
  }
  cerrarCreador();
  const sel = crq("#chat-agente");
  if (sel && sel.value === ident) { sel.value = "chat"; sel.dispatchEvent(new Event("change")); }
  await crTrasGuardar(null, false);
  if (typeof toast === "function") toast("Agente borrado.");
}

window.addEventListener("pywebviewready", () => {
  montarCreador();
  const mas = crq("#cr-mas-sala");
  if (mas) mas.onclick = () => abrirCreador(null);
});
