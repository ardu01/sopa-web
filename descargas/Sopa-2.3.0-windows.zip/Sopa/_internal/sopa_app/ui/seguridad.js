// Copyright (C) 2026 Miguel Rodríguez Saiz
// SPDX-License-Identifier: GPL-3.0-only
// La puerta de seguridad: la tarjeta «Sopa pregunta» en la Sala y Ajustes · Seguridad.
// Nada sale del equipo; la vista previa llega sin claves ni tokens.
const NIVEL_TEXTO = { libre: "Libre", anotada: "Anotada", preguntar: "Preguntar", bloqueada: "Bloqueada" };
let puertaPreguntas = [];
let puertaReloj = null;
let segCargada = null;
let segGuardando = 0;

async function refrescarPuerta(nueva) {
  let r;
  try { r = await api().seguridad_preguntas(); } catch (e) { return; }
  puertaPreguntas = (r && r.preguntas) || [];
  pintarPuerta();
  const sala = $("#vista-chat");
  if (nueva && puertaPreguntas.length && sala && !sala.classList.contains("visible")) {
    toast("Sopa te pregunta algo en la Sala.");
  }
}

function pintarPuerta() {
  const caja = $("#puerta-preguntas");
  if (!caja) return;
  if (!puertaPreguntas.length) {
    caja.innerHTML = "";
    clearInterval(puertaReloj); puertaReloj = null;
    return;
  }
  caja.innerHTML = puertaPreguntas.map((p) => `<div class="tarjeta puerta-pregunta" data-id="${esc(p.id)}" data-etiqueta="${esc(p.etiqueta)}">
    <b>Sopa pregunta: ¿${esc(p.etiqueta)}?</b>
    ${p.vista ? `<pre class="vista-previa">${esc(p.vista)}</pre>` : ""}
    <small>${p.origen === "movil" ? "Lo ha pedido el móvil. " : ""}«Sí» vale solo para esta llamada. «Sí, siempre» recuerda esta herramienta.</small>
    <div class="acciones"><button class="btn primario" type="button" data-puerta="si">Sí</button><button class="btn" type="button" data-puerta="siempre">Sí, siempre</button><button class="btn" type="button" data-puerta="no">No</button>
    <span class="puerta-cuenta" aria-live="off">Quedan ${Number(p.quedan) || 0} s. Sin respuesta es un no.</span></div></div>`).join("");
  caja.querySelectorAll("[data-puerta]").forEach((b) => {
    const cual = b.dataset.puerta;
    b.onclick = () => responderPuerta(b.closest(".puerta-pregunta").dataset.id, cual !== "no", cual === "siempre");
  });
  if (!puertaReloj) puertaReloj = setInterval(() => {
    puertaPreguntas.forEach((p) => { p.quedan = Math.max(0, (Number(p.quedan) || 0) - 1); });
    caja.querySelectorAll(".puerta-pregunta").forEach((t) => {
      const p = puertaPreguntas.find((x) => x.id === t.dataset.id);
      const c = t.querySelector(".puerta-cuenta");
      if (p && c) c.textContent = `Quedan ${p.quedan} s. Sin respuesta es un no.`;
    });
  }, 1000);
}

async function responderPuerta(id, si, siempre) {
  const tarjeta = document.querySelector(`.puerta-pregunta[data-id="${CSS.escape(id)}"]`);
  const etiqueta = tarjeta ? (tarjeta.dataset.etiqueta || "") : "";
  if (tarjeta) tarjeta.querySelectorAll("button").forEach((b) => { b.disabled = true; });
  const r = await api().responder_seguridad(id, si === true, siempre === true);
  if (!r.ok) toast(r.error || "Esa pregunta ya no está abierta.");
  else if (siempre && r.siempre) toast(etiqueta ? `Recordado. «${etiqueta}» ya no vuelve a preguntar.` : "Recordado. Esta herramienta ya no vuelve a preguntar.");
  else if (siempre && !r.siempre) toast(r.aviso || "He aceptado esta llamada, pero no he podido recordarla.");
  refrescarPuerta(false);
  if (siempre && r.ok && r.siempre && typeof pintarSeguridad === "function") pintarSeguridad();
}

function filaSeguridad(h, config) {
  const propio = (config.niveles || {})[h.herramienta] || "";
  const opciones = (h.con_vista ? ["preguntar", "bloqueada"] : ["libre", "anotada", "preguntar", "bloqueada"])
    .map((n) => `<option value="${n}"${propio === n ? " selected" : ""}>${NIVEL_TEXTO[n]}</option>`).join("");
  const notas = [];
  if (h.con_vista) notas.push("Con vista previa");
  if (String(h.regla || "").startsWith("pedir en cada acción")) notas.push("El interruptor pide permiso en cada acción");
  const nota = notas.join(" · ");
  const vigente = h.nivel === h.movil ? NIVEL_TEXTO[h.nivel] : `${NIVEL_TEXTO[h.nivel]} (móvil: ${NIVEL_TEXTO[h.movil]})`;
  return `<div class="fila-ajuste seg-fila"><div class="txt"><b>${esc(h.etiqueta)}</b><span class="seg-nota">${nota ? esc(nota) + " · " : ""}Ahora: <span class="seg-vigente">${esc(vigente)}</span></span></div>
    <div class="ctrl"><div class="selector"><select class="campo" data-seg-herramienta="${esc(h.herramienta)}" aria-label="Nivel de ${esc(h.etiqueta)}">
      <option value=""${propio ? "" : " selected"}>De fábrica (${NIVEL_TEXTO[h.fabrica]})</option>${opciones}</select>${svg("abajo")}</div></div></div>`;
}

function aplicarInterruptores(config) {
  const pedir = (config && config.pedir_cada_accion) || {};
  document.querySelectorAll(".seg-pedir").forEach((caja) => {
    caja.checked = pedir[caja.dataset.grupo] === true;
  });
}

function leerInterruptores() {
  const de = (grupo) => {
    const caja = document.querySelector(`.seg-pedir[data-grupo="${grupo}"]`);
    if (caja) return caja.checked === true;
    const guardado = segCargada && segCargada.pedir_cada_accion;
    return !!(guardado && guardado[grupo] === true);
  };
  return { ordenador: de("ordenador"), escritorio: de("escritorio") };
}

function engancharInterruptores() {
  document.querySelectorAll(".seg-pedir").forEach((caja) => {
    caja.onchange = () => {
      document.querySelectorAll(`.seg-pedir[data-grupo="${caja.dataset.grupo}"]`).forEach((otra) => {
        otra.checked = caja.checked;
      });
      guardarSeguridad();
    };
  });
}

// Permisos por herramienta (Ajustes › Avanzado). Se guarda al cambiar; no hay botón Guardar.
// Lo anotado por Seguridad sale en el registro único de Avanzado, con un solo «Borrar el registro».
async function pintarSeguridad(extra = "") {
  const caja = $("#seg-contenido");
  if (!caja) return;
  let r;
  try { r = await api().seguridad_estado(); } catch (e) { r = { ok: false }; }
  if (segGuardando) return;
  if (!r.ok) { caja.innerHTML = aviso("err", "No he podido leer la seguridad."); return; }
  estado.registroSeguridad = r.registro || [];
  if (typeof pintarRegistroUnico === "function") pintarRegistroUnico();
  const config = r.config || {};
  segCargada = config;
  aplicarInterruptores(config);
  const notas = {
    ordenador: "Estado, captura, ratón y teclado van anotados de fábrica. El interruptor los vuelve a preguntar. Encender, la red y apagar siguen preguntando.",
    escritorio: "Ventanas, captura, ratón y teclado van anotados de fábrica. El interruptor los vuelve a preguntar. Abrir un programa sigue preguntando.",
  };
  const porGrupo = (r.grupos || []).map((g) => {
    const filas = (r.herramientas || []).filter((h) => h.grupo === g.id).map((h) => filaSeguridad(h, config)).join("");
    const nota = notas[g.id] ? `<p class="terciario seg-nota-grupo">${esc(notas[g.id])}</p>` : "";
    return `<h3 class="seg-grupo">${esc(g.etiqueta)} <span class="secundario-texto">· de fábrica ${esc(NIVEL_TEXTO[g.fabrica])}</span></h3>${nota}<div class="seg-lista">${filas}</div>`;
  }).join("");
  caja.innerHTML = `<div id="seg-aviso">${extra}</div>
    <div class="seg-tabla">${porGrupo}</div>
    <div class="seg-reglas formulario">
      <label class="etq" for="seg-plazo">Plazo para responder (segundos)</label><input class="campo" id="seg-plazo" type="number" min="10" max="600" value="${Number(config.plazo_segundos) || 60}">
      <label class="etq" for="seg-denegar">Denegar siempre (una por línea, p. ej. <code>movil/borrar</code>)</label><textarea class="campo area" id="seg-denegar" rows="3">${esc((config.denegar || []).join("\n"))}</textarea>
      <label class="etq" for="seg-permitir">Permitir sin preguntar (una por línea)</label><textarea class="campo area" id="seg-permitir" rows="3">${esc((config.permitir || []).join("\n"))}</textarea>
    </div>`;
  caja.querySelectorAll("[data-seg-herramienta]").forEach((s) => s.onchange = guardarSeguridad);
  ["#seg-plazo", "#seg-denegar", "#seg-permitir"].forEach((id) => { const el = $(id); if (el) el.onchange = guardarSeguridad; });
  const avisoInterruptor = $("#seg-interruptor-aviso");
  if (avisoInterruptor && extra) avisoInterruptor.innerHTML = extra;
}

function lineasSeguridad(sel) {
  return String($(sel).value || "").split(/[\n,]+/).map((t) => t.trim()).filter(Boolean);
}

function configDesdePantalla() {
  const niveles = {};
  const selects = document.querySelectorAll("[data-seg-herramienta]");
  if (selects.length) selects.forEach((s) => { if (s.value) niveles[s.dataset.segHerramienta] = s.value; });
  else if (segCargada && segCargada.niveles) Object.assign(niveles, segCargada.niveles);
  const plazoEl = $("#seg-plazo");
  return {
    plazo_segundos: plazoEl ? (Number(plazoEl.value) || 60) : (Number(segCargada && segCargada.plazo_segundos) || 60),
    niveles,
    denegar: $("#seg-denegar") ? lineasSeguridad("#seg-denegar") : ((segCargada && segCargada.denegar) || []),
    permitir: $("#seg-permitir") ? lineasSeguridad("#seg-permitir") : ((segCargada && segCargada.permitir) || []),
    pedir_cada_accion: leerInterruptores(),
  };
}

async function guardarSeguridad() {
  if (!segCargada && !document.querySelector("[data-seg-herramienta]")) {
    try {
      const leido = await api().seguridad_estado();
      if (leido && leido.ok) segCargada = leido.config || {};
    } catch (e) { /* se guarda con lo que haya en pantalla */ }
  }
  segGuardando++;
  let r;
  try {
    r = await api().guardar_seguridad(configDesdePantalla());
  } catch (e) {
    r = { ok: false, error: "No he podido guardarlo." };
  } finally {
    segGuardando--;
  }
  if (r && r.ok) segCargada = r.config || segCargada;
  aplicarInterruptores(segCargada || {});
  const mensaje = r && r.ok
    ? aviso("ok", "Guardado. Se aplica a la próxima llamada.")
    : aviso("err", esc((r && r.error) || "No he podido guardarlo."));
  const cajaAviso = $("#seg-interruptor-aviso");
  if (cajaAviso) cajaAviso.innerHTML = mensaje;
  if ($("#seg-contenido")) pintarSeguridad(mensaje);
}

async function cargarInterruptores() {
  if (segGuardando) return;
  try {
    const r = await api().seguridad_estado();
    if (segGuardando || !r || !r.ok) return;
    segCargada = r.config || {};
    aplicarInterruptores(segCargada);
  } catch (e) { /* Ajustes lo reintenta al abrirse */ }
}

engancharInterruptores();
window.addEventListener("pywebviewready", () => {
  refrescarPuerta(false);
  cargarInterruptores();
});
