// Interfaz de Sopa. Toda la lógica pesada vive en Python (window.pywebview.api).
"use strict";
window.__errores = [];
window.addEventListener("error", (e) => window.__errores.push(String(e.message)));
window.addEventListener("unhandledrejection", (e) => window.__errores.push(String(e.reason)));
const $ = (s) => document.querySelector(s);
const api = () => window.pywebview.api;
const esc = (t) => String(t ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const TEXTO_CHAT = { gpu: "En la gráfica", mixto: "Gráfica + memoria", cpu: "En el procesador (lento)", no: "No cabe" };
const TEXTO_ESP = { chat: "Charlar", razonamiento: "Razonar", codigo: "Programar", documentos: "Documentos", rapido: "Rápido", vision: "Imágenes" };
const TEXTO_PERS = { si: "Sí", justo: "Justo", no: "No" };
const TEXTO_VERIF = { verificado: "Verificado", estimado: "Estimado", no_soportado: "No soportado" };
const TEXTO_FUNC = { verificado: "Verificado en equipo real", ci: "Probado en pruebas automáticas", pendiente: "Pendiente de probar" };
const ICONO = { ok: "ok", warn: "aviso", err: "error", info: "info" };
const svg = (n) => `<svg class="i" aria-hidden="true"><use href="#i-${n}"/></svg>`;
const aviso = (tipo, texto, accion = "", icono = ICONO[tipo]) => `<div class="aviso ${tipo}">${svg(icono)}<div>${texto}</div>${accion ? `<span class="accion">${accion}</span>` : ""}</div>`;
const vacio = (icono, titulo, texto, extra = "") => `<div class="vacio">${svg(icono)}<h3>${esc(titulo)}</h3><p>${esc(texto)}</p>${extra}</div>`;
function toast(texto) {
  const t = $("#toast"); t.innerHTML = svg("ok") + `<span>${esc(texto)}</span>`; t.classList.remove("oculto");
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.add("oculto"), 5000);
}
function fallo(caja, texto) { $(caja).innerHTML = aviso("err", esc(texto)); }
let estado = { docs: [],  info: null, cursor: 0, mensajes: [], conversacion: null, versionConv: 0, ocupadoMovil: false, datos: null, equipo: [], equipoEstado: "listo", agenteTurno: "chat", trasRecarga: true, eleccionDeEstaPagina: false, modeloEnUso: null };

window.sopaEvento = function (ev) {
  if (!ev || !ev.tipo) return;
  if (ev.tipo === "puerta_pregunta" || ev.tipo === "puerta_respondida") {
    if (typeof refrescarPuerta === "function") refrescarPuerta(ev.tipo === "puerta_pregunta");
    return;
  }
  if (ev.tipo === "trabajo_cambio" || ev.tipo === "trabajo_aviso" || ev.tipo === "trabajos_pausados_al_cerrar") {
    if (typeof eventoTrabajo === "function") eventoTrabajo(ev);
    return;
  }
  if (ev.tipo === "modelo_cargando") marcarMotor(ev.texto || "Sopa está cargando el modelo, un momento…");
  if (ev.tipo === "comparar_trozo" && ev.texto != null) {
    const caja = ev.lado === "personalizado" ? $("#comparar-mio") : $("#comparar-base");
    if (caja) caja.textContent = String(ev.texto);
    return;
  }
  if (ev.tipo === "chat_ocupado" && ev.origen === "movil") marcarMotor("Escribiendo desde el móvil…");
  if (ev.tipo === "chat_libre") {
    marcarMotor("");
    if (typeof pulsarAprender === "function") pulsarAprender();
  }
  if (ev.tipo === "aprender_listo" && typeof pintarAprender === "function") pintarAprender();
  if (ev.tipo === "imagen_estado" && typeof imagenesHidratar === "function") imagenesHidratar();
  if (ev.tipo === "video_estado" && typeof videoHidratar === "function") videoHidratar();
  if (ev.tipo === "modelo_cambiado" && ev.modelo) {
    estado.modeloChat = ev.modelo;
    const sel = $("#chat-modelo");
    if (sel) for (const o of sel.options) {
      if (o.value.endsWith("/" + ev.modelo + ".gguf") || o.value.endsWith("\\" + ev.modelo + ".gguf") || o.textContent.startsWith(ev.modelo)) sel.value = o.value;
    }
    // El botón tiene que decir el modelo que acaba de cargar, no el del catálogo.
    if (typeof refrescarModeloEnUso === "function") {
      refrescarModeloEnUso().then(() => { if (typeof pintarMenuModelo === "function") pintarMenuModelo(); });
    }
  }
  if ((ev.tipo === "conv_creada" || ev.tipo === "conv_borrada" || ev.tipo === "conv_mensaje" || ev.tipo === "conv_fin") && $("#vista-chat") && $("#vista-chat").classList.contains("visible")) {
    if (ev.tipo !== "conv_mensaje" || ev.origen === "movil") cargarModelosChat();
  }
  if (ev.tipo === "conv_plan" && ev.origen === "escritorio" && ev.id && ev.id === estado.conversacion) {
    pintarPlan(ev.pasos);
    return;
  }
  if (ev.tipo === "conv_estado" && ev.origen === "escritorio" && ev.id && ev.id === estado.conversacion) {
    // Un «Calculando» que llegue después de Parar no vuelve a pintar la línea.
    if (!estado.enviando) return;
    pintarEstado(ev.texto);
    return;
  }
  if (ev.tipo === "conv_progreso" && ev.origen === "escritorio" && ev.id && ev.id === estado.conversacion) {
    pintarProgreso(ev);
    return;
  }
  if (ev.tipo === "conv_trozo" && ev.origen === "escritorio" && estado.enviando && ev.id && ev.id === estado.conversacion && ev.texto != null) {
    const cajaEstado = $("#chat-estado");
    if (cajaEstado && cajaEstado.textContent === "Preparando la respuesta…") pintarEstado("");
    const ultimo = estado.mensajes[estado.mensajes.length - 1];
    if (ultimo && ultimo.role === "assistant" && !ultimo.enCurso) return;
    const visible = String(ev.texto);
    if (!visible.trim()) {
      if (ultimo && ultimo.enCurso) ultimo.content = "";
      pintarMensajes(true);
      return;
    }
    const pintado = estado.prefijoContinuar ? estado.prefijoContinuar + visible : visible;
    if (!ultimo || ultimo.role !== "assistant" || !ultimo.enCurso) {
      const ficha = typeof fichaEquipo === "function" ? fichaEquipo(estado.agenteTurno) : null;
      estado.mensajes.push({ role: "assistant", content: pintado, origen: "escritorio", enCurso: true, agente: estado.agenteTurno || "chat", agente_nombre: ficha && ficha.nombre });
    } else {
      ultimo.content = pintado;
    }
    aplazarPintado(false);
    return;
  }
  if (ev.id && ev.id === estado.conversacion && ev.origen === "movil") {
    if (ev.tipo === "conv_trozo" && ev.texto != null) {
      const ultimo = estado.mensajes[estado.mensajes.length - 1];
      if (!ultimo || ultimo.role !== "assistant") estado.mensajes.push({ role: "assistant", content: "", origen: "movil" });
      estado.mensajes[estado.mensajes.length - 1].content = ev.texto;
      if (ev.version) estado.versionConv = ev.version;
      pintarMensajes(true);
    } else if (ev.version && ev.version > (estado.versionConv || 0)) {
      recargarConversacion(ev.id);
    }
  }
};

function marcarMotor(texto) {
  estado.ocupadoMovil = !!texto;
  const campo = $("#chat-texto");
  const enviar = $("#chat-enviar");
  if (campo) campo.disabled = !!texto;
  if (enviar) enviar.disabled = !!texto;
  const caja = $("#aviso-chat");
  if (!caja) return;
  if (texto) caja.innerHTML = aviso("info", texto);
  else if (caja.textContent.includes("Escribiendo desde el móvil") || caja.textContent.includes("cargando el modelo")) caja.innerHTML = "";
}

async function recargarConversacion(id) {
  const r = await api().conversacion(id);
  if (!r || !r.ok || r.id !== estado.conversacion) return;
  estado.versionConv = r.version || estado.versionConv;
  estado.mensajes = r.mensajes || [];
  estado.docs = r.documentos || [];
  if (typeof pintarDocs === "function") pintarDocs();
  pintarMensajes(estado.ocupadoMovil);
}

// Una sola regla para la marca del menú: cada vista pertenece a una sección.
// El Equipo (crear y editar agentes) vive en el Taller; la Sala es para conversar. Trabajos, también en el Taller.
// Lo tuyo agrupa Documentos y Memoria. El registro del motor vive en Ajustes › Avanzado.
const SECCION_DE = { chat: "sala", agentes: "taller", modelos: "taller", personalizar: "taller", comparar: "taller", diseno3d: "taller", trabajos: "taller", trabajo: "taller",
  documentos: "lotuyo", memoria: "lotuyo", registro: "ajustes" };
// Entrenamiento, Comparar y Diseño 3D van en «Más» del Taller.
const VISTAS_MAS = ["personalizar", "comparar", "diseno3d"];
function marcarNav(nombre) {
  const seccion = SECCION_DE[nombre] || nombre;
  document.querySelectorAll(".lateral [data-vista]").forEach((b) => {
    const activa = (b.dataset.seccion || b.dataset.vista) === seccion;
    b.classList.toggle("activa", activa);
    if (activa) b.setAttribute("aria-current", "page"); else b.removeAttribute("aria-current");
  });
  document.querySelectorAll(".pestanas").forEach((p) => {
    p.classList.toggle("visible", p.id === "pestanas-" + seccion);
    p.querySelectorAll("[role=tab]").forEach((t) => {
      const elegida = t.id === "pestana-mas" ? VISTAS_MAS.includes(nombre) : t.dataset.vista === nombre;
      t.setAttribute("aria-selected", elegida ? "true" : "false");
    });
  });
  document.querySelectorAll("#menu-mas-taller [data-vista]").forEach((m) => {
    if (m.dataset.vista === nombre) m.setAttribute("aria-current", "page"); else m.removeAttribute("aria-current");
  });
  const principal = $("#contenido");
  if (principal) principal.classList.toggle("con-pestanas", seccion === "taller" || seccion === "lotuyo");
}

// Menús «…» y desplegables: un botón con data-menu abre el elemento con ese id.
// Se cierran al pulsar fuera, con Escape o con un botón data-cerrar.
function cerrarMenus(salvo) {
  document.querySelectorAll(".menu.abierto").forEach((m) => { if (m !== salvo) m.classList.remove("abierto"); });
  document.querySelectorAll("[data-menu][aria-expanded='true']").forEach((b) => {
    if (!salvo || b.dataset.menu !== salvo.id) b.setAttribute("aria-expanded", "false");
  });
}
function abrirMenu(id) {
  const m = document.getElementById(id);
  if (!m) return;
  cerrarMenus(m);
  m.classList.add("abierto");
  document.querySelectorAll(`[data-menu="${id}"]`).forEach((b) => b.setAttribute("aria-expanded", "true"));
  const primero = m.querySelector("textarea, select, .menu-item:not([disabled])");
  if (primero && typeof primero.focus === "function") primero.focus({ preventScroll: true });
}
function enlazarMenus() {
  document.addEventListener("click", (e) => {
    const b = e.target.closest("[data-menu]");
    if (b) {
      e.preventDefault();
      if (b.disabled) return;
      const m = document.getElementById(b.dataset.menu);
      if (m && m.classList.contains("abierto")) cerrarMenus(); else abrirMenu(b.dataset.menu);
      return;
    }
    const dentro = e.target.closest(".menu");
    if (!dentro || e.target.closest("[data-cerrar]") || (e.target.closest(".menu-item") && dentro.getAttribute("role") === "menu")) cerrarMenus();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && document.querySelector(".menu.abierto")) {
      const abierto = document.querySelector(".menu.abierto");
      cerrarMenus();
      const b = abierto && document.querySelector(`[data-menu="${abierto.id}"]`);
      if (b) b.focus();
    }
  });
}

function mostrarVista(nombre) {
  document.querySelectorAll(".vista").forEach((v) => v.classList.toggle("visible", v.id === "vista-" + nombre));
  marcarNav(nombre);
  if (typeof montarAvatares === "function") montarAvatares(document.getElementById("vista-" + nombre));
  if (nombre === "modelos") { cargarCatalogo(); cargarLocales(); }
  if (nombre === "chat") cargarModelosChat();
  if (nombre === "documentos") cargarDocumentos();
  if (nombre === "personalizar") cargarModelosPersonalizar();
  if (nombre === "comparar") cargarComparar();
  if (nombre === "diseno3d" && typeof cargarDiseno3d === "function") cargarDiseno3d();
  if (nombre === "trabajos" && typeof cargarTrabajos === "function") cargarTrabajos();
  if (nombre === "memoria") cargarMemoria();
  if (nombre === "ajustes") { pintarCodigoProbador(); pintarMovil(); pintarActualizaciones(); pintarCarpetas(); pintarAutomatizaciones(); pintarGrafica(); pintarBuscarWeb(); pintarComprobar(); if (typeof pintarContextoLargo === "function") pintarContextoLargo(); if (typeof pintarSeguridad === "function") pintarSeguridad(); }
}

function aplicarTema(tema) {
  document.documentElement.dataset.tema = tema;
  const grupo = $("#tema");
  if (!grupo) return;
  grupo.dataset.valor = tema;
  grupo.querySelectorAll("[data-valor]").forEach((b) => b.setAttribute("aria-pressed", b.dataset.valor === tema ? "true" : "false"));
}

function tarjeta(titulo, valor, detalle) {
  return `<div class="tarjeta dato"><div class="etiqueta">${esc(titulo)}</div><div class="valor">${esc(valor)}</div><div class="nota">${esc(detalle || "")}</div></div>`;
}
const decimal = (n, d = 1) => Number(n || 0).toFixed(d).replace(".", ",");
// Tamaño en GB con coma decimal y sin ceros de más: 2.33 → «2,33 GB», 0.9 → «0,9 GB», 4 → «4 GB».
// Un campo en la misma fila, en lugar de prompt(): Intro guarda, Esc o «Cancelar» lo deja como estaba.
// Devuelve el texto escrito (sin espacios a los lados) o null si se cancela o se deja vacío.
function editarEnLinea(caja, { valor = "", etiqueta = "Nombre", boton = "Guardar", nota = "", multilinea = false } = {}) {
  return new Promise((resolver) => {
    if (!caja) { resolver(null); return; }
    const antes = caja.innerHTML;
    caja.classList.add("editando");
    const campo = multilinea ? `<textarea class="campo" rows="2" aria-label="${esc(etiqueta)}"></textarea>` : `<input type="text" class="campo" aria-label="${esc(etiqueta)}" autocomplete="off">`;
    caja.innerHTML = `<form class="en-linea">${nota ? `<span class="en-linea-nota">${esc(nota)}</span>` : ""}<span class="en-linea-fila">${campo}<button type="submit" class="btn primario">${esc(boton)}</button><button type="button" class="btn texto" data-en-linea-cancelar>Cancelar</button></span></form>`;
    const f = caja.querySelector("form.en-linea"), c = f.querySelector(".campo");
    c.value = valor;
    c.focus();
    if (c.select) c.select();
    let hecho = false;
    const fin = (v) => { if (hecho) return; hecho = true; caja.innerHTML = antes; caja.classList.remove("editando"); resolver(v); };
    f.onsubmit = (ev) => { ev.preventDefault(); const v = c.value.trim(); fin(v || null); };
    f.querySelector("[data-en-linea-cancelar]").onclick = () => fin(null);
    c.onkeydown = (ev) => {
      if (ev.key === "Escape") { ev.preventDefault(); ev.stopPropagation(); fin(null); }
      else if (multilinea && ev.key === "Enter" && !ev.shiftKey) { ev.preventDefault(); f.requestSubmit(); }
    };
  });
}
const gbComa = (n) => `${String(Math.round(Number(n || 0) * 100) / 100).replace(".", ",")} GB`;

async function cargarInicio() {
  const r = await api().info();
  estado.info = r;
  if ($("#version")) $("#version").textContent = `Versión ${r.version}${r.beta ? " beta" : ""}`;
  aplicarTema(r.ajustes.tema || "sistema");
  aplicarBuscarWeb(r.ajustes.buscar_web === true);
  const h = r.hardware;
  const gpu = h.gpus[0];
  $("#hardware").innerHTML =
    tarjeta("Procesador", `${h.nucleos} núcleos`, h.cpu) +
    tarjeta("Memoria RAM", `${decimal(h.ram_total_gb)} GB`, `${decimal(h.ram_libre_gb)} GB libres`) +
    tarjeta("Disco libre", `${h.disco_libre_gb.toFixed(0)} GB`, r.datos) +
    tarjeta("Tarjeta gráfica", gpu ? gpu.nombre : "Sin GPU NVIDIA", gpu ? `Driver ${gpu.driver} · capacidad ${gpu.capacidad}` : "Se usará el procesador") +
    tarjeta("Memoria de vídeo", gpu ? `${decimal(gpu.vram_total_gb)} GB` : "—", gpu ? `${decimal(gpu.vram_libre_gb)} GB libres` : "") +
    tarjeta("Entrenamiento", r.motor_listo ? "Preparado" : "Sin instalar", h.cuda ? `CUDA ${h.cuda}${r.motor_listo ? " · motor instalado" : ""}` : "CUDA no disponible: entrenar será lento");
  // Una sola línea con lo que importa; el detalle va plegado.
  const partes = [`Procesador de ${h.nucleos} núcleos`, `${Math.round(h.ram_total_gb)} GB de memoria`,
    gpu ? `gráfica de ${Math.round(gpu.vram_total_gb)} GB` : "sin gráfica NVIDIA", `${h.disco_libre_gb.toFixed(0)} GB libres`];
  if ($("#resumen-linea")) $("#resumen-linea").textContent = partes.join(" · ");
  if ($("#resumen-titulo")) $("#resumen-titulo").textContent = r.aviso_driver ? "Listo, con un aviso" : "Todo listo para trabajar";
  $("#avisos-inicio").innerHTML =
    (r.aviso_driver ? aviso("warn", esc(r.aviso_driver.split(" Actualízalo")[0]), `<a href="${esc(r.url_driver)}" target="_blank">Actualizar el driver</a>`) : "") +
    (!gpu ? aviso("info", "No hay una gráfica NVIDIA compatible. Puedes chatear con modelos pequeños usando el procesador; entrenar será lento.") : "");
  // El motor de entrenamiento solo se menciona aquí cuando falta; instalado, se ve en «Ver detalles del equipo».
  $("#motor-estado").innerHTML = r.motor_listo
    ? ""
    : aviso("info", "Para entrenar modelos con tus ejemplos hace falta instalar el motor (unos 3 GB, una sola vez).", `<button id="instalar" class="primario">Instalar motor</button>`);
  const f = await api().funciones();
  $("#funciones-nota").textContent = f.nota;
  $("#funciones").innerHTML = f.funciones.map((x) => `<tr><td>${esc(x.nombre)}</td><td><span class="chip ${x.estado}">${TEXTO_FUNC[x.estado]}</span>${x.fecha ? `<small>${esc(x.fecha)}</small>` : ""}</td></tr>`).join("");
  const b = $("#instalar");
  // La instalación se sigue en Ajustes › Avanzado › Registro del motor.
  if (b) b.onclick = async () => { const x = await api().instalar_motor(); if (!x.ok) fallo("#motor-estado", x.error); else { mostrarAjustes("avanzado"); mostrarVista("registro"); } };
}

// Filtros del catálogo: se combinan (AND entre grupos, OR dentro de un grupo),
// se aplican al momento y se recuerdan en este equipo (localStorage).
// A la vista solo hay buscar y el selector de uso («Para todo»). «Cabe en mi gráfica» va solo: se aplica
// si hay una gráfica NVIDIA con memoria detectada, y «Ver todos» lo quita.
const CLAVE_FILTROS = "sopa-filtros-modelos";
const FILTROS_VACIOS = () => ({ nombre: "", tam: [], uso: [], cabe: false, descargado: "", verTodos: false });
// Lo guardado por la versión anterior podía ocultar modelos sin un control a la vista
// (tamaño, descargados, la píldora). Al leerlo, solo se conservan nombre, uso y «Ver todos».
function leerFiltros() {
  try {
    const guardado = JSON.parse(localStorage.getItem(CLAVE_FILTROS) || "{}") || {};
    const f = FILTROS_VACIOS();
    f.nombre = typeof guardado.nombre === "string" ? guardado.nombre : "";
    const uso = Array.isArray(guardado.uso) ? guardado.uso[0] : guardado.uso;
    f.uso = typeof uso === "string" && uso ? [uso] : [];
    f.verTodos = guardado.verTodos === true;
    return f;
  } catch (e) { return FILTROS_VACIOS(); }
}
function guardarFiltros(f) {
  try { localStorage.setItem(CLAVE_FILTROS, JSON.stringify({ nombre: f.nombre || "", uso: f.uso || [], verTodos: f.verTodos === true })); } catch (e) {}
}
// Hay gráfica NVIDIA válida si el equipo detectó una con memoria. Sin ella, no se filtra.
function hayGraficaNvidia(info) {
  const gpus = (info && info.hardware && info.hardware.gpus) || [];
  return gpus.some((g) => Number(g && g.vram_total_gb) > 0);
}
function filtrosEfectivos(f, info) {
  return Object.assign({}, f, { cabe: hayGraficaNvidia(info) && f.verTodos !== true });
}
// Tamaño por parámetros (parametros_b del catálogo). Los huecos van al tramo de abajo.
function tramoTamano(b) {
  const n = Number(b) || 0;
  if (n >= 20) return "20";
  if (n >= 10) return "12-14";
  if (n >= 7) return "7-8";
  return "pocos";
}
// Uso según los metadatos que ya trae el catálogo: especialidad y vision.
function usosModelo(m) {
  const esp = m.especialidad || [];
  const usos = [];
  if (esp.includes("chat") || esp.includes("razonamiento") || esp.includes("documentos") || esp.includes("rapido")) usos.push("chat");
  if (esp.includes("codigo")) usos.push("codigo");
  if (esp.includes("documentos")) usos.push("documentos");
  if (m.vision || esp.includes("vision")) usos.push("vision");
  return usos;
}
function filtrarModelos(lista, f) {
  const q = (f.nombre || "").trim().toLocaleLowerCase("es");
  return lista.filter((m) => {
    if (q && !`${m.nombre || ""} ${m.id || ""} ${m.sin_censura ? "sin censura" : ""}`.toLocaleLowerCase("es").includes(q)
      && !`${m.descripcion || ""} ${(m.especialidad || []).map((e) => TEXTO_ESP[e] || e).join(" ")}`.toLocaleLowerCase("es").includes(q)) return false;
    if (f.tam.length && !f.tam.includes(tramoTamano(m.parametros_b))) return false;
    if (f.uso.length && !usosModelo(m).some((u) => f.uso.includes(u))) return false;
    if (f.cabe && m.chat !== "gpu") return false; // «gpu» = cabe entero en la VRAM detectada
    if (f.descargado === "si" && !m.descargado) return false;
    if (f.descargado === "no" && m.descargado) return false;
    return true;
  });
}
function pintarFiltros(f) {
  if (!$("#filtros-modelos")) return;
  $("#filtro-nombre").value = f.nombre;
  $("#filtro-uso").value = f.uso[0] || "";
  $("#filtro-limpiar").hidden = !(f.nombre || f.uso.length);
  const nota = $("#nota-filtro");
  if (nota) {
    const nvidia = hayGraficaNvidia(estado.info);
    nota.hidden = !nvidia;
    nota.innerHTML = !nvidia ? "" : f.verTodos
      ? `${svgS("grafica")}Ves todos los modelos, también los que no caben en tu gráfica. <button type="button" class="btn texto" id="filtro-cabe">Solo los que caben</button>`
      : `${svgS("grafica")}Solo los que caben en tu gráfica NVIDIA. <button type="button" class="btn texto" id="filtro-cabe">Ver todos</button>`;
  }
}
function montarFiltros() {
  const caja = $("#filtros-modelos");
  if (!caja || caja.dataset.listo) return;
  caja.dataset.listo = "1";
  estado.filtros = leerFiltros();
  pintarFiltros(estado.filtros);
  const cambio = () => { guardarFiltros(estado.filtros); pintarFiltros(estado.filtros); pintarCatalogo(); };
  $("#filtro-nombre").addEventListener("input", (e) => { estado.filtros.nombre = e.target.value; cambio(); });
  $("#filtro-uso").addEventListener("change", (e) => { estado.filtros.uso = e.target.value ? [e.target.value] : []; cambio(); });
  $("#nota-filtro").addEventListener("click", (e) => {
    if (!e.target.closest("#filtro-cabe")) return;
    estado.filtros.verTodos = !estado.filtros.verTodos; cambio();
  });
  $("#filtro-limpiar").addEventListener("click", () => { estado.filtros = Object.assign(FILTROS_VACIOS(), { verTodos: estado.filtros.verTodos }); cambio(); });
}

async function cargarCatalogo() {
  montarFiltros();
  const r = await api().catalogo(false); // los filtros se aplican aquí, sin volver a pedir
  $("#aviso-red").innerHTML = navigator.onLine ? "" : aviso("warn", "Sin conexión. Puedes usar los modelos que ya tienes; las descargas se reanudarán cuando vuelva la red.", "", "sinred");
  estado.catalogo = Object.fromEntries(r.modelos.map((m) => [m.id, m]));
  estado.catalogoLista = r.modelos;
  pintarFiltros(estado.filtros || FILTROS_VACIOS());
  pintarCatalogo();
}

const svgS = (n) => `<svg class="i s" aria-hidden="true"><use href="#i-${n}"/></svg>`;
// «En tu equipo»: una píldora y una línea. Sale de m.chat, que ya calcula el backend con la VRAM.
const FUNCIONA = { gpu: ["ok", "Va fluido"], mixto: ["ok", "Va bien"], cpu: ["aviso", "Va lento"], no: ["", "No cabe"] };
function lineaFunciona(m) {
  if (m.equipo_potente) return "Pide un equipo más potente";
  if (m.verificacion === "estimado") return "Aún no lo hemos medido aquí";
  if (m.chat === "mixto") return "Usa también la memoria del ordenador";
  if (m.chat === "cpu") return "Solo con el procesador";
  if (m.chat === "no") return "No cabe en este equipo";
  if (m.personalizar === "si") return "Se puede entrenar en tu equipo";
  return `${m.tamano || gbComa(m.gguf_gb)}`;
}
function filaCatalogo(m, n) {
  const [cls, texto] = m.equipo_potente ? ["", "Equipo potente"] : (FUNCIONA[m.chat] || ["", TEXTO_CHAT[m.chat] || ""]);
  const idm = `menu-cat-${n}`;
  const accion = m.descargado ? `<span class="descargado">${svgS("check")}Descargado</span>`
    : m.solo_catalogo ? '<span class="pildora">Solo catálogo</span>'
    : m.chat === "no" ? ""
    : `<button type="button" class="btn" data-descargar="${esc(m.id)}" ${navigator.onLine ? "" : "disabled"}>${svgS("descarga")}${m.parcial_bytes ? "Continuar" : "Descargar"}</button>`;
  return `<div class="fila" role="row" data-modelo="${esc(m.id)}">
    <div class="modelo" role="cell"><span class="monograma">${svgS("taller")}</span><div class="txt"><span class="nombre-modelo"><b>${esc(m.nombre)}</b>${m.sin_censura ? '<span class="pildora aviso">Sin censura</span>' : ""}</span><span>${esc(m.descripcion)}</span></div></div>
    <div class="funciona col-funciona" role="cell"><span class="pildora ${cls}"><span class="punto"></span>${esc(texto)}</span><span class="det">${esc(lineaFunciona(m))}</span></div>
    <div class="accion" role="cell">${accion}
      <div class="ancla"><button type="button" class="icono-btn" data-menu="${idm}" aria-haspopup="menu" aria-expanded="false" aria-label="Más sobre ${esc(m.nombre)}" title="Más">${svg("mas")}</button>
        <div class="menu abajo derecha" id="${idm}" role="menu">
          <button type="button" class="menu-item" role="menuitem" data-ver-modelo="${esc(m.id)}">${svg("info")}Ver detalles</button>
          <a class="menu-item" role="menuitem" href="${esc(m.licencia_url)}" target="_blank" rel="noopener">${svg("doc")}<span>Licencia<span class="det">${esc(m.licencia)} · ${TEXTO_LIC[m.licencia_tipo] || TEXTO_LIC.abierta}</span></span></a>
        </div></div></div>
    <div class="detalles-modelo" role="cell" id="det-${idm}" hidden><dl>
      <dt>Para</dt><dd>${(m.especialidad || []).map((e) => TEXTO_ESP[e] || esc(e)).join(", ")}${textoVision(m)}</dd>${filaVision(m)}
      <dt>Tamaño</dt><dd>${esc(m.tamano || gbComa(m.gguf_gb))}</dd>
      <dt>Chat</dt><dd>${esc(m.chat_texto)}</dd><dt>Entrenar</dt><dd>${esc(m.personalizar_texto)}</dd><dt>Fiabilidad</dt><dd>${esc(m.verificacion_texto)}</dd>
      <dt>Licencia</dt><dd>${chipLicencia(m)} ${esc(m.licencia)}</dd>${m.sin_censura ? "<dt>Uso</dt><dd>Sin censura: no tiene los filtros habituales.</dd>" : ""}</dl></div>
  </div>`;
}

// Visión (mmproj): «próximamente», «Añadir visión (x MB)» o «lista». Ver sopa_app/vision.py.
function textoVision(m) {
  const v = m.vision_estado || {};
  if (!m.vision) return "";
  if (!v.puede) return " · imágenes: próximamente";
  return v.lista ? " · imágenes" : "";
}
function mbComa(bytes) { return `${Math.round((bytes || 0) / 1e6).toLocaleString("es-ES")} MB`; }
function filaVision(m) {
  const v = m.vision_estado || {};
  if (!m.vision || !v.puede) return "";
  const sinMedir = v.estado === "sin_medir" ? '<span class="chip lic-condiciones">Sin medir</span>' : "";
  const cuerpo = v.lista ? `<span class="descargado">${svgS("check")}Visión lista</span>${sinMedir}`
    : !m.descargado ? `<span class="secundario-texto">Descarga el modelo y después añade su visión (${mbComa(v.bytes)}).</span>`
    : `<button type="button" class="btn" data-vision="${esc(m.id)}" ${navigator.onLine ? "" : "disabled"}>${svgS("descarga")}Añadir visión (${mbComa(v.bytes)})</button>${sinMedir}`;
  return `<dt>Imágenes</dt><dd class="vision-fila">${cuerpo}</dd>`;
}

function pintarCatalogo() {
  const todos = estado.catalogoLista || [];
  const f = estado.filtros || FILTROS_VACIOS();
  const modelos = filtrarModelos(todos, filtrosEfectivos(f, estado.info));
  if ($("#filtro-cuenta")) $("#filtro-cuenta").textContent = todos.length && modelos.length !== todos.length ? `${modelos.length} de ${todos.length}` : "";
  if (!todos.length) { $("#lista-modelos").innerHTML = vacio("modelos", "El catálogo está vacío", "Busca actualizaciones del catálogo en Ajustes."); return; }
  if (!modelos.length) { $("#lista-modelos").innerHTML = vacio("modelos", "Ningún modelo encaja con la búsqueda", f.verTodos || !hayGraficaNvidia(estado.info) ? "Prueba con otras palabras." : "Prueba con otras palabras o pulsa «Ver todos»."); return; }
  $("#lista-modelos").innerHTML = modelos.map((m, n) => filaCatalogo(m, n)).join("");
  document.querySelectorAll("[data-descargar]").forEach((b) => b.onclick = () => confirmarDescarga(b.dataset.descargar));
  document.querySelectorAll("[data-vision]").forEach((b) => b.onclick = (ev) => { if (!ev || ev.isTrusted !== true) return; descargarVision(b.dataset.vision); });
  document.querySelectorAll("[data-ver-modelo]").forEach((b) => b.onclick = () => {
    const det = b.closest(".fila").querySelector(".detalles-modelo");
    if (det) det.hidden = !det.hidden;
  });
}

const TEXTO_LIC = { abierta: "Uso comercial", condiciones: "Con condiciones", no_comercial: "No comercial" };
const chipLicencia = (m) => `<span class="chip lic-${esc(m.licencia_tipo || "abierta")}">${TEXTO_LIC[m.licencia_tipo] || TEXTO_LIC.abierta}</span>`;

const TEXTO_AVISO_SIN_CENSURA = "Este modelo no tiene los filtros habituales y puede responder a cualquier cosa. Úsalo con responsabilidad.";
const CLAVE_SIN_CENSURA = "sopa-sin-censura";

function idsSinCensuraAceptados() {
  try {
    const raw = localStorage.getItem(CLAVE_SIN_CENSURA);
    const lista = raw ? JSON.parse(raw) : [];
    return Array.isArray(lista) ? lista.map(String) : [];
  } catch (e) { return []; }
}
function avisoSinCensuraAceptado(id) { return !!id && idsSinCensuraAceptados().includes(String(id)); }
function recordarAvisoSinCensura(id) {
  if (!id) return;
  const lista = idsSinCensuraAceptados();
  if (!lista.includes(String(id))) {
    lista.push(String(id));
    localStorage.setItem(CLAVE_SIN_CENSURA, JSON.stringify(lista));
  }
}
function modeloSinCensura(idORuta) {
  if (!idORuta) return null;
  const cat = estado.catalogo || {};
  if (cat[idORuta] && cat[idORuta].sin_censura) return cat[idORuta];
  const porId = (estado.catalogoLista || []).find((x) => x.id === idORuta);
  if (porId && porId.sin_censura) return porId;
  const local = (estado.modelosLocales || []).find((x) => x.ruta === idORuta || x.id === idORuta);
  const ident = local && local.id;
  const m = ident && (cat[ident] || (estado.catalogoLista || []).find((x) => x.id === ident));
  return m && m.sin_censura ? m : null;
}
function aceptarSinCensuraSiToca(idORuta) {
  const m = modeloSinCensura(idORuta);
  if (!m) return Promise.resolve(true);
  if (avisoSinCensuraAceptado(m.id)) return Promise.resolve(true);
  return pedirAvisoSinCensura(m);
}
function pedirAvisoSinCensura(m) {
  return new Promise((resolver) => {
    const velo = $("#dialogo-sin-censura");
    const texto = $("#sin-censura-texto");
    const si = $("#sin-censura-si");
    const no = $("#sin-censura-no");
    if (!velo || !si || !no) { resolver(false); return; }
    if (texto) texto.textContent = TEXTO_AVISO_SIN_CENSURA;
    const titulo = $("#sin-censura-titulo");
    if (titulo) titulo.textContent = m && m.nombre ? `${m.nombre}` : "Modelo sin censura";
    const cerrar = (ok) => {
      velo.hidden = true;
      document.body.classList.remove("con-dialogo");
      velo.removeEventListener("keydown", tecla);
      velo.removeEventListener("click", fondo);
      si.onclick = null;
      no.onclick = null;
      if (ok) recordarAvisoSinCensura(m && m.id);
      resolver(!!ok);
    };
    const tecla = (e) => { if (e.key === "Escape") { e.stopPropagation(); cerrar(false); } };
    const fondo = (e) => { if (e.target.id === "dialogo-sin-censura") cerrar(false); };
    velo.hidden = false;
    document.body.classList.add("con-dialogo");
    velo.addEventListener("keydown", tecla);
    velo.addEventListener("click", fondo);
    no.onclick = () => cerrar(false);
    si.onclick = () => cerrar(true);
    no.focus();
  });
}
async function confirmarDescarga(id) {
  if (!(await aceptarSinCensuraSiToca(id))) return;
  confirmarLicencia(id);
}

// Antes de descargar se muestra siempre la licencia del modelo; si no es abierta, hay que aceptarla.
function confirmarLicencia(id) {
  const m = (estado.catalogo || {})[id] || {};
  const caja = $("#descarga");
  caja.classList.remove("oculto");
  const tipo = m.licencia_tipo || "abierta";
  const enlace = `<a href="${esc(m.licencia_url)}" target="_blank">Leer la licencia completa</a>`;
  const titulo = tipo === "no_comercial" ? `<b>${esc(m.nombre)} es solo para uso no comercial.</b> ` : tipo === "condiciones" ? `<b>${esc(m.nombre)} tiene condiciones de uso.</b> ` : `<b>${esc(m.nombre)}</b> · `;
  caja.innerHTML = aviso(tipo === "no_comercial" ? "err" : tipo === "condiciones" ? "warn" : "info",
    `${titulo}${esc(m.licencia_nota || m.licencia)} ${enlace}`,
    `<button class="primario" id="lic-aceptar">${tipo === "abierta" ? "Descargar" : "Acepto la licencia y descargo"}</button><button class="fantasma" id="lic-cancelar">Cancelar</button>`);
  // Solo un clic de la persona descarga: un .click() desde código no vale.
  $("#lic-aceptar").onclick = (ev) => { if (!ev || ev.isTrusted !== true) return; descargar(id); };
  $("#lic-cancelar").onclick = () => caja.classList.add("oculto");
  caja.scrollIntoView({ block: "nearest" });
}

async function cargarLocales() {
  // El nombre y la descripción salen del catálogo: si aún no está, se pide (sin red, se ven los ids).
  if (!estado.catalogo) {
    try { const cat = await api().catalogo(false); if (cat && cat.modelos) { estado.catalogo = Object.fromEntries(cat.modelos.map((m) => [m.id, m])); estado.catalogoLista = cat.modelos; } } catch (e) { /* sin catálogo */ }
  }
  const r = await api().modelos_locales();
  const caja = $("#lista-locales");
  if (!r.modelos.length) { caja.innerHTML = `<div class="fila"><span class="secundario-texto">Aún no tienes modelos. Descarga uno del catálogo o importa uno exportado.</span></div>`; return; }
  const enUso = estado.modeloChat || "";
  caja.innerHTML = r.modelos.map((m, n) => {
    const nombre = nombreModelo(m);
    const cat = (estado.catalogo || {})[m.id];
    const usado = enUso && (enUso === m.id || enUso === m.ruta || String(m.ruta || "").endsWith(enUso + ".gguf"));
    const pildora = usado ? '<span class="pildora ok">En uso</span>' : m.personalizado ? '<span class="pildora info">Personalizado</span>' : "";
    const det = m.personalizado ? `Tu modelo personalizado · ${gbComa(m.tamano_gb)}`
      : `${cat && cat.descripcion ? String(cat.descripcion).replace(/\.$/, "") + " · " : ""}${gbComa(m.tamano_gb)}`;
    return `<div class="fila fila-modelo"><span class="monograma">${svgS(m.personalizado ? "entrenar" : "taller")}</span>
      <div class="txt"><b>${esc(nombre)}</b><span>${esc(det)}</span></div>${pildora}
      <div class="ancla"><button type="button" class="icono-btn" data-menu="menu-local-${n}" aria-haspopup="menu" aria-expanded="false" aria-label="Opciones de ${esc(nombre)}" title="Opciones">${svg("mas")}</button>
        <div class="menu abajo derecha" id="menu-local-${n}" role="menu">
          ${m.personalizado ? `<button type="button" class="menu-item" role="menuitem" data-comparar-modelo="${esc(m.id)}">${svg("comparar")}Comparar con el original</button>
          <button type="button" class="menu-item" role="menuitem" data-renombrar="${esc(m.id)}">${svg("editar")}Renombrar</button>` : ""}
          <button type="button" class="menu-item" role="menuitem" data-exportar="${esc(m.id)}">${svg("exportar")}Exportar…</button>
          <div class="menu-sep"></div>
          <button type="button" class="menu-item peligro" role="menuitem" data-borrar="${esc(m.id)}">${svg("borrar")}Borrar del equipo</button>
        </div></div></div>`;
  }).join("");
  document.querySelectorAll("[data-comparar-modelo]").forEach((b) => b.onclick = () => {
    mostrarVista("comparar");
    const sel = $("#comparar-modelo");
    setTimeout(() => { if (sel && [...sel.options].some((o) => o.value === b.dataset.compararModelo)) sel.value = b.dataset.compararModelo; }, 300);
  });
  const av = $("#aviso-gestion");
  document.querySelectorAll("[data-renombrar]").forEach((b) => b.onclick = async () => {
    const fila = b.closest(".fila");
    const nuevo = await editarEnLinea(fila && fila.querySelector(".txt"), { valor: b.dataset.renombrar.slice(4), etiqueta: "Nuevo nombre del modelo", boton: "Renombrar" });
    if (!nuevo) return;
    const x = await api().renombrar_modelo(b.dataset.renombrar, nuevo);
    av.innerHTML = x.ok ? aviso("ok", `Renombrado a «${esc(x.id.slice(4))}».`) : aviso("err", esc(x.error)); cargarLocales();
  });
  document.querySelectorAll("[data-exportar]").forEach((b) => b.onclick = async () => {
    const x = await api().exportar_modelo(b.dataset.exportar);
    if (x.cancelado) return;
    if (!x.ok) { av.innerHTML = aviso("err", esc(x.error)); return; }
    const paso = async () => {
      const e = await api().estado_exportacion();
      if (e.activo) {
        const pct = e.total ? Math.round(100 * e.hecho / e.total) : 0;
        av.innerHTML = `<div class="aviso info">${svg("info")}<div>Exportando «${esc(e.id)}»… ${pct} %${e.total ? ` (${gib(e.hecho / 2)} de ${gib(e.total / 2)})` : ""}<progress class="barra-progreso" max="100" value="${pct}"></progress></div></div>`;
        setTimeout(paso, 500);
      } else av.innerHTML = e.error ? aviso("err", esc(e.error)) : aviso("ok", `Exportado en ${esc(e.ruta)}. Puedes llevarlo a otro equipo e importarlo.`);
    };
    paso();
  });
  document.querySelectorAll("[data-borrar]").forEach((b) => b.onclick = () => {
    av.innerHTML = aviso("warn", `¿Borrar «${esc(b.dataset.borrar)}» de este equipo? ${b.dataset.borrar.startsWith("mio-") ? "Se borra también lo necesario para seguir personalizándolo." : "Podrás volver a descargarlo."}`,
      `<button class="peligro" id="borrar-si">Borrar</button><button class="fantasma" id="borrar-no">Cancelar</button>`);
    $("#borrar-no").onclick = () => av.innerHTML = "";
    $("#borrar-si").onclick = async () => { const x = await api().borrar_modelo(b.dataset.borrar); av.innerHTML = x.ok ? aviso("ok", "Borrado.") : aviso("err", esc(x.error)); cargarLocales(); cargarCatalogo(); };
  });
}

async function importarModelo() {
  const av = $("#aviso-gestion");
  av.innerHTML = aviso("info", "Comprobando e importando…");
  let x = await api().importar_modelo();
  if (x.cancelado) { av.innerHTML = ""; return; }
  if (!x.ok && /^Ya tienes/.test(x.error || "")) {
    av.innerHTML = `<div class="aviso info en-linea-caja"></div>`;
    const nombre = await editarEnLinea(av.querySelector(".en-linea-caja"), { nota: `${x.error} ¿Con qué nombre lo importo?`, etiqueta: "Nombre para el modelo importado", boton: "Importar" });
    if (!nombre) { av.innerHTML = ""; return; }
    x = await api().importar_modelo_ruta(x.ruta, nombre);
  }
  if (!x.ok) { av.innerHTML = aviso("err", esc(x.error)); return; }
  const lic = x.licencia_base;
  av.innerHTML = aviso("ok", `Importado como «${esc(x.id.replace(/^mio-/, ""))}». Ya puedes usarlo en el chat.`)
    + (lic && lic.tipo === "no_comercial" ? aviso("err", `Está basado en un modelo de uso no comercial (${esc(lic.nombre)}).`) : lic && lic.tipo === "condiciones" ? aviso("warn", `Está basado en un modelo con condiciones de uso (${esc(lic.nombre)}).`) : "");
  cargarLocales();
}

function pintarProgresoDescarga(d) {
  const barra = $("#progreso-descarga");
  if (!barra) return;
  if (!d || !d.activa) { barra.classList.add("oculto"); barra.innerHTML = ""; return; }
  const hecho = Number(d.hecho) || 0;
  const total = Number(d.total) || 0;
  const pct = total ? Math.round((100 * hecho) / total) : 0;
  const accion = d.fase === "verificando" ? "Comprobando que el archivo es correcto" : "Descargando";
  barra.classList.remove("oculto");
  barra.innerHTML = `<b>${accion} ${esc(d.id || "")}</b><progress class="barra-progreso" max="100" value="${pct}"></progress><small>${pct}% · ${(hecho / 1e9).toFixed(2)} de ${(total / 1e9).toFixed(2)} GB</small>`;
}

async function descargarVision(id) {
  const r = await api().descargar_vision(id, true);
  if (!r.ok) { const caja = $("#descarga"); caja.classList.remove("oculto"); caja.innerHTML = aviso("err", esc(r.error)); return; }
  seguirDescarga(id, "Visión descargada y comprobada. Carga el modelo de nuevo para que vea imágenes.");
}

async function descargar(id) {
  const r = await api().descargar_modelo(id, true);
  const caja = $("#descarga");
  if (!r.ok) { caja.classList.remove("oculto"); caja.innerHTML = aviso("err", esc(r.error)); return; }
  seguirDescarga(id);
}

function seguirDescarga(id, textoFin) {
  const caja = $("#descarga");
  $("#punto-descarga").parentElement.classList.add("ocupado");
  caja.classList.remove("oculto");
  pintarProgresoDescarga({ activa: true, id, hecho: 0, total: 0, fase: "descargando" });
  const t = setInterval(async () => {
    const d = await api().estado_descarga();
    const pct = d.total ? Math.round((100 * d.hecho) / d.total) : 0;
    const accion = d.fase === "verificando" ? "Comprobando que el archivo es correcto" : "Descargando";
    pintarProgresoDescarga(d);
    caja.innerHTML = `<h3>${accion} ${esc(d.id)}</h3><progress class="barra-progreso" max="100" value="${pct}"></progress>
      <small>${pct}% · ${(d.hecho / 1e9).toFixed(2)} de ${(d.total / 1e9).toFixed(2)} GB</small><button id="cancelar" class="btn texto">Cancelar</button>`;
    const c = $("#cancelar"); if (c) c.onclick = () => api().cancelar_descarga();
    if (!d.activa) {
      clearInterval(t);
      pintarProgresoDescarga(null);
      $("#punto-descarga").parentElement.classList.remove("ocupado");
      caja.innerHTML = d.cancelada ? aviso("warn", esc(d.error)) : d.error ? aviso("err", esc(d.error), "Pulsa «Continuar» para reintentar.")
        : aviso("ok", d.verificado ? "Descarga completa y comprobada." : "Descarga completa.", `<button class="primario" onclick="mostrarVista('chat')">Empezar a chatear</button>`);
      if (!d.error) toast(textoFin || "Modelo descargado y comprobado.");
      cargarCatalogo();
    }
  }, 700);
}

// Nombre llano de un modelo: el del catálogo si lo hay; si no, su id.
function nombreModelo(m) {
  if (!m) return "";
  if (m.personalizado) return m.id.replace(/^mio-/, "").replace(/-/g, " ").replace(/^./, (c) => c.toUpperCase());
  const cat = (estado.catalogo || {})[m.id];
  return (cat && cat.nombre) || m.id;
}
function agenteSala() { return ($("#chat-agente") && $("#chat-agente").value) || "chat"; }
function nombreAgenteSala() {
  const f = typeof fichaEquipo === "function" ? fichaEquipo(agenteSala()) : null;
  return (f && f.nombre) || "Sopa";
}

async function cargarModelosChat() {
  if (!estado.catalogo && !estado.pidiendoCatalogo) {
    estado.pidiendoCatalogo = true;
    try {
      const cat = await api().catalogo(false);
      if (cat && cat.modelos) { estado.catalogo = Object.fromEntries(cat.modelos.map((m) => [m.id, m])); estado.catalogoLista = cat.modelos; }
    } catch (e) { /* sin catálogo, se ven los ids */ }
    estado.pidiendoCatalogo = false;
  }
  const r = await api().modelos_locales();
  estado.modelosLocales = r.modelos || [];
  const antes = $("#chat-modelo").value;  // al volver a pintar la lista no se pierde el modelo en uso
  $("#chat-modelo").innerHTML = r.modelos.length
    ? r.modelos.map((m) => `<option value="${esc(m.ruta)}">${esc(nombreModelo(m))} (${gbComa(m.tamano_gb)})</option>`).join("")
    : `<option value="">Aún no tienes modelos</option>`;
  if (antes && r.modelos.some((m) => m.ruta === antes)) $("#chat-modelo").value = antes;
  estado.hayModelos = r.modelos.length > 0;
  if (!estado.mensajes.length) pintarMensajes();
  if (estado.trasRecarga && !estado.eleccionDeEstaPagina && typeof adoptarModeloEnUso === "function") await adoptarModeloEnUso();
  pintarMenuModelo();
  pintarEleccionChat();
  const c = await api().conversaciones();
  estado.listaConversaciones = c.conversaciones || [];
  pintarMenuConversacion();
  pintarHistorial();
}

// ---- Modelo de esta conversación -------------------------------------------
// Automático por defecto. Si eliges uno a mano, vale solo para esa conversación
// (se recuerda en este equipo) y se carga al elegirlo.
const CLAVE_MODELO_CONV = "sopa-modelo-conv";
function modelosPorConv() {
  try { const x = JSON.parse(localStorage.getItem(CLAVE_MODELO_CONV) || "{}"); return x && typeof x === "object" ? x : {}; } catch (e) { return {}; }
}
function modeloDeConv(id) {
  if (!id) return estado.modeloPendiente || "";
  return modelosPorConv()[id] || "";
}
function fijarModeloConv(id, ruta) {
  if (!id) { estado.modeloPendiente = ruta || ""; return; }
  const todos = modelosPorConv();
  if (ruta) todos[id] = ruta; else delete todos[id];
  try { localStorage.setItem(CLAVE_MODELO_CONV, JSON.stringify(todos)); } catch (e) {}
}
function pintarMenuModelo() {
  const caja = $("#menu-modelo-lista");
  if (!caja) return;
  // Si hay un modelo en marcha, el menú lo marca a él. Si no, la elección guardada de esta conversación.
  const enUso = estado.modeloEnUso && estado.modeloEnUso.activo && estado.modeloEnUso.ruta;
  const manual = enUso || modeloDeConv(estado.conversacion);
  const auto = estado.eleccionAuto ? ` · ${estado.eleccionAuto}` : "";
  const marca = `<span class="fin">${svg("check")}</span>`;
  const item = (valor, titulo, det, elegido) => `<button type="button" class="menu-item${elegido ? " elegido" : ""}" role="menuitemradio" aria-checked="${elegido ? "true" : "false"}" data-modelo-conv="${esc(valor)}"><span>${esc(titulo)}<span class="det">${esc(det)}</span></span>${elegido ? marca : ""}</button>`;
  caja.innerHTML = item("", `Automático${auto}`, "Sopa elige el mejor para cada agente", !manual)
    + (estado.modelosLocales || []).map((m) => {
      const cat = (estado.catalogo || {})[m.id];
      const det = m.personalizado ? `Tu modelo personalizado · ${gbComa(m.tamano_gb)}` : `${cat && cat.descripcion ? cat.descripcion.split(".")[0] + " · " : ""}${gbComa(m.tamano_gb)}`;
      return item(m.ruta, nombreModelo(m), det, manual === m.ruta);
    }).join("");
  caja.querySelectorAll("[data-modelo-conv]").forEach((b) => b.onclick = () => elegirModeloConv(b.dataset.modeloConv));
  pintarBotonModelo();
}
function pintarBotonModelo() {
  const b = $("#boton-modelo"), t = $("#boton-modelo-texto");
  if (!b || !t || estado.cargandoModelo) return;
  const locales = estado.modelosLocales || [];
  const porRuta = (ruta) => ruta && locales.find((x) => x.ruta === ruta);
  const uso = estado.modeloEnUso;
  // El que está cargado manda sobre el nombre del catálogo (el 27B) y sobre una elección vieja del menú.
  const enMarcha = uso && uso.activo ? porRuta(uso.ruta) : null;
  const manual = modeloDeConv(estado.conversacion);
  const m = enMarcha || porRuta(manual) || porRuta(estado.modeloManualCargado);
  if (m) t.textContent = nombreModelo(m);
  else if (uso && uso.activo && uso.nombre) t.textContent = uso.nombre;
  else t.textContent = estado.eleccionAuto || "Automático";
  b.title = m || (uso && uso.activo) ? "Modelo en uso" : "Automático: Sopa elige el modelo";
}
async function elegirModeloConv(ruta) {
  if (ruta && !(await aceptarSinCensuraSiToca(ruta))) { pintarMenuModelo(); return; }
  estado.eleccionDeEstaPagina = true;
  estado.trasRecarga = false;
  fijarModeloConv(estado.conversacion, ruta);
  pintarMenuModelo();
  if (ruta) { await cargarChat(ruta); return; }
  // Vuelve a Automático: si había uno elegido a mano cargado, se suelta y Sopa elige al enviar.
  if (estado.modeloManualCargado && !estado.enviando) {
    await api().chat_detener();
    estado.modeloChat = null;
    estado.modeloManualCargado = "";
  }
  pintarEleccionChat();
}
// Qué hacer con el modelo al enviar. Tras recargar la página no se arranca el default
// del catálogo: se queda el que ya está en marcha, o se restaura el que la persona eligió
// (con su contexto). En otra conversación en Automático sí se suelta el elegido a mano.
function decisionModelo({ manual, cargado, enMarcha, guardado, recarga }) {
  manual = manual || "";
  cargado = cargado || "";
  enMarcha = enMarcha || "";
  if (recarga && enMarcha) return { accion: "quedarse", ruta: enMarcha, fijar: manual !== enMarcha };
  if (recarga && guardado && guardado.ruta) {
    return { accion: "restaurar", ruta: guardado.ruta, contexto: guardado.contexto || null, fijar: manual !== guardado.ruta };
  }
  if (manual && manual !== cargado) {
    if (enMarcha && enMarcha === manual) return { accion: "quedarse", ruta: manual, fijar: false };
    return { accion: "cargar", ruta: manual };
  }
  if (!manual && cargado) return { accion: "soltar" };
  return { accion: "seguir" };
}
async function refrescarModeloEnUso() {
  let uso = null;
  try { uso = await api().modelo_en_uso(); } catch (e) { return null; }
  if (!uso || uso.ok === false) return null;
  estado.modeloEnUso = uso;
  if (uso.activo && uso.id) estado.modeloChat = uso.id;
  return uso;
}
// Al abrir la página de nuevo: el modelo en marcha (o el último elegido) pasa a ser el de esta conversación.
async function adoptarModeloEnUso() {
  const uso = await refrescarModeloEnUso();
  if (!uso || estado.eleccionDeEstaPagina || !estado.trasRecarga) {
    if (typeof pintarBotonModelo === "function") pintarBotonModelo();
    return;
  }
  const ruta = (uso.activo && uso.ruta) || (uso.explicito && uso.ruta) || "";
  if (ruta) {
    if (uso.activo) estado.modeloManualCargado = uso.ruta;
    if (modeloDeConv(estado.conversacion) !== ruta) fijarModeloConv(estado.conversacion, ruta);
  }
  if (typeof pintarMenuModelo === "function") pintarMenuModelo();
}
// Antes de enviar: que el modelo cargado sea el de esta conversación.
async function prepararModeloConv() {
  if (estado.modeloPendiente && estado.conversacion) {
    fijarModeloConv(estado.conversacion, estado.modeloPendiente);
    estado.modeloPendiente = "";
  }
  const manual = modeloDeConv(estado.conversacion);
  let uso = estado.modeloEnUso;
  if (estado.trasRecarga) {
    try {
      const fresco = await api().modelo_en_uso();
      if (fresco && fresco.ok !== false) { uso = fresco; estado.modeloEnUso = fresco; }
    } catch (e) { /* sigue con lo que ya hubiera */ }
  }
  const decision = decisionModelo({
    manual,
    cargado: estado.modeloManualCargado || "",
    enMarcha: uso && uso.activo ? (uso.ruta || "") : "",
    guardado: uso && uso.explicito && uso.ruta ? { ruta: uso.ruta, contexto: uso.contexto } : null,
    recarga: estado.trasRecarga === true,
  });
  estado.trasRecarga = false;
  if (decision.accion === "quedarse") {
    estado.modeloManualCargado = decision.ruta;
    if (uso && uso.id) estado.modeloChat = uso.id;
    if (decision.fijar) fijarModeloConv(estado.conversacion, decision.ruta);
    pintarMenuModelo();
    return;
  }
  if (decision.accion === "restaurar") {
    if (decision.fijar) fijarModeloConv(estado.conversacion, decision.ruta);
    await cargarChat(decision.ruta, decision.contexto);
    return;
  }
  if (decision.accion === "cargar") {
    await cargarChat(manual);
    return;
  }
  if (decision.accion === "soltar") {
    await api().chat_detener();
    estado.modeloChat = null;
    estado.modeloManualCargado = "";
    estado.modeloEnUso = null;
  }
}

// ---- «…» del chat: el agente y sus conversaciones ---------------------------
function pintarMenuConversacion() {
  const nombre = nombreAgenteSala();
  const agente = agenteSala();
  const suyas = (estado.listaConversaciones || []).filter((x) => (x.agente || "chat") === agente);
  if ($("#menu-agente-titulo")) $("#menu-agente-titulo").textContent = nombre;
  if (typeof pintarPlaceholderChat === "function") pintarPlaceholderChat();
  if ($("#menu-conv-titulo")) $("#menu-conv-titulo").textContent = `Conversaciones con ${nombre}`;
  if ($("#conv-exportar-texto")) $("#conv-exportar-texto").textContent = `Exportar las de ${nombre}…`;
  if ($("#sala-recuerdos-det")) $("#sala-recuerdos-det").textContent = `Lo que ${nombre} recuerda de ti`;
  const anteriores = suyas.filter((x) => x.id !== estado.conversacion).length;
  if ($("#conv-historial-det")) $("#conv-historial-det").textContent = anteriores === 1 ? "1 conversación anterior" : anteriores ? `${anteriores} conversaciones anteriores` : "Aún no hay otras";
  if ($("#conv-exportar")) $("#conv-exportar").disabled = !suyas.length;
  const guardada = suyas.some((x) => x.id === estado.conversacion);
  if ($("#conv-md")) $("#conv-md").disabled = !guardada;
  if ($("#conv-borrar")) $("#conv-borrar").disabled = !guardada;
}
function fechaConv(iso) {
  const d = new Date(iso || "");
  return isNaN(d) ? "" : d.toLocaleDateString("es-ES", { day: "numeric", month: "short" });
}
function pintarHistorial() {
  const caja = $("#historial");
  if (!caja) return;
  const agente = agenteSala();
  const suyas = (estado.listaConversaciones || []).filter((x) => (x.agente || "chat") === agente);
  caja.innerHTML = `<div class="cab-historial"><h3>Conversaciones con ${esc(nombreAgenteSala())}</h3><button type="button" class="icono-btn" id="historial-cerrar" aria-label="Cerrar el historial" title="Cerrar">${svg("cerrar")}</button></div>`
    + (suyas.length ? `<div class="lista-historial">${suyas.map((x) => `<div class="fila-conv${x.id === estado.conversacion ? " activa" : ""}" data-conv="${esc(x.id)}" role="button" tabindex="0"${x.id === estado.conversacion ? ' aria-current="true"' : ""} title="${esc(x.titulo)}">
        <span class="txt"><b>${esc(x.titulo || "Sin título")}</b><span>${esc(fechaConv(x.actualizada))}</span></span>
        <button type="button" class="icono-btn" data-md="${esc(x.id)}" aria-label="Guardar como texto: ${esc(x.titulo)}" title="Guardar como texto">${svg("exportar")}</button>
        <button type="button" class="icono-btn" data-borrar="${esc(x.id)}" aria-label="Borrar conversación: ${esc(x.titulo)}" title="Borrar">${svg("borrar")}</button></div>`).join("")}</div>`
    : `<p class="secundario-texto">Tus conversaciones se guardan aquí, en este equipo.</p>`);
  $("#historial-cerrar").onclick = () => { caja.hidden = true; $("#conv-historial").setAttribute("aria-expanded", "false"); };
  caja.querySelectorAll("[data-conv]").forEach((d) => {
    const abrir = () => abrirConversacion(d.dataset.conv);
    d.onclick = (ev) => { if (!ev.target.closest("[data-borrar],[data-md]")) abrir(); };
    d.onkeydown = (ev) => {
      if (ev.target !== d) return;
      if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); abrir(); }
    };
  });
  caja.querySelectorAll("[data-borrar]").forEach((b) => b.onclick = (ev) => { ev.stopPropagation(); borrarConversacion(b.dataset.borrar); });
  caja.querySelectorAll("[data-md]").forEach((b) => b.onclick = async (ev) => {
    ev.stopPropagation();
    const x = await api().exportar_conversacion_md(b.dataset.md);
    $("#aviso-chat").innerHTML = x.cancelado ? "" : x.ok ? aviso("ok", `Guardada como texto en ${esc(x.ruta)}.`) : aviso("err", esc(x.error));
  });
}
// Abre una conversación anterior del agente: se deja como su hilo actual (hilo_fijar).
async function abrirConversacion(id) {
  estado.trasRecarga = false;
  const agente = agenteSala();
  estado.hiloToken = (estado.hiloToken || 0) + 1;
  await api().hilo_fijar(agente, id);
  const r = await api().conversacion(id);
  if (!r || !r.ok) return fallo("#aviso-chat", (r && r.error) || "No encuentro esa conversación.");
  if (typeof aplicarHilo === "function") aplicarHilo(Object.assign({}, r, { agente }));
  else { estado.conversacion = r.id; estado.versionConv = r.version || 0; estado.mensajes = r.mensajes || []; estado.docs = r.documentos || []; pintarDocs(); pintarMensajes(); }
  if (typeof seguidor === "function") seguidor().irAlFinal();
  pintarMenuConversacion();
  pintarHistorial();
  pintarMenuModelo();
}
async function borrarConversacion(id) {
  const x = (estado.listaConversaciones || []).find((y) => y.id === id);
  if (!confirm(`¿Borrar «${(x && x.titulo) || "esta conversación"}»? No se puede deshacer.`)) return;
  await api().borrar_conversacion(id);
  fijarModeloConv(id, "");
  if (estado.conversacion === id) {
    estado.conversacion = null; estado.mensajes = []; estado.docs = [];
    const agente = agenteSala();
    if (estado.hilos) delete estado.hilos[agente];
    pintarDocs(); pintarMensajes();
  }
  cargarModelosChat();
}
function enlazarMenuChat() {
  const avc = () => $("#aviso-chat");
  $("#conv-historial").onclick = () => {
    const caja = $("#historial");
    caja.hidden = !caja.hidden;
    $("#conv-historial").setAttribute("aria-expanded", caja.hidden ? "false" : "true");
    if (!caja.hidden) { pintarHistorial(); const f = caja.querySelector("[data-conv]"); if (f) f.focus(); }
  };
  $("#conv-exportar").onclick = async () => {
    const x = await api().exportar_conversaciones(agenteSala());
    avc().innerHTML = x.cancelado ? "" : x.ok ? aviso("ok", `${x.cantidad} conversaciones exportadas en ${esc(x.ruta)}.`) : aviso("err", esc(x.error));
  };
  $("#conv-importar").onclick = async () => {
    const x = await api().importar_conversaciones();
    if (x.cancelado) return;
    avc().innerHTML = x.ok ? aviso("ok", `${x.importadas.length} conversaciones importadas${x.omitidas ? ` (${x.omitidas} no eran válidas)` : ""}.`) : aviso("err", esc(x.error));
    cargarModelosChat();
  };
  $("#conv-md").onclick = async () => {
    if (!estado.conversacion) return;
    const x = await api().exportar_conversacion_md(estado.conversacion);
    avc().innerHTML = x.cancelado ? "" : x.ok ? aviso("ok", `Guardada como texto en ${esc(x.ruta)}.`) : aviso("err", esc(x.error));
  };
  $("#conv-borrar").onclick = () => { if (estado.conversacion) borrarConversacion(estado.conversacion); };
  $("#boton-menu-chat").addEventListener("click", () => pintarMenuConversacion());
}

function enlacesWeb(h) {
  if (!h) return "";
  const que = h.que ? `<small class="meta">${esc(h.que)}</small>` : "";
  const links = (Array.isArray(h.fuentes) ? h.fuentes : []).map((f) => {
    const url = String((f && f.url) || "");
    if (!/^https?:\/\//i.test(url)) return "";
    return `<a href="${esc(url)}" target="_blank" rel="noopener noreferrer">${esc((f && f.titulo) || url)}</a>`;
  }).filter(Boolean);
  return que + (links.length ? `<div class="fuentes-web">${links.join("")}</div>` : "");
}

// Capturas del arenero, del escritorio aislado y del ordenador del agente: solo PNG en data URL, como mucho dos. El modelo no las ve.
function capturasEjecucion(h) {
  if (!h || !Array.isArray(h.capturas)) return "";
  const herramienta = String((h && h.herramienta) || "");
  const escritorio = herramienta.startsWith("escritorio_");
  const ordenador = herramienta.startsWith("ordenador_");
  const imgs = h.capturas.filter((c) => c && typeof c.src === "string" && /^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(c.src))
    .slice(-2)
    .map((c) => {
      const titulo = c.titulo || (ordenador ? "Ordenador del agente" : escritorio ? "Escritorio aislado" : "Captura del arenero");
      const alt = ordenador ? "Captura del ordenador del agente" : escritorio ? "Captura del escritorio aislado" : (c.titulo ? "Captura de «" + c.titulo + "»" : "Captura del programa");
      return `<figure class="ejecucion-captura"><img alt="${esc(alt)}" src="${c.src}">`
        + `<figcaption>${esc(titulo)}${c.ancho && c.alto ? ` · ${Number(c.ancho)}×${Number(c.alto)}` : ""}</figcaption></figure>`;
    });
  return imgs.join("");
}

function etiquetaEstadoEquipo(valor) {
  if (valor === "trabajando") return "Trabajando";
  if (valor === "error") return "Error";
  return "Listo";
}

// Tres caras pequeñas (foto fija) en la pestaña Equipo del Taller y en el botón de Inicio que lleva a la Sala,
// y el número real de agentes del equipo.
function pintarCarasEquipo() {
  const lista = estado.equipo || [];
  const caras = lista.slice(0, 3).map((a) =>
    `<span class="cara-sopa s"><img alt="" src="avatares/${esc(a.avatar || "zen")}.png" onerror="this.remove()"></span>`).join("");
  ["pestana-caras", "inicio-caras"].forEach((id) => {
    const caja = document.getElementById(id);
    if (caja) caja.innerHTML = caras;
  });
  const cuantos = document.getElementById("inicio-n-agentes");
  if (cuantos) cuantos.textContent = lista.length ? `${lista.length} ${lista.length === 1 ? "agente" : "agentes"} en tu equipo` : "Tu equipo";
}

function pintarAgenteActivo() {
  const sel = $("#chat-agente");
  const caja = $("#chat-agente-activo");
  if (!sel || !caja) return;
  const id = sel.value || "chat";
  const opcion = sel.selectedOptions && sel.selectedOptions[0];
  const ficha = typeof fichaEquipo === "function" ? fichaEquipo(id) : null;
  const nombre = (ficha && ficha.nombre) || (opcion ? opcion.textContent : "Sopa");
  const rol = ficha && ficha.rol ? " · " + ficha.rol : "";
  const marca = estado.equipoEstado || "listo";
  caja.textContent = nombre + rol + " · " + etiquetaEstadoEquipo(marca);
  caja.dataset.estado = marca;
  const especialista = id !== "chat";
  caja.classList.toggle("especialista", especialista);
  sel.classList.toggle("especialista", especialista);
  // El color del agente sale de tokens.css (--ag-<id>) por data-agente.
  const vista = document.getElementById("vista-chat");
  if (vista) vista.dataset.agente = id;
  pintarCarasEquipo();
  if (typeof pintarChipsEquipo === "function") pintarChipsEquipo();
  if (typeof pintarSala === "function") pintarSala();
}

async function cargarAgentesChat() {
  const sel = $("#chat-agente");
  if (!sel) return;
  const previo = sel.value || "chat";
  let datos = null;
  try { datos = await api().agentes_del_chat(); }
  catch (e) { datos = null; }
  if (!datos || !datos.agentes || !datos.agentes.length) {
    pintarAgenteActivo();
    return;
  }
  const lista = datos.agentes;
  estado.equipo = lista;
  estado.caras = datos.caras || {};
  estado.e2e = datos.e2e === true;
  if (Array.isArray(datos.avatares)) estado.avatares = datos.avatares;
  if (Array.isArray(datos.colores)) estado.colores = datos.colores;
  if (typeof pintarColoresAgentes === "function") pintarColoresAgentes(lista);
  sel.innerHTML = lista.map((a) => {
    // Los agentes propios van con el plan, como los especialistas; los compañeros persona, siempre.
    const off = a.id !== "chat" && (a.persona !== true || a.propio === true) && datos.permitido === false;
    return `<option value="${esc(a.id)}"${off ? " disabled" : ""}>${esc(a.nombre)}</option>`;
  }).join("");
  const cabe = [...sel.options].some((o) => o.value === previo && !o.disabled);
  sel.value = cabe ? previo : "chat";
  sel.title = datos.permitido === false && datos.aviso ? datos.aviso : "Elige quién responde";
  pintarAgenteActivo();
  if (typeof pintarOnboardingEquipo === "function") pintarOnboardingEquipo();
  if (typeof prepararHilo === "function") prepararHilo();
}

function aplicarBuscarWeb(on) {
  const activo = on === true;
  const caja = $("#web-on");
  const boton = $("#chat-web");
  const nota = $("#aviso-privado-texto");
  if (caja) caja.checked = activo;
  if (boton) {
    boton.setAttribute("aria-pressed", activo ? "true" : "false");
    boton.setAttribute("aria-checked", activo ? "true" : "false");
    boton.classList.toggle("encendido", activo);
    boton.title = activo ? "Buscar en la web está encendido" : "Buscar en la web está apagado";
  }
  if (nota) nota.textContent = activo ? "Búsqueda web encendida" : "Todo ocurre en este equipo";
  const chip = $("#web-chip");
  if (chip) { chip.hidden = !activo; chip.title = "Buscar en la web está encendido"; }
  if (!estado.mensajes.length) pintarMensajes();
}

function etiquetaComprobacion(m) {
  if (!m || !m.comprobacion || m.enCurso) return "";
  return htmlEtiquetaComprobacion(m, estado.mensajes.indexOf(m));  // ratón: title; clic: la explicación
}

async function pintarComprobar() {
  const a = await api().ajustes();
  const caja = $("#comprobar-on");
  if (caja) caja.checked = a.comprobar_codigo !== false;
}

async function pintarBuscarWeb() {
  const a = await api().ajustes();
  aplicarBuscarWeb(a.buscar_web === true);
}

async function cambiarBuscarWeb(on) {
  const r = await api().guardar_ajustes({ buscar_web: on === true });
  aplicarBuscarWeb(r && r.ajustes ? r.ajustes.buscar_web === true : on === true);
}

function pintarPlan(pasos) {
  const caja = $("#chat-plan");
  if (!caja) return;
  const lista = Array.isArray(pasos) ? pasos : [];
  if (!lista.length) { caja.hidden = true; caja.innerHTML = ""; return; }
  caja.hidden = false;
  caja.innerHTML = lista.map((p) => `<li data-estado="${esc(p.estado || "pendiente")}">${esc(p.texto || "")}</li>`).join("");
}

function pintarEstado(texto) {
  const caja = $("#chat-estado");
  if (!caja) return;
  const visible = String(texto || "").trim();
  if (!visible && estado.cargandoModelo && caja.classList.contains("chat-estado-cargando")) return;
  caja.classList.remove("chat-estado-cargando");
  caja.hidden = !visible;
  caja.textContent = visible;
}

function paradaVisible(on) {
  const caja = $("#chat-progreso");
  if (!caja) return;
  if (on) {
    caja.hidden = false;
    caja.classList.add("solo-parar");
    return;
  }
  caja.classList.remove("solo-parar");
  if (!caja.classList.contains("con-barra")) caja.hidden = true;
}

function pintarProgreso(ev) {
  const caja = $("#chat-progreso");
  const barra = $("#chat-progreso-barra");
  if (!caja || !barra) return;
  const hechos = Number(ev.bloques) || 0;
  const objetivo = Number(ev.objetivo) || 0;
  const ancho = objetivo > 0 ? Math.min(100, Math.round((hechos / objetivo) * 100)) : 0;
  barra.style.width = ancho + "%";
  caja.classList.remove("solo-parar");
  caja.classList.add("con-barra");
  caja.hidden = ev.activo === false && hechos === 0;
  if (ev.activo === false && hechos > 0) caja.hidden = false;
}

const cacheMarkdown = new WeakMap();
let pintadoTimer = 0;
let pintadoModo = false;

function aplazarPintado(pensando) {
  pintadoModo = pensando;
  if (pintadoTimer) return;
  pintadoTimer = setTimeout(() => {
    pintadoTimer = 0;
    pintarMensajes(pintadoModo);
  }, 100);
}

function cabeceraAgente(m) {
  if (!m || m.role !== "assistant") return "";
  // Lavado de cara: el que habla en su propio hilo ya está en la cabecera; solo se firma si responde otro.
  const activo = (document.getElementById("chat-agente") || {}).value || "chat";
  if (!m.agente_nombre && (m.agente || "chat") === activo) return "";
  const ficha = typeof fichaEquipo === "function" ? fichaEquipo(m.agente || "chat") : null;
  const nombre = m.agente_nombre || (ficha && ficha.nombre) || "Sopa";
  const rol = (ficha && ficha.rol) || "";
  const base = ficha || { emoji: "🥣", animacion: "vapor", avatar: "sprout", cara: "avatares/sprout" };
  const cara = typeof htmlAvatar === "function"
    ? htmlAvatar(base)
    : `<span class="avatar" data-anim="${esc(base.animacion || "vapor")}" aria-hidden="true">${esc(base.emoji || "🥣")}</span>`;
  return `<div class="quien" data-agente="${esc(m.agente || "chat")}">${cara}<span><b>${esc(nombre)}</b>${rol ? `<small>${esc(rol)}</small>` : ""}</span></div>`;
}

function htmlDelMensaje(m) {
  if (!m.enCurso) return markdownSeguro(m.content);
  let cache = cacheMarkdown.get(m);
  if (!cache) {
    cache = {};
    cacheMarkdown.set(m, cache);
  }
  return markdownEnCurso(m.content || "", cache);
}

function notaRazonGptOss(m) {
  if (!m || !m.razonamiento) return "";
  if (!/gpt-oss/i.test(String(estado.modeloChat || ""))) return "";
  return `<p class="nota-razon">Este modelo razona en inglés; la respuesta va en tu idioma.</p>`;
}

// Solo sigue el texto si ya estaba al final; «Ir al final» lo vuelve a activar.
let seguidorChat = null;
function seguidor() {
  if (!seguidorChat) {
    const caja = $("#mensajes");
    seguidorChat = seguirAlFinal(caja, $("#ir-al-final"));
    caja.addEventListener("click", (e) => {
      if (typeof alPulsarLeerVoz === "function" && alPulsarLeerVoz(e)) return;
      if (!alPulsarComprobacion(e, estado.mensajes)) alPulsarCopiar(e, caja);
    });
  }
  return seguidorChat;
}

function pintarMensajes(pensando) {
  if (pintadoTimer) { clearTimeout(pintadoTimer); pintadoTimer = 0; }
  const caja = $("#mensajes");
  if (typeof rescatarClipsHilo === "function") rescatarClipsHilo();
  if (typeof clSiCambiaLaConversacion === "function") clSiCambiaLaConversacion();
  const seg = seguidor();
  guardarCajas(caja);
  const webOn = $("#chat-web") && $("#chat-web").getAttribute("aria-pressed") === "true";
  const lista = estado.mensajes.filter((m) => !(m.enCurso && !String(m.content || "").trim()));
  estado.listaPintada = lista;
  const ultimo = lista[lista.length - 1];
  const cursor = !!(pensando === false && ultimo && ultimo.enCurso) || !!(pensando && ultimo && ultimo.enCurso && ultimo.content);
  caja.innerHTML = lista.map((m, i) => m.role === "assistant"
    ? `<div class="msg assistant"><div>${cabeceraAgente(m)}${notaRazonGptOss(m)}${m.razonamiento ? `<details class="razonamiento"><summary>Ver cómo lo ha pensado</summary>${esc(m.razonamiento)}</details>` : ""}${htmlDelMensaje(m)}${cursor && i === lista.length - 1 ? `<span class="escribiendo"></span>` : ""}${enlacesWeb(m.herramienta)}${capturasEjecucion(m.herramienta)}${typeof tarjetasImagen === "function" ? tarjetasImagen(m.herramienta) : ""}${typeof tarjetasVideo === "function" ? tarjetasVideo(m.herramienta) : ""}${m.fuentes && m.fuentes.length ? `<div class="fuentes">${m.fuentes.map((f, i) => `<span class="chip" title="${esc(f.texto.slice(0, 300))}">[${i + 1}] ${esc(f.nombre)}${f.pagina ? " · p. " + f.pagina : ""}</span>`).join("")}</div>` : ""}${m.citas && m.citas.invalidas && m.citas.invalidas.length ? `<small class="aviso-cita">Cita ${m.citas.invalidas.map((n) => "[" + n + "]").join(", ")}, que no está entre las fuentes: compruébalo.</small>` : ""}${m.cortada && !m.enCurso ? `<p class="corte"><small>La respuesta se cortó por larga.</small> <button type="button" class="continuar">Continuar</button></p>` : ""}${m.resumir && !m.enCurso ? `<p class="corte"><button type="button" class="resumir">Resumir y seguir</button></p>` : ""}${etiquetaComprobacion(m)}${typeof botonLeerVoz === "function" ? botonLeerVoz(m, i) : ""}${m.segundos ? `<small class="meta">${m.segundos} s</small>` : ""}</div></div>`
    : `<div class="msg ${m.role}">${esc(m.content)}</div>`).join("") +
    (pensando && !cursor ? `<div class="msg assistant"><div>${cabeceraAgente({ role: "assistant", agente: estado.agenteTurno })}<span class="escribiendo"></span></div></div>` : "");
  if (!estado.mensajes.length && !pensando) {
    const fichaVacia = typeof fichaEquipo === "function" ? fichaEquipo(($("#chat-agente") && $("#chat-agente").value) || "chat") : null;
    const nombreVacio = (fichaVacia && fichaVacia.nombre) || "Sopa";
    caja.innerHTML = estado.hayModelos === false
    ? vacio("chat", "Aún no tienes ningún modelo", "Descarga uno en Modelos; Sopa te dirá cuáles van bien en tu equipo.", `<button class="primario" onclick="mostrarVista('modelos')">Ver modelos</button>`)
    : vacio("chat", `Habla con ${nombreVacio}`, webOn
      ? "Web está encendido: si lo pides, busco en la web y leo una página. Este hilo es solo suyo."
      : "Este hilo es solo suyo. Lo que le pidas que recuerde se queda con él.",
      `<div class="ideas">${["Resume este texto en tres puntos", "Escribe un correo amable para pedir un cambio de turno", "Explícame qué es la inflación con un ejemplo", "Dame ideas para una cena con lo que tengo en la nevera"].map((t) => `<button class="idea">${t}</button>`).join("")}</div>`);
  }
  caja.querySelectorAll(".idea").forEach((b) => b.onclick = () => { $("#chat-texto").value = b.textContent; $("#chat-texto").focus(); });
  caja.querySelectorAll("button.continuar").forEach((b) => { b.onclick = () => continuar(); });
  caja.querySelectorAll("button.resumir").forEach((b) => { b.onclick = () => resumirConversacion(); });
  restaurarCajas(caja);
  if (typeof montarAvatares === "function") montarAvatares(caja);
  seg.pintado();
}

// «Sopa usará X porque…»: el modelo se elige solo según la tarea; el desplegable permite cambiarlo.
// La nota (i) del menú de modelo dice qué elige Automático y por qué.
async function pintarEleccionChat() {
  const caja = $("#chat-eleccion");
  if (!caja) return;
  const manual = modeloDeConv(estado.conversacion);
  const enMarcha = estado.modeloEnUso && estado.modeloEnUso.activo;
  if (manual || enMarcha) {
    if (manual) caja.innerHTML = `${svgS("info")}<span>Elegido a mano para esta conversación. Las demás siguen en Automático.</span>`;
    else if (estado.modeloEnUso.nombre) caja.innerHTML = `${svgS("info")}<span>En uso: <b>${esc(estado.modeloEnUso.nombre)}</b>.</span>`;
    pintarBotonModelo();
    return;
  }
  const tarea = $("#chat-tarea").value;
  const r = await api().elegir_modelo(estado.docs.length && tarea === "charlar" ? "documentos" : tarea);
  // Mientras tanto la persona pudo elegir, o la página ya sabe qué modelo está en marcha.
  if (modeloDeConv(estado.conversacion) || (estado.modeloEnUso && estado.modeloEnUso.activo)) { pintarBotonModelo(); return; }
  if (!r.ok) { caja.innerHTML = ""; return; }
  if (r.elegido && r.elegido.ruta) $("#chat-modelo").value = r.elegido.ruta;
  estado.eleccionAuto = r.elegido ? r.elegido.nombre : "";
  caja.innerHTML = textoEleccion(r);
  pintarMenuModelo();
}

function textoEleccion(r, extra = "") {
  const sug = r.sugerencia ? ` Mejor aún para tu equipo: <b>${esc(r.sugerencia.nombre)}</b> (${r.sugerencia.gb} GB). ${esc(r.sugerencia.por_que)} <button type="button" class="btn texto" data-vista="modelos">Ver en Modelos</button>` : "";
  if (!r.elegido) return `${svgS(r.puede === false ? "error" : "info")}<span>${esc(r.aviso || r.motivo || "")}${r.sugerencia ? ` <button type="button" class="btn texto" data-vista="modelos">Ver modelos</button>` : ""}</span>`;
  return `${svgS(r.aviso ? "aviso" : "info")}<span>${fraseEleccion(r)}${r.aviso ? " " + esc(r.aviso) : ""}${extra ? ` ${esc(extra)}` : ""}${sug}</span>`;
}
// La nota (i) del menú de modelo, en una frase y sin repetir el nombre: «Qwen3 4B cabe entero en tu gráfica y va con fluidez.»
// Los textos son los de seleccion.TEXTO_MODO. Si el modo no se sabe, se usa el motivo del backend sin su «Nombre:».
const TEXTO_MODO_CHAT = {
  gpu: "cabe entero en tu gráfica y va con fluidez",
  mixto: "se reparte entre tu gráfica y la memoria; va algo más lento",
  cpu: "funciona en el procesador; irá lento",
};
// La nota (i) va justo debajo de «Automático · Nombre»: no repite el nombre ni manda al menú de modelos.
function fraseEleccion(r) {
  const e = r.elegido || {}, nombre = String(e.nombre || e.id || "");
  const motivo = String(r.motivo || "").replace(/^[^:]*:\s*/, "");
  const pequeno = /Es pequeño: con documentos puede citar peor\./.test(motivo) ? " Es pequeño: con documentos puede citar peor." : "";
  const mayus = (t) => t ? t[0].toUpperCase() + t.slice(1) : t;
  const modo = /equipo más potente/.test(motivo) ? "" : TEXTO_MODO_CHAT[e.chat];
  if (modo) return `${esc(mayus(modo))}.${pequeno}`;
  let resto = motivo;
  if (nombre && resto.toLowerCase().startsWith(nombre.toLowerCase())) resto = resto.slice(nombre.length).replace(/^[\s,:]+/, "");
  return esc(mayus(resto));
}

const minus = (t) => t ? t[0].toLowerCase() + t.slice(1) : "";

// Se carga al elegirlo. Mientras, el botón queda desactivado y #chat-estado lo cuenta.
// No hay cancelar: la carga no se puede interrumpir, pero se puede ir escribiendo.
async function cargarChat(ruta, contexto) {
  if (!ruta) return;
  if (!(await aceptarSinCensuraSiToca(ruta))) return;
  const m = (estado.modelosLocales || []).find((x) => x.ruta === ruta);
  const nombre = m ? nombreModelo(m) : "el modelo";
  const boton = $("#boton-modelo"), texto = $("#boton-modelo-texto");
  const est = $("#chat-estado");
  estado.cargandoModelo = true;
  cerrarMenus();
  if (boton) { boton.disabled = true; boton.setAttribute("aria-busy", "true"); boton.classList.add("cargando"); }
  if (texto) texto.textContent = `Cargando ${nombre}…`;
  if (est && !estado.enviando) {
    est.classList.add("chat-estado-cargando");
    est.innerHTML = `${svgS("cargando")}<span>Cargando ${esc(nombre)}. Puede tardar hasta 2 minutos (10 la primera vez) y no se puede interrumpir; puedes ir escribiendo.</span>`;
    est.hidden = false;
  }
  let r;
  const ctx = Number(contexto);
  const conCtx = Number.isFinite(ctx) && ctx >= 128;
  try { r = await api().chat_cargar(ruta, conCtx ? ctx : null, "escritorio", true); } finally {
    estado.cargandoModelo = false;
    if (boton) { boton.disabled = false; boton.removeAttribute("aria-busy"); boton.classList.remove("cargando"); }
    if (est && est.classList.contains("chat-estado-cargando")) { est.classList.remove("chat-estado-cargando"); est.innerHTML = ""; est.hidden = true; }
    pintarBotonModelo();
  }
  if (!r.ok) return fallo("#aviso-chat", r.error);
  estado.modeloManualCargado = ruta;
  estado.modeloEnUso = { ok: true, activo: true, explicito: true, ruta, id: r.modelo, contexto: r.contexto, nombre };
  const donde = r.reparto === "gpu" ? "en la gráfica" : r.reparto === "mixto"
    ? `repartido entre la gráfica y la memoria (${r.capas_gpu} de ${r.capas_total} partes en la gráfica; irá algo más lento)` : "en el procesador (irá más lento)";
  estado.modeloChat = r.modelo;
  $("#chat-eleccion").innerHTML = `${svgS(r.reparto === "gpu" ? "ok" : "info")}<span>${esc(nombre)} listo ${esc(donde)}. Solo para esta conversación.</span>`;
  pintarMenuModelo();
}

// Mientras el modelo escribe, el texto no llega por evaluate_js (se queda pillado
// con la respuesta entera). Se pide a trozos, por la misma vía que Parar.
function aplicarCurso(r) {
  if (!r || !r.ok || !r.id || r.id !== estado.conversacion) return r && r.hay_mas ? 40 : 350;
  if (r.gen && r.gen !== estado.cursoGen) {
    estado.cursoGen = r.gen;
    estado.cursoDesde = 0;
    estado.cursoTexto = "";
    if (r.desde) return 40;
  }
  const caja = $("#chat-estado");
  const actual = caja ? caja.textContent : "";
  const nuevo = String(r.estado || "");
  if (nuevo) {
    if (nuevo !== actual) pintarEstado(nuevo);
  } else if (actual === "Preparando la respuesta…" || actual.indexOf("Leyendo el contexto") === 0) {
    pintarEstado("");
  }
  const desde = Number(r.desde) || 0;
  if (r.rehacer) {
    estado.cursoTexto = String(r.texto || "");
    estado.cursoDesde = Number(r.hasta) || estado.cursoTexto.length;
  } else if (desde === (estado.cursoDesde || 0)) {
    const parte = String(r.texto || "");
    estado.cursoTexto = (estado.cursoTexto || "") + parte;
    estado.cursoDesde = Number(r.hasta) || ((estado.cursoDesde || 0) + parte.length);
  } else {
    return 40;
  }
  const visible = estado.cursoTexto || "";
  if (!String(visible).trim()) {
    if (r.rehacer) {
      const vacioEnCurso = estado.mensajes[estado.mensajes.length - 1];
      if (vacioEnCurso && vacioEnCurso.enCurso) vacioEnCurso.content = "";
      pintarMensajes(true);
    }
    return r.hay_mas ? 40 : 350;
  }
  const pintado = estado.prefijoContinuar ? estado.prefijoContinuar + visible : visible;
  const ultimo = estado.mensajes[estado.mensajes.length - 1];
  if (!ultimo || ultimo.role !== "assistant" || !ultimo.enCurso) {
    const ficha = typeof fichaEquipo === "function" ? fichaEquipo(estado.agenteTurno) : null;
    estado.mensajes.push({
      role: "assistant", content: pintado, origen: "escritorio", enCurso: true,
      agente: estado.agenteTurno || "chat", agente_nombre: ficha && ficha.nombre,
    });
  } else {
    ultimo.content = pintado;
  }
  aplazarPintado(false);
  return r.hay_mas ? 40 : 350;
}

function pedirCurso() {
  if (!estado.enviando || estado.cursoPidiendo) return;
  const marca = estado.cursoMarca;
  estado.cursoPidiendo = true;
  const desde = estado.cursoDesde || 0;
  api().chat_en_curso(desde).then((r) => {
    if (marca !== estado.cursoMarca) return;
    estado.cursoPidiendo = false;
    if (!estado.enviando) return;
    const espera = aplicarCurso(r);
    estado.cursoTimer = setTimeout(pedirCurso, espera);
  }).catch(() => {
    if (marca !== estado.cursoMarca) return;
    estado.cursoPidiendo = false;
    if (estado.enviando) estado.cursoTimer = setTimeout(pedirCurso, 500);
  });
}

function empezarCurso() {
  if (estado.cursoTimer) { clearTimeout(estado.cursoTimer); estado.cursoTimer = 0; }
  estado.cursoMarca = (estado.cursoMarca || 0) + 1;
  estado.cursoPidiendo = false;
  estado.cursoDesde = 0;
  estado.cursoTexto = "";
  estado.cursoGen = 0;
  pedirCurso();
}

// Imagen adjunta en la Sala: se copia a Sopa y el modelo solo ve su nombre (adj-….png).
async function adjuntarImagen() {
  const r = await api().adjuntar_imagen();
  if (!r || r.cancelado) return;
  if (!r.ok) { toast(r.error || "No he podido adjuntar la imagen."); return; }
  estado.imagenAdjunta = r.adjunto;
  pintarImagenAdjunta(r.vision === false ? "El modelo cargado no ve imágenes: carga uno con la visión añadida." : "");
  $("#chat-texto").focus();
}
function pintarImagenAdjunta(avisoVision) {
  const chip = $("#imagen-chip");
  if (!chip) return;
  chip.hidden = !estado.imagenAdjunta;
  $("#imagen-chip-texto").textContent = estado.imagenAdjunta ? "Imagen adjunta" : "Imagen";
  chip.title = avisoVision || "";
  if (avisoVision) toast(avisoVision);
}
function textoConImagen(texto) {
  if (!estado.imagenAdjunta) return texto;
  const t = `[Imagen adjunta: ${estado.imagenAdjunta}]\n${texto || "¿Qué se ve en esta imagen?"}`;
  estado.imagenAdjunta = null;
  pintarImagenAdjunta("");
  return t;
}

async function enviar(ev) {
  ev.preventDefault();
  if (estado.ocupadoMovil) return;
  const escrito = $("#chat-texto").value.trim();
  if (!escrito && !estado.imagenAdjunta) return;
  const texto = textoConImagen(escrito);
  $("#chat-texto").value = "";
  estado.hiloToken = (estado.hiloToken || 0) + 1;
  const agenteEnvio = ($("#chat-agente") && $("#chat-agente").value) || "chat";
  estado.agenteTurno = agenteEnvio;
  estado.mensajes.push({ role: "user", content: texto, origen: "escritorio" });
  seguidor().irAlFinal();
  if (typeof marcarEstadoEquipo === "function") marcarEstadoEquipo("trabajando");
  pintarMensajes(true);
  $("#propuesta-accion").innerHTML = "";
  pintarPlan([]);
  pintarEstado("Preparando la respuesta…");
  const nueva = !estado.conversacion;
  estado.conversacion = estado.conversacion || "conv-" + Date.now();
  if (nueva) api().hilo_fijar(agenteEnvio, estado.conversacion);
  if (typeof recordarHiloLocal === "function") recordarHiloLocal(agenteEnvio);
  // El modelo elegido a mano vale solo para esta conversación; Automático suelta el manual.
  try { await prepararModeloConv(); } catch (e) { /* si falla, chat_enviar avisa */ }
  const convEnvio = estado.conversacion;
  const mensajesEnvio = estado.mensajes.slice();
  const docsEnvio = estado.docs.map((d) => d.id);
  estado.enviando = true;
  paradaVisible(true);
  empezarCurso();
  try {
    const r = await api().chat_enviar(mensajesEnvio, 0.7, false, docsEnvio, $("#chat-tarea").value, convEnvio, "escritorio", agenteEnvio);
    if (!r.ok) {
      while (estado.mensajes.length && estado.mensajes[estado.mensajes.length - 1].enCurso) estado.mensajes.pop();
      if (estado.mensajes.length && estado.mensajes[estado.mensajes.length - 1].role === "user") estado.mensajes.pop();
      pintarMensajes();
      pintarEstado("");
      if (typeof marcarEstadoEquipo === "function") marcarEstadoEquipo("error");
      return fallo("#aviso-chat", r.error);
    }
    if (r.modelo_auto) avisoModeloAuto(r.modelo_auto, "#aviso-chat");
    estado.enviando = false;
    const sigueAqui = (($("#chat-agente") && $("#chat-agente").value) || "chat") === agenteEnvio;
    const fichaTurno = typeof fichaEquipo === "function" ? fichaEquipo(r.agente || agenteEnvio) : null;
    const burbuja = { role: "assistant", content: r.respuesta, razonamiento: r.razonamiento || "", fuentes: r.fuentes || [], citas: r.citas || null, cortada: r.cortada, resumir: !!r.ofrecer_resumen, tps: r.tokens_por_segundo, segundos: r.segundos, origen: "escritorio", herramienta: r.uso_herramienta || null, comprobacion: r.comprobacion || null, agente: r.agente || agenteEnvio, agente_nombre: r.agente_nombre || (fichaTurno && fichaTurno.nombre) || "" };
    const historialEnvio = mensajesEnvio.slice();
    historialEnvio.push(burbuja);
    if (sigueAqui) {
      const ultimo = estado.mensajes[estado.mensajes.length - 1];
      if (ultimo && ultimo.enCurso) estado.mensajes[estado.mensajes.length - 1] = burbuja;
      else estado.mensajes.push(burbuja);
      pintarMensajes();
      if (typeof marcarEstadoEquipo === "function") marcarEstadoEquipo("listo");
      if (r.propuesta_accion) pintarPropuesta(r.propuesta_accion);
      else $("#propuesta-accion").innerHTML = "";
      if (r.plan) pintarPlan(r.plan);
      if (r.parada || !String(r.estado || "").trim()) pintarEstado("");
      else pintarEstado(r.estado);
    } else {
      estado.hilos = estado.hilos || {};
      estado.hilos[agenteEnvio] = { id: convEnvio, mensajes: historialEnvio, documentos: estado.docs || [], version: estado.versionConv || 0 };
    }
    if (r.propuesta_memoria || r.propuesta_agente) {
      proponerMemoria(r.propuesta_agente || r.propuesta_memoria, {
        agente: r.agente || agenteEnvio,
        globalMemoria: !!r.propuesta_memoria,
        agenteMemoria: !!r.propuesta_agente,
      });
    }
    const guardada = await api().guardar_conversacion(convEnvio, { titulo: historialEnvio[0].content.slice(0, 60), modelo: estado.modeloChat || "", documentos: estado.docs, actualizada: new Date().toISOString(), origen: "escritorio", agente: agenteEnvio, mensajes: sigueAqui ? estado.mensajes : historialEnvio });
    if (guardada && guardada.version) {
      if (sigueAqui) estado.versionConv = guardada.version;
      if (estado.hilos && estado.hilos[agenteEnvio]) estado.hilos[agenteEnvio].version = guardada.version;
    }
    if (sigueAqui && typeof recordarHiloLocal === "function") recordarHiloLocal(agenteEnvio);
    else if (!sigueAqui) {
      estado.previews = estado.previews || {};
      if (typeof textoPreview === "function") estado.previews[agenteEnvio] = textoPreview(r.respuesta);
      if (typeof pintarSala === "function") pintarSala();
    }
    if (nueva && sigueAqui) cargarModelosChat();
    if (sigueAqui && typeof pintarResumido === "function") pintarResumido(convEnvio);
  } finally {
    estado.enviando = false;
    paradaVisible(false);
    if (estado.equipoEstado === "trabajando" && typeof marcarEstadoEquipo === "function") marcarEstadoEquipo("listo");
  }
}

async function resumirConversacion() {
  if (!estado.conversacion || estado.enviando) return;
  const r = await api().chat_resumir(estado.conversacion, "escritorio");
  if (!r.ok) return fallo("#aviso-chat", r.error);
  if (Array.isArray(r.mensajes) && r.mensajes.length) {
    estado.mensajes = r.mensajes.map((m) => ({
      role: m.role, content: m.content || "", origen: m.origen || "escritorio",
      razonamiento: m.razonamiento || "", cortada: !!m.cortada,
      agente: m.agente, agente_nombre: m.agente_nombre,
    }));
    pintarMensajes();
    const guardada = await api().guardar_conversacion(estado.conversacion, {
      titulo: (estado.mensajes.find((m) => m.role === "user") || { content: "Conversación" }).content.slice(0, 60),
      modelo: estado.modeloChat || "", documentos: estado.docs, actualizada: new Date().toISOString(),
      origen: "escritorio", mensajes: estado.mensajes,
    });
    if (guardada && guardada.version) estado.versionConv = guardada.version;
  }
}

async function continuar() {
  let indice = -1;
  for (let i = estado.mensajes.length - 1; i >= 0; i--) {
    const item = estado.mensajes[i];
    if (item.role === "assistant" && item.cortada && !item.enCurso) { indice = i; break; }
  }
  const m = indice >= 0 ? estado.mensajes[indice] : null;
  if (!m || estado.enviando || estado.ocupadoMovil) return;
  estado.enviando = true;
  paradaVisible(true);
  empezarCurso();
  estado.prefijoContinuar = m.content || "";
  m.enCurso = true;
  pintarMensajes(false);
  try {
    const r = await api().chat_continuar(estado.mensajes, 0.7, false, estado.conversacion, "escritorio");
    m.enCurso = false;
    if (!r.ok) {
      pintarMensajes();
      return fallo("#aviso-chat", r.error);
    }
    m.content = (estado.prefijoContinuar || "") + (r.respuesta || "");
    m.cortada = !!r.cortada;
    m.resumir = !!r.ofrecer_resumen;
    if (r.razonamiento) m.razonamiento = [m.razonamiento, r.razonamiento].filter(Boolean).join("\n");
    if (r.segundos) m.segundos = r.segundos;
    pintarMensajes();
    const guardada = await api().guardar_conversacion(estado.conversacion, { titulo: estado.mensajes[0].content.slice(0, 60), modelo: estado.modeloChat || "", documentos: estado.docs, actualizada: new Date().toISOString(), origen: "escritorio", mensajes: estado.mensajes });
    if (guardada && guardada.version) estado.versionConv = guardada.version;
  } finally {
    estado.prefijoContinuar = "";
    estado.enviando = false;
    paradaVisible(false);
    if (m) m.enCurso = false;
  }
}

async function cargarComparar() {
  const sel = $("#comparar-modelo");
  const caja = $("#aviso-comparar");
  if (!sel || !caja) return;
  const r = await api().modelos_locales();
  const propios = (r.modelos || []).filter((m) => m.personalizado);
  if (!propios.length) {
    sel.innerHTML = "";
    caja.innerHTML = aviso("info", "Todavía no tienes un modelo personalizado. Entrénalo en Entrenamiento y vuelve aquí.");
    $("#comparar-enviar").disabled = true;
    $("#comparar-titulo-base").textContent = "Base";
    $("#comparar-titulo-mio").textContent = "Personalizado";
    return;
  }
  const previo = sel.value;
  sel.innerHTML = propios.map((m) => `<option value="${esc(m.id)}">${esc(m.id.slice(4))}</option>`).join("");
  if ([...sel.options].some((o) => o.value === previo)) sel.value = previo;
  await pintarPareja();
}

async function pintarPareja() {
  const sel = $("#comparar-modelo");
  const caja = $("#aviso-comparar");
  if (!sel || !sel.value) return;
  const r = await api().pareja_modelo(sel.value);
  if (!r.ok) {
    caja.innerHTML = aviso("err", esc(r.error));
    $("#comparar-enviar").disabled = true;
    $("#comparar-titulo-base").textContent = "Base";
    return;
  }
  estado.pareja = r;
  $("#comparar-titulo-mio").textContent = "Personalizado · " + r.personalizado.nombre;
  $("#comparar-titulo-base").textContent = "Base · " + r.base.nombre;
  if (!r.base.descargado) {
    caja.innerHTML = aviso("warn", `Falta el modelo base «${esc(r.base.nombre)}». Descárgalo en Modelos y vuelve a comparar.`);
    $("#comparar-enviar").disabled = true;
    return;
  }
  if (!estado.comparando) caja.innerHTML = "";
  $("#comparar-enviar").disabled = false;
}

async function comparar(ev) {
  if (ev) ev.preventDefault();
  const sel = $("#comparar-modelo");
  const pregunta = $("#comparar-texto").value.trim();
  const caja = $("#aviso-comparar");
  if (!sel || !sel.value) {
    caja.innerHTML = aviso("info", "Elige un modelo personalizado.");
    return;
  }
  if (!pregunta) {
    caja.innerHTML = aviso("err", "Escribe una pregunta para comparar.");
    return;
  }
  estado.comparando = true;
  $("#comparar-enviar").disabled = true;
  $("#comparar-base").textContent = "";
  $("#comparar-mio").textContent = "";
  caja.innerHTML = aviso("info", "Primero responde el modelo base. Después se carga el personalizado.");
  let r;
  try {
    r = await api().comparar_modelos(sel.value, pregunta);
  } catch (e) {
    r = { ok: false, error: "No he podido comparar los dos modelos." };
  }
  estado.comparando = false;
  if (r.base && r.base.texto != null) $("#comparar-base").textContent = r.base.texto;
  if (r.personalizado && r.personalizado.texto != null) $("#comparar-mio").textContent = r.personalizado.texto;
  if (r.base && r.base.nombre) $("#comparar-titulo-base").textContent = "Base · " + r.base.nombre;
  if (r.personalizado && r.personalizado.nombre) $("#comparar-titulo-mio").textContent = "Personalizado · " + r.personalizado.nombre;
  caja.innerHTML = r.ok
    ? aviso("ok", "Misma pregunta, dos respuestas. El personalizado queda cargado en el chat.")
    : aviso("err", esc(r.error || "No he podido comparar los dos modelos."));
  const faltaBase = !r.ok && String(r.error || "").startsWith("Falta el modelo base");
  $("#comparar-enviar").disabled = faltaBase;
}

function avisoModeloAuto(m, caja) {
  estado.modeloChat = m.id;
  if (m.ruta) $("#chat-modelo").value = m.ruta;
  estado.eleccionAuto = m.nombre || estado.eleccionAuto;
  estado.modeloManualCargado = "";
  // Ya no hay recuadro en el chat: lo cuenta la nota (i) del menú de modelo.
  $("#chat-eleccion").innerHTML = `${svgS("ok")}<span>Sopa ha cargado <b>${esc(m.nombre)}</b> porque ${esc(minus(m.motivo.replace(/^[^:]*:\s*/, "")))}</span>`;
  if (caja !== "#aviso-chat") $(caja).innerHTML = aviso("ok", `Sopa ha cargado <b>${esc(m.nombre)}</b>.`);
  pintarMenuModelo();
}

function pintarPropuesta(p) {
  const caja = $("#propuesta-accion");
  if (!p) { caja.innerHTML = ""; return; }
  if (p.rechazada || !p.id) {
    caja.innerHTML = aviso("warn", esc(p.que || "No he hecho nada."));
    return;
  }
  const rutas = (p.rutas || []).map((r) => `<li>${esc(r.donde || "En")} <b>${esc(r.carpeta)}</b>: ${esc(r.ruta)}</li>`).join("");
  const contenido = p.contenido != null ? `<pre class="vista-previa">${esc(p.contenido)}</pre>` : "";
  // crear_documento: el texto es Markdown; esto dice cómo se maqueta (Word, Excel, PowerPoint o PDF).
  const doc = p.documento && p.documento.texto ? `<p class="propuesta-documento">Se crea como ${esc(p.documento.texto)}.</p>` : "";
  const sobre = p.aviso ? aviso("warn", esc(p.aviso)) : "";
  const guardar = p.accion === "plan" ? `<button class="fantasma" id="prop-auto" type="button">Guardar automatización</button>` : "";
  caja.innerHTML = `<div class="tarjeta propuesta-accion"><b>${esc(p.que)}</b><ul>${rutas}</ul>${doc}${contenido}${sobre}<div class="acciones"><button class="primario" id="prop-si" type="button">Confirmar</button><button class="fantasma" id="prop-no" type="button">Cancelar</button>${guardar}</div></div>`;
  $("#prop-no").onclick = () => cancelarPropuesta(p.id);
  $("#prop-si").onclick = () => confirmarPropuesta(p.id, false);
  if ($("#prop-auto")) $("#prop-auto").onclick = () => pedirAutomatizacion(p.id);
}

function pedirAutomatizacion(id) {
  const caja = $("#propuesta-accion .acciones");
  if (!caja || $("#prop-auto-form")) return;
  caja.insertAdjacentHTML("beforeend", `<div id="prop-auto-form"><label>Nombre <input id="prop-auto-nombre" maxlength="80" autocomplete="off"></label><label>Cuándo <select id="prop-auto-cuando"><option value="manual">Con el botón</option><option value="diario">Cada día</option><option value="semanal">Cada semana</option><option value="una_vez">Una vez</option><option value="carpeta">Cuando aparezca un archivo</option></select></label><label>Hora <input id="prop-auto-hora" value="08:30" autocomplete="off"></label><label>Día <select id="prop-auto-dia"><option value="0">Lunes</option><option value="1">Martes</option><option value="2">Miércoles</option><option value="3">Jueves</option><option value="4">Viernes</option><option value="5">Sábado</option><option value="6">Domingo</option></select></label><label>Momento <input id="prop-auto-momento" placeholder="2026-10-16T08:30" autocomplete="off"></label><label class="interruptor"><input type="checkbox" id="prop-auto-ok"> Confirmo este plan exacto y estas carpetas</label><div id="prop-auto-lineas"></div><button class="primario" id="prop-auto-guardar" type="button">Guardar</button></div>`);
  $("#prop-auto-guardar").onclick = () => guardarAutomatizacion(id, false);
}

async function guardarAutomatizacion(id, confirmada) {
  const r = await api().automatizaciones_desde_plan(id, {
    nombre: $("#prop-auto-nombre").value,
    disparador: disparadorAuto("#prop-auto-"),
    confirmada: confirmada || $("#prop-auto-ok").checked,
  });
  const lineas = $("#prop-auto-lineas");
  if (r && r.necesita_confirmacion) {
    if (lineas) lineas.innerHTML = aviso("warn", esc((r.lineas || []).join(" ") + " " + (r.que || r.error || "")));
    return;
  }
  if (r && r.ok) {
    $("#propuesta-accion").insertAdjacentHTML("beforeend", aviso("ok", esc(r.texto || "Guardada.")));
    if ($("#vista-ajustes").classList.contains("visible")) pintarAutomatizaciones();
    return;
  }
  if (lineas) lineas.innerHTML = aviso("err", esc((r && (r.error || r.que)) || "No he podido guardarla."));
}

async function cancelarPropuesta(id) {
  const r = await api().acciones_cancelar(id);
  const texto = r.ok ? (r.texto || "Cancelado. No he cambiado nada.") : (r.error || "No he cambiado nada.");
  $("#propuesta-accion").innerHTML = aviso("info", esc(texto));
  if ($("#vista-ajustes").classList.contains("visible")) pintarCarpetas();
}

function resultadoPropuesta(r) {
  const caja = $("#propuesta-accion");
  const bien = r && r.ok !== false;
  const des = r && r.puede_deshacer ? `<button class="fantasma" id="prop-deshacer" type="button">Deshacer</button>` : "";
  const texto = bien ? (r.texto || "Hecho.") : ((r && r.error) || "No he podido hacerlo.");
  caja.innerHTML = aviso(bien ? "ok" : "err", esc(texto), des);
  const b = $("#prop-deshacer");
  if (b) b.onclick = async () => {
    const x = await api().acciones_deshacer();
    caja.innerHTML = x.ok ? aviso("ok", esc(x.texto || "He deshecho la última acción.")) : aviso("err", esc(x.error));
    if ($("#vista-ajustes").classList.contains("visible")) pintarCarpetas();
  };
  if ($("#vista-ajustes").classList.contains("visible")) pintarCarpetas();
}

async function confirmarPropuesta(id, sobrescribir) {
  const boton = $("#prop-si");
  if (boton) boton.disabled = true;
  const r = await api().acciones_confirmar(id, sobrescribir);
  if (r && r.necesita_sobrescribir) {
    const acciones = $("#propuesta-accion .acciones");
    if (!acciones) return;
    acciones.innerHTML = `<span>Esto sustituye lo que ya hay. Lo de ahora irá a la papelera.</span><button class="primario" id="prop-sobre" type="button">Sí, sustituir</button><button class="fantasma" id="prop-no2" type="button">Cancelar</button>`;
    $("#prop-no2").onclick = () => cancelarPropuesta(id);
    $("#prop-sobre").onclick = async () => {
      $("#prop-sobre").disabled = true;
      const x = await api().acciones_confirmar(id, true);
      if (x && x.propuesta) { pintarPropuesta(x.propuesta); return; }
      resultadoPropuesta(x);
    };
    return;
  }
  if (r && r.propuesta) { pintarPropuesta(r.propuesta); return; }
  resultadoPropuesta(r);
}

async function pintarGrafica(mensaje) {
  const caja = $("#grafica-aviso");
  const acel = $("#aceleracion-estado");
  if (acel) {
    try {
      const a = await api().estado_aceleracion();
      const texto = (a && a.texto) || "";
      const tipo = a && a.activas ? "ok" : (a && a.cargado ? "warn" : "info");
      acel.innerHTML = texto ? aviso(tipo, esc(texto)) : "";
    } catch (e) { acel.innerHTML = ""; }
  }
  if (!caja) return;
  let estado = "";
  try {
    const r = await api().estado_ajuste_grafica();
    if (r && r.aviso) estado = aviso("warn", esc(r.aviso));
  } catch (e) { /* la pantalla de ajustes sigue usable */ }
  caja.innerHTML = estado + (mensaje || "");
}

async function pintarCarpetas(mensaje) {
  const r = await api().acciones_estado();
  if (!r || r.ok === false) {
    $("#carp-aviso").innerHTML = aviso("err", esc((r && r.error) || "No he podido leer las carpetas."));
    return;
  }
  const cabe = r.permitido !== false;
  $("#carp-anadir").disabled = !cabe;
  $("#carp-deshacer").disabled = !r.puede_deshacer;
  const avisoPlan = !cabe ? aviso("warn", esc(r.aviso || "")) : "";
  const apagadas = cabe && !(r.carpetas || []).length ? aviso("info", "No hay carpetas autorizadas. Las acciones están apagadas.") : "";
  $("#carp-aviso").innerHTML = avisoPlan || mensaje || apagadas;
  const herr = [["leer", "Leer"], ["buscar", "Buscar"], ["resumir", "Resumir"], ["archivos", "Cambiar archivos"]];
  const interruptor = (attrs, on, texto) => `<label class="casilla-sw"><input type="checkbox" role="switch" class="sw" ${attrs} ${on ? "checked" : ""} ${cabe ? "" : "disabled"}><span>${texto}</span></label>`;
  $("#carp-lista").innerHTML = (r.carpetas || []).map((c, n) => {
    const mapa = c.herramientas || {};
    const checks = herr.map(([id, nombre]) => interruptor(`data-herr="${id}" data-carpeta="${esc(c.id)}"`, mapa[id] !== false, nombre)).join("");
    const desdeMovil = interruptor(`data-movil="${esc(c.id)}"`, c.desde_movil === true, "Permitir desde el móvil");
    return `<div class="fila-carpeta"><div class="fila"><span class="monograma">${svgS("carpeta")}</span><div class="txt"><b>${esc(c.nombre)}</b><span>${esc(c.ruta)}</span></div>
      <div class="ancla"><button type="button" class="icono-btn" data-menu="menu-carp-${n}" aria-haspopup="menu" aria-expanded="false" aria-label="Opciones de ${esc(c.nombre)}" title="Opciones">${svg("mas")}</button>
        <div class="menu abajo derecha" id="menu-carp-${n}" role="menu"><button type="button" class="menu-item peligro" role="menuitem" data-quitar-carpeta="${esc(c.id)}" ${cabe ? "" : "disabled"}>${svg("borrar")}Quitar de la lista</button></div></div></div>
      <div class="herramientas-carpeta">${checks}${desdeMovil}</div></div>`;
  }).join("");
  estado.registroCarpetas = r.registro || [];
  pintarRegistroUnico();
  document.querySelectorAll("[data-quitar-carpeta]").forEach((b) => b.onclick = async () => {
    const x = await api().acciones_quitar(b.dataset.quitarCarpeta);
    pintarCarpetas(x.ok ? aviso("ok", "Carpeta quitada. Sopa ya no propondrá acciones ahí.") : aviso("err", esc(x.error)));
  });
  document.querySelectorAll("[data-herr]").forEach((b) => b.onchange = async () => {
    const x = await api().acciones_herramienta(b.dataset.carpeta, b.dataset.herr, b.checked);
    pintarCarpetas(x.ok ? "" : aviso("err", esc(x.error || "No he podido cambiar la herramienta.")));
  });
  document.querySelectorAll("[data-movil]").forEach((b) => b.onchange = async () => {
    const x = await api().acciones_desde_movil(b.dataset.movil, b.checked);
    pintarCarpetas(x.ok ? "" : aviso("err", esc(x.error || "No he podido cambiar el móvil.")));
  });
}

function nombreAgenteAprender(agente) {
  const ficha = typeof fichaEquipo === "function" ? fichaEquipo(agente) : null;
  return (ficha && ficha.nombre) || (agente === "chat" ? "Sopa" : agente);
}

async function pulsarAprender() {
  if (!window.pywebview || !window.pywebview.api) return;
  try {
    await api().aprender_pulso();
  } catch (e) { /* la Sala sigue aunque la cola no responda */ }
  await pintarAprender();
}

async function pintarAprender() {
  const caja = $("#aprender-aviso");
  if (!caja || !window.pywebview || !window.pywebview.api) return;
  let r;
  try {
    r = await api().aprender_estado();
  } catch (e) {
    return;
  }
  if (!r || r.ok === false) return;
  const pendientes = (r.trabajos || []).filter((t) => t.estado === "pendiente");
  if (!pendientes.length) {
    caja.hidden = true;
    caja.innerHTML = "";
    return;
  }
  const trabajo = pendientes[0];
  const hechos = trabajo.hechos || [];
  const nombre = nombreAgenteAprender(trabajo.agente);
  const pregunta = trabajo.destino === "agente"
    ? `¿Guardar estos hechos en la memoria de ${esc(nombre)}? Todavía no están guardados.`
    : "¿Guardar estos hechos en la memoria? Todavía no están guardados.";
  const lista = hechos.length
    ? hechos.map((h) => `«${esc(h)}»`).join("<br>")
    : esc(trabajo.aviso || "No he sacado ningún hecho.");
  const extra = pendientes.length > 1 ? `<br><small>Hay ${pendientes.length} esperando tu sí.</small>` : "";
  let lora = "";
  if (trabajo.lora && trabajo.lora.estado === "propuesto") {
    lora = `<br><small>También hay un plan de LoRA ligero (r=${esc(trabajo.lora.r)}) para ${esc(trabajo.lora.modelo)}. Guardar no entrena ni carga el modelo.</small>`;
  } else if (trabajo.lora && trabajo.lora.motivo) {
    lora = `<br><small>${esc(trabajo.lora.motivo)}</small>`;
  }
  const guardar = hechos.length ? `<button class="primario" id="aprender-si" type="button">Guardar</button>` : "";
  caja.hidden = false;
  caja.innerHTML = aviso("info", `${pregunta}<br>${lista}${lora}${extra}`,
    `${guardar}<button class="fantasma" id="aprender-no" type="button">${hechos.length ? "Ahora no" : "Quitar"}</button>`, "memoria");
  const no = $("#aprender-no");
  if (no) no.onclick = async () => {
    const x = await api().aprender_descartar(trabajo.id);
    if (!x || x.ok === false) {
      caja.innerHTML = aviso("err", esc((x && x.error) || "No he podido quitarlo."));
      return;
    }
    await pintarAprender();
  };
  const si = $("#aprender-si");
  if (si) si.onclick = async () => {
    const x = await api().aprender_aprobar(trabajo.id);
    if (!x || x.ok === false) {
      caja.innerHTML = aviso("err", esc((x && x.error) || "No he podido guardarlo."));
      return;
    }
    caja.innerHTML = aviso("ok", trabajo.destino === "agente"
      ? `Guardado. ${esc(nombre)} lo tendrá en cuenta.`
      : "Guardado en la memoria. Puedes verlo o borrarlo en Memoria.");
    if (typeof pintarRecuerdos === "function") pintarRecuerdos();
    if (pendientes.length > 1) setTimeout(() => { pintarAprender(); }, 900);
  };
}

async function marcarAprenderDespues() {
  const campo = $("#chat-texto");
  const texto = (campo && campo.value || "").trim();
  const caja = $("#aprender-aviso");
  if (!texto) {
    if (caja) {
      caja.hidden = false;
      caja.innerHTML = aviso("info", "Escribe antes lo que hay que aprender después.");
    }
    return;
  }
  const agente = ($("#chat-agente") && $("#chat-agente").value) || "chat";
  const r = await api().aprender_encolar(texto, agente);
  if (!r || r.ok === false) {
    if (caja) {
      caja.hidden = false;
      caja.innerHTML = aviso("err", esc((r && r.error) || "No he podido dejarlo en la cola."));
    }
    return;
  }
  if (campo) campo.value = "";
  const listo = r.trabajo && r.trabajo.estado === "pendiente";
  toast(listo
    ? "He preparado los hechos. Aún no están guardados: confirma en la Sala."
    : "Queda en la cola. Se preparará cuando no haya generación. Aún no está guardado.");
  await pintarAprender();
}

function proponerMemoria(texto, opciones) {
  const opts = opciones || {};
  const agente = opts.agente || (($("#chat-agente") && $("#chat-agente").value) || "chat");
  const guardarGlobal = opts.globalMemoria !== false;
  const guardarAgente = opts.agenteMemoria === true;
  const ficha = typeof fichaEquipo === "function" ? fichaEquipo(agente) : null;
  const nombre = (ficha && ficha.nombre) || "Sopa";
  const pregunta = guardarAgente && !guardarGlobal
    ? `¿Que ${esc(nombre)} lo recuerde? «${esc(texto)}»`
    : `¿Guardar en la memoria? «${esc(texto)}»`;
  $("#aviso-chat").innerHTML = aviso("info", pregunta,
    `<button class="primario" id="mem-si">Guardar</button><button class="fantasma" id="mem-no">Ahora no</button>`, "memoria");
  $("#mem-no").onclick = () => { $("#aviso-chat").innerHTML = ""; };
  $("#mem-si").onclick = async () => {
    let fallo = "";
    if (guardarAgente) {
      const x = await api().memoria_agente_añadir(agente, texto);
      if (!x || x.ok === false) fallo = (x && x.error) || "No he podido guardarlo.";
    }
    if (guardarGlobal) {
      const x = await api().memoria_añadir(texto, "chat");
      if (!x || x.ok === false) fallo = (x && x.error) || fallo;
    }
    const donde = guardarAgente && !guardarGlobal
      ? `Guardado. ${esc(nombre)} lo tendrá en cuenta en este hilo.`
      : "Guardado en la memoria. Puedes verlo o borrarlo en Memoria.";
    $("#aviso-chat").innerHTML = fallo ? aviso("err", esc(fallo)) : aviso("ok", donde);
    if (!fallo && typeof pintarRecuerdos === "function") pintarRecuerdos();
  };
}

async function cargarModelosPersonalizar() {
  const [r, e] = await Promise.all([api().catalogo(false), api().elegir_modelo("entrenar")]);
  const sel = $("#p-modelo");
  sel.innerHTML = r.modelos.map((m) => `<option value="${m.id}" ${m.personalizar === "no" && estado.info.hardware.gpus.length ? "disabled" : ""}>${esc(m.nombre)} — ${TEXTO_PERS[m.personalizar]}</option>`).join("");
  if (e.ok && e.elegido && !sel.dataset.tocado) sel.value = e.elegido.id;
  $("#p-eleccion").innerHTML = !e.ok ? "" : e.elegido
    ? aviso(e.aviso ? "warn" : "info", `Sopa propone <b>${esc(e.elegido.nombre)}</b>: ${esc(minus(e.motivo.replace(/^[^:]*:\s*/, "")))}${e.aviso ? " " + esc(e.aviso) : ""} <small>Puedes elegir otro en el paso 1.</small>`)
    : aviso("err", esc(e.aviso || e.motivo));
  const info = () => { const m = r.modelos.find((x) => x.id === sel.value); $("#p-modelo-info").textContent = m ? m.personalizar_texto : ""; };
  sel.onchange = () => { sel.dataset.tocado = "1"; info(); estimar(); }; info();
}

async function pintarDatos(ruta) {
  estado.datos = ruta;
  $("#p-datos-ruta").textContent = ruta;
  const v = await api().vista_previa_datos(ruta);
  $("#p-vista").textContent = v.ok
    ? `${v.filas} ejemplos · formato «${v.plantilla}»${v.aviso ? " · ⚠ " + v.aviso : ""}\n` + v.ejemplos.map((e) => JSON.stringify(e).slice(0, 200)).join("\n")
    : "✖ " + v.error;
  estimar();
}

async function elegirDatos() {
  const r = await api().elegir_archivo();
  if (!r.ruta) return;
  await pintarDatos(r.ruta);
}

async function elegirOrigenEjemplos() {
  const r = await api().elegir_origen_ejemplos();
  if (!r || !r.ruta) return;
  estado.origenEjemplos = r.ruta;
  $("#p-origen-ruta").textContent = r.ruta;
  $("#p-crear").disabled = false;
  $("#p-preparado").textContent = "";
}

async function crearEjemplos() {
  if (!estado.origenEjemplos) return;
  $("#p-crear").disabled = true;
  const r = await api().preparar_ejemplos(estado.origenEjemplos);
  $("#p-crear").disabled = false;
  if (!r.ok) {
    $("#p-preparado").textContent = r.error;
    return;
  }
  $("#p-preparado").textContent = `${r.cantidad} ejemplos, formato «${r.plantilla}». Ya están elegidos en el paso 2.${r.aviso ? " " + r.aviso : ""}`;
  await pintarDatos(r.ruta);
}

async function estimar() {
  const p = $("#p-estimacion");
  if (!estado.datos || !$("#p-modelo").value) return;
  const r = await api().estimar_tiempo($("#p-modelo").value, estado.datos, $("#p-intensidad").value);
  p.innerHTML = r.ok
    ? `Tardará <b>${esc(r.texto)}</b> (${r.fiabilidad === "medido" ? "medido en un equipo real" : "aproximado"}).`
      + (r.plan ? `<br><small class="plan">${svg("info")} ${esc(r.plan.texto)}</small>` : "")
      + `<details class="detalles"><summary>Ver detalles</summary><small>${r.pasos} pasos de ~${r.segundos_por_paso} s.${r.plan && r.plan.detalle ? " " + esc(r.plan.detalle) : ""}</small></details>`
    : esc(r.error);
}

async function empezar() {
  const r = await api().entrenar({ modelo: $("#p-modelo").value, datos: estado.datos, intensidad: $("#p-intensidad").value, nombre: $("#p-nombre").value });
  if (!r.ok) return fallo("#aviso-pers", r.error);
  $("#aviso-pers").innerHTML = "";
  $("#p-estado").textContent = "Empezando…";
}

async function mostrarTextoLegal(cual) {
  const caja = $("#texto-legal");
  if (!caja) return;
  const r = await api().texto_legal(cual);
  caja.hidden = false;
  caja.textContent = r && r.ok ? r.texto : ((r && r.error) || "No se pudo leer el texto.");
}

let qrFuera = null;

function pintarMovil(r) {
  const panel = $("#movil-panel");
  if (!r) { api().movil_estado().then(pintarMovil); return; }
  const interruptor = $("#movil-on");
  const cabe = r.permitido !== false;
  interruptor.disabled = !cabe;
  interruptor.checked = cabe && !!r.activo;
  const f = r.fuera || {};
  const fueraOn = $("#fuera-on");
  const cabeFuera = cabe && f.permitido !== false;
  if (fueraOn) {
    fueraOn.disabled = !cabeFuera;
    fueraOn.checked = cabeFuera && !!f.activo;
  }
  if (!cabeFuera) qrFuera = null;
  if (!cabe) {
    panel.innerHTML = aviso("warn", esc(r.aviso || ""));
    const fp = $("#fuera-panel");
    if (fp) fp.innerHTML = f.aviso ? aviso("warn", esc(f.aviso)) : "";
    return;
  }
  if (!r.activo) {
    panel.innerHTML = r.error ? aviso("err", esc(r.error)) : "";
  } else {
    const dispositivos = (r.dispositivos || []).map((d) =>
      `<div class="dispositivo"><span>${esc(d.nombre)} · ${esc(d.creado)}</span><button class="fantasma" data-revocar="${esc(d.id)}" type="button">Revocar</button></div>`).join("");
    const vistos = (r.registro_icono || []).map((l) => `<li>${esc(l)}</li>`).join("");
    const conexiones = (r.registro || []).map((l) => `<li>${esc(l)}</li>`).join("");
    const queda = r.codigo_segundos > 90 ? Math.round(r.codigo_segundos / 60) + " min" : r.codigo_segundos + " s";
    const reserva = r.ip
      ? (r.mac ? `Reserva en el router la IP ${esc(r.ip)} para la MAC ${esc(r.mac)}.` : `Reserva en el router la IP ${esc(r.ip)}.`)
      : "";
    panel.innerHTML = `<h4>${esc(r.titulo || "")}</h4>`
      + `<p>${esc(r.ip || "")} · ${esc(r.host || "")} · ${esc(r.estado || "")}</p>`
      + (r.huella ? `<p>Huella del certificado: <code>${esc(r.huella)}</code></p>` : "")
      + (reserva ? `<p>${reserva}</p>` : "")
      + `<div class="qr">${r.qr || ""}</div>`
      + (r.url_enlace ? `<p class="respaldo">${esc(r.url_enlace)}</p>` : "")
      + (r.url_certificado ? `<p>Instalar el certificado: ${esc(r.url_certificado)}</p>` : "")
      + (r.codigo ? `<p>Código de 6 dígitos: <b>${esc(r.codigo)}</b></p>` : "")
      + (r.url_plan ? `<p class="respaldo">${esc(r.url_plan)}</p>` : "")
      + (r.codigo_segundos ? `<small>Vale una sola vez · quedan ${queda}.</small>` : "")
      + `<p><button id="movil-codigo" type="button">Generar código nuevo</button></p>`
      + (r.qr_volver ? `<h4>Volver a conectar</h4><div class="qr">${r.qr_volver}</div><p class="respaldo">${esc(r.url_volver || "")}</p>` : "")
      + (r.vuelta_pendiente ? `<p><button id="movil-volver-si" type="button">Confirmar reconexión</button></p>` : `<p><button id="movil-volver" type="button">Volver a conectar</button></p>`)
      + dispositivos
      + (conexiones ? `<details><summary>Conexiones</summary><ul>${conexiones}</ul></details>` : "")
      + (vistos ? `<details><summary>Peticiones del icono</summary><ul>${vistos}</ul></details>` : "");
    const otro = $("#movil-codigo");
    if (otro) otro.onclick = async () => pintarMovil(await api().movil_codigo());
    const volver = $("#movil-volver");
    if (volver) volver.onclick = async () => pintarMovil(await api().movil_volver());
    const confirmarVuelta = $("#movil-volver-si");
    if (confirmarVuelta) confirmarVuelta.onclick = async () => pintarMovil(await api().movil_confirmar_vuelta());
    panel.querySelectorAll("[data-revocar]").forEach((b) => b.onclick = async () => pintarMovil(await api().movil_revocar(b.dataset.revocar)));
  }
  pintarFuera(f);
}

function pintarFuera(f) {
  const panel = $("#fuera-panel");
  if (!panel) return;
  if (!f || f.permitido === false) {
    panel.innerHTML = f && f.aviso ? aviso("warn", esc(f.aviso)) : "";
    return;
  }
  if (!f.activo) { panel.innerHTML = ""; return; }
  const moviles = (f.moviles || []).map((d) =>
    `<div class="dispositivo"><span>${esc(d.nombre)} · ${esc(d.creado)}</span><button class="fantasma" data-revocar-tunel="${esc(d.id)}" type="button">Revocar</button></div>`).join("");
  const qr = qrFuera
    ? `<h4>Pasa este código a WireGuard</h4><div class="qr">${qrFuera.qr}</div>`
      + `<p>Se enseña una sola vez y lleva la clave de ese móvil. Si lo cierras sin pasarlo a la app, revoca el móvil y crea otro. La clave no se guarda en el ordenador.</p>`
      + `<pre class="vista-previa">${esc(qrFuera.conf)}</pre>`
      + `<p><button id="fuera-copiar" type="button">Copiar</button> <button id="fuera-listo" type="button">Ya está en el móvil</button></p>`
    : "";
  panel.innerHTML = aviso("warn", esc(f.texto_admin || ""))
    + `<p><a href="${esc(f.url_wireguard || "")}" target="_blank" rel="noopener">Descargar WireGuard para Windows</a></p>`
    + `<p><button id="fuera-guardar" type="button">Guardar archivo del túnel</button></p>`
    + `<p>${esc(f.texto_passkey || "")}</p>`
    + `<p>${esc(f.texto_red || "")}</p>`
    + `<p>${esc(f.texto_dns || "")}</p>`
    + (f.url_movil ? `<p>En el móvil, con el túnel encendido, abre <b>${esc(f.url_movil)}</b>. Es la misma dirección que en casa.</p>` : "")
    + (f.host_es_ip ? aviso("warn", "Este enlace usa una IP. La cara o la huella de fuera de casa necesitan el nombre .local. Enlaza el móvil en casa con ese nombre.") : "")
    + `<p>${esc(f.texto_puerto || "")}</p>`
    + (f.ip_casa ? `<p>La IP de este PC en casa es <b>${esc(f.ip_casa)}</b>. El puerto UDP es <b>${esc(f.puerto)}</b>.</p>` : "")
    + `<p><label>Puerto UDP <input id="fuera-puerto" type="number" min="1" max="65535" value="${Number(f.puerto) || 51820}"></label> <button id="fuera-puerto-ok" type="button">Usar este puerto</button></p>`
    + `<h4>IP pública</h4>`
    + `<p>No se consulta sola. Pulsa Comprobar para preguntarle a tu router, sin salir de casa.</p>`
    + (f.endpoint ? `<p>Los móviles nuevos apuntarán a <b>${esc(f.endpoint)}</b>.</p>` : "")
    + `<p><button id="fuera-comprobar" type="button">Comprobar</button></p>`
    + `<p>${esc(f.aviso_internet || "")}</p>`
    + `<p><button id="fuera-internet" type="button">Preguntar en internet</button></p>`
    + `<p><label>O escribe la IP <input id="fuera-ip" type="text" value="${esc(f.endpoint || "")}" autocomplete="off" spellcheck="false"></label> <button id="fuera-usar" type="button">Usar esta</button></p>`
    + `<p><button id="fuera-anadir" class="primario" type="button">Añadir un móvil</button></p>`
    + qr + moviles
    + (moviles ? `<p>${esc(f.texto_revocar || "")}</p>` : "")
    + (f.escuchando
      ? `<small>El túnel está activo en este PC: Sopa escucha en la IP del túnel.</small>`
      : `<small>Cuando actives el túnel en WireGuard, Sopa escuchará en esa IP.</small>`);
  const falloFuera = async (promesa) => {
    const resp = await promesa;
    if (!resp || resp.ok === false) toast((resp && resp.error) || "No he podido hacerlo.");
    if (resp && resp.fuera) pintarMovil(resp);
    else pintarMovil();
    return resp;
  };
  $("#fuera-guardar").onclick = async () => {
    const resp = await api().fuera_guardar_conf();
    if (resp && resp.cancelado) return;
    if (!resp || resp.ok === false) toast((resp && resp.error) || "No he podido guardar el archivo.");
    else toast("Archivo guardado. Impórtalo en WireGuard.");
  };
  $("#fuera-puerto-ok").onclick = () => falloFuera(api().fuera_puerto(Number($("#fuera-puerto").value)));
  $("#fuera-comprobar").onclick = () => falloFuera(api().fuera_comprobar());
  $("#fuera-internet").onclick = () => falloFuera(api().fuera_comprobar_internet());
  $("#fuera-usar").onclick = () => falloFuera(api().fuera_endpoint($("#fuera-ip").value));
  $("#fuera-anadir").onclick = async () => {
    const resp = await api().fuera_movil_nuevo("");
    if (!resp || resp.ok === false) { toast((resp && resp.error) || "No he podido añadir el móvil."); return; }
    qrFuera = { qr: resp.qr_tunel, conf: resp.conf_tunel, id: resp.movil_tunel };
    pintarMovil(resp);
  };
  const copiar = $("#fuera-copiar");
  if (copiar) copiar.onclick = async () => {
    try { await navigator.clipboard.writeText(qrFuera.conf); toast("Configuración copiada."); }
    catch (e) { toast("Selecciona el texto y cópialo."); }
  };
  const listo = $("#fuera-listo");
  if (listo) listo.onclick = () => { qrFuera = null; pintarMovil(); };
  panel.querySelectorAll("[data-revocar-tunel]").forEach((b) => b.onclick = async () => {
    if (qrFuera && qrFuera.id === b.dataset.revocarTunel) qrFuera = null;
    await falloFuera(api().fuera_revocar(b.dataset.revocarTunel));
  });
}

async function pintarCodigoProbador() {
  const r = await api().codigo_probador();
  if (r.ok) $("#codigo-probador").textContent = r.codigo;
}


const fechaCorta = (iso) => iso ? new Date(iso + "T12:00:00").toLocaleDateString("es-ES", { day: "numeric", month: "long", year: "numeric" }) : "";
const primeraNovedad = (n) => { const t = (n || "").split("\n")[0].replace(/^[-*#]\s*/, "").replace(/\.$/, "").trim(); return t ? t[0].toLowerCase() + t.slice(1) : "mejoras"; };
const gib = (b) => (b / 1024 ** 3).toFixed(2) + " GB";  // mismas unidades que la lista de modelos
const mb = (b) => b > 1e9 ? (b / 1e9).toFixed(2) + " GB" : Math.round(b / 1e6) + " MB";
// «el 30 oct, 9:12»; si es de otro año, «el 30 oct 2025, 9:12». Sale de la comprobación real (ultima_busqueda).
const MESES_CORTOS = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sept", "oct", "nov", "dic"];
function fechaComprobado(iso, hoy = new Date()) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  const anio = d.getFullYear() === hoy.getFullYear() ? "" : ` ${d.getFullYear()}`;
  return `el ${d.getDate()} ${MESES_CORTOS[d.getMonth()]}${anio}, ${d.getHours()}:${String(d.getMinutes()).padStart(2, "0")}`;
}
const fecha = (iso) => iso ? new Date(iso).toLocaleString("es-ES", { dateStyle: "medium", timeStyle: "short" }) : "Nunca";

function avisoDisponible(d) {
  return aviso("info", `<b>Sopa ${esc(d.version)} está disponible</b> · ${mb(d.bytes)}${d.notas ? `<div class="notas">${esc(d.notas)}</div>` : ""}`,
    `<button class="primario" data-act="ahora">Actualizar ahora</button><button class="fantasma" data-act="luego">Más tarde</button><button class="fantasma" data-act="ignorar">Ignorar esta versión</button>`, "actualizar");
}

async function pintarActualizaciones(mensaje) {
  const e = await api().actualizaciones_estado();
  $("#act-version").textContent = e.version;
  // Una línea: al día o no, y cuándo se comprobó. Sin datos inventados: si nunca se buscó, se dice.
  const hayNueva = e.disponible && e.disponible.version !== e.ignorada;
  $("#act-resumen").textContent = hayNueva ? `Hay una versión nueva: ${e.disponible.version}` : e.ultima_busqueda ? "Estás al día · comprobado" : "Aún no se ha comprobado";
  $("#act-ultima").textContent = e.ultima_busqueda ? fechaComprobado(e.ultima_busqueda) : "";
  $("#act-auto").checked = e.auto;
  $("#act-catalogo").textContent = e.catalogo ? `${e.catalogo.modelos} modelos · ${e.catalogo.origen === "descargado" ? "actualizado" : "incluido"}` : "—";
  const p = e.progreso || {};
  let html = mensaje || "";
  if (p.activa) html = aviso("info", `${{ copia: "Guardando una copia de tus datos…", descargando: "Descargando", verificando: "Comprobando la firma y el archivo…", preparando: "Preparando la nueva versión…" }[p.fase] || "Preparando…"} ${p.total ? Math.round(100 * p.hecho / p.total) + "%" : ""}`, `<button class="btn texto" data-act="cancelar">Cancelar</button>`, "actualizar");
  else if (p.lista) html = aviso("ok", `Sopa ${esc(p.version)} está lista. Se cerrará y se abrirá la nueva versión; si algo falla, volverá sola a la actual. Tus datos no se tocan.`, `<button class="btn primario" data-act="reiniciar">Reiniciar y actualizar</button>`);
  else if (p.error) html = aviso(p.cancelada ? "warn" : "err", esc(p.error));
  else if (!html && e.disponible && e.disponible.version !== e.ignorada) html = avisoDisponible(e.disponible);
  $("#act-aviso").innerHTML = html;
  if (html) $("#aviso-actualizacion").innerHTML = "";  // en Ajustes, el aviso va dentro de la tarjeta
  const hist = (e.historial || []);
  $("#act-lista").innerHTML = (e.instaladas || []).slice().reverse().map((v) => `<div class="version"><b>${esc(v.version)}</b> <small class="en-linea">instalada ${fecha(v.fecha)}</small></div>`).join("")
    + hist.map((v) => `<div class="version"><b>${esc(v.version)}</b> <small class="en-linea">${esc(v.fecha || "")}</small><p>${esc(v.notas || "")}</p></div>`).join("")
    || `<small>Aún no hay historial.</small>`;
  enlazarAcciones(document);
  if (p.activa) setTimeout(() => pintarActualizaciones(), 800);
  return e;
}

async function avisoGlobal() {
  const e = await api().actualizaciones_estado();
  const u = e.ultima_instalacion;
  if (u) toast(u.estado === "completada" ? `Sopa se ha actualizado a la versión ${u.a}.` : u.detalle || "La actualización no se completó; sigues en tu versión.");
  const d = e.disponible;
  const enAjustes = $("#vista-ajustes").classList.contains("visible");
  $("#aviso-actualizacion").innerHTML = !enAjustes && d && d.version !== e.ignorada && !sessionStorage.getItem("luego") && e.instalable ? avisoDisponible(d) : "";
  enlazarAcciones($("#aviso-actualizacion"));
}

function enlazarAcciones(raiz) {
  raiz.querySelectorAll("[data-act]").forEach((b) => b.onclick = async () => {
    const a = b.dataset.act;
    const e = await api().actualizaciones_estado();
    if (a === "ahora") { $("#aviso-actualizacion").innerHTML = ""; mostrarVista("ajustes"); const r = await api().actualizar_ahora(); return pintarActualizaciones(r.ok ? "" : aviso("err", esc(r.error))); }
    if (a === "luego") { sessionStorage.setItem("luego", "1"); $("#aviso-actualizacion").innerHTML = ""; return; }
    if (a === "ignorar") { await api().ignorar_version(e.disponible.version); $("#aviso-actualizacion").innerHTML = ""; return pintarActualizaciones(aviso("info", `No volveré a avisarte de la versión ${esc(e.disponible.version)}.`)); }
    if (a === "cancelar") { await api().cancelar_actualizacion(); return; }
    if (a === "reiniciar") { await api().reiniciar_para_actualizar(); }
  });
}

function pintarDocs() {
  $("#chat-docs").innerHTML = estado.docs.length
    ? `<small>Responderá con:</small>` + estado.docs.map((d) => `<span class="chip doc">${svg("doc")}${esc(d.nombre)}<button type="button" class="fantasma" data-quitar-doc="${d.id}" aria-label="No usar ${esc(d.nombre)}">${svgS("cerrar")}</button></span>`).join("")
    : "";
  document.querySelectorAll("[data-quitar-doc]").forEach((b) => b.onclick = () => { estado.docs = estado.docs.filter((d) => d.id !== b.dataset.quitarDoc); pintarDocs(); });
  if ($("#vista-chat").classList.contains("visible")) pintarEleccionChat();
}

async function adjuntar() {
  $("#chat-adjuntar").disabled = true;
  $("#aviso-chat").innerHTML = aviso("info", "Leyendo tus documentos…");
  const r = await api().elegir_documentos();
  $("#chat-adjuntar").disabled = false;
  for (const d of r.añadidos || []) if (!estado.docs.find((x) => x.id === d.id)) estado.docs.push({ id: d.id, nombre: d.nombre });
  pintarDocs();
  const avisosDoc = (r.avisos || []).map((e) => aviso("warn", `${esc(e.nombre)}: ${esc(e.aviso)}`)).join("")
    + (r.errores || []).map((e) => aviso("warn", `${esc(e.nombre)}: ${esc(e.error)}`)).join("");
  const listo = (r.añadidos || []).length ? aviso("ok", `Listo: responderé usando ${r.añadidos.map((d) => esc(d.nombre)).join(", ")}. No sale nada de tu equipo.`) : "";
  $("#aviso-chat").innerHTML = avisosDoc + listo;
}

const duracion = (s) => s < 90 ? Math.round(s) + " s" : s < 5400 ? Math.round(s / 60) + " min" : (s / 3600).toFixed(1) + " h";

async function sondear() {
  const r = await api().estado(estado.cursor);
  if (r.lineas && r.lineas.length) {
    const pre = $("#registro");
    pre.textContent += r.lineas.join("\n") + "\n";
    estado.cursor = r.cursor;
  }
  if (r.nombre) {
    $("#p-barra").style.width = Math.round(100 * (r.progreso || 0)) + "%";
    const nombres = { entrenar: "Entrenando", exportar: "Preparando el modelo para el chat", instalar: "Instalando el motor" };
    const u = r.ultimo || {};
    $("#punto-tarea").parentElement.classList.toggle("ocupado", !!r.activa);
    $("#p-progreso").className = "progreso" + (r.error ? " error" : !r.activa && r.codigo !== 0 ? " pausa" : "");
    if (!r.activa && r.codigo === 0 && estado.ultimaFin !== r.nombre + r.cursor) { estado.ultimaFin = r.nombre + r.cursor; if (r.nombre === "exportar") toast("Tu modelo personalizado ya está en el chat."); }
    $("#p-estado").textContent = r.activa
      ? `${nombres[r.nombre] || r.nombre}… ${u.texto || ""}${u.segundos_restantes != null ? " · quedan " + duracion(u.segundos_restantes) : ""}`
      : r.error ? "✖ " + r.error : r.codigo === 0 ? (r.nombre === "exportar" ? "✔ ¡Listo! Tu modelo ya aparece en el chat." : "✔ Terminado.") : "Detenido.";
  }
  if (estado.conversacion && !estado.enviando) {
    try {
      const v = await api().versiones_conversaciones();
      const n = v && v.versiones ? v.versiones[estado.conversacion] : 0;
      if (n && n > (estado.versionConv || 0)) await recargarConversacion(estado.conversacion);
    } catch (e) { /* el sondeo de la tarea sigue */ }
  }
}

// Ajustes en 5 secciones. data-ir-ajustes salta a otra sección y abre lo indicado.
function mostrarAjustes(seccion, ir) {
  document.querySelectorAll(".ajustes-nav [data-ajustes]").forEach((b) => {
    if (b.dataset.ajustes === seccion) b.setAttribute("aria-current", "page"); else b.removeAttribute("aria-current");
  });
  document.querySelectorAll(".panel-ajustes").forEach((p) => { p.hidden = p.dataset.panel !== seccion; });
  if (ir) {
    const destino = document.getElementById(ir);
    if (destino) {
      const boton = destino.querySelector("[aria-controls]");
      if (boton) alternarPanel(boton, true);
      destino.scrollIntoView({ block: "start" });
    }
  }
}
function alternarPanel(boton, abrir) {
  const panel = document.getElementById(boton.getAttribute("aria-controls"));
  if (!panel) return;
  const on = abrir === undefined ? panel.hidden : abrir;
  panel.hidden = !on;
  boton.setAttribute("aria-expanded", on ? "true" : "false");
}
function enlazarAjustes() {
  document.querySelectorAll(".ajustes-nav [data-ajustes]").forEach((b) => b.onclick = () => mostrarAjustes(b.dataset.ajustes));
  document.querySelectorAll("[data-ir-ajustes]").forEach((b) => b.onclick = () => mostrarAjustes(b.dataset.irAjustes, b.dataset.irA));
  ["#ver-probado", "#seguridad-abrir", "#cl-opciones"].forEach((id) => { const b = $(id); if (b) b.onclick = () => alternarPanel(b); });
  const verHist = $("#act-ver-historial");
  if (verHist) verHist.onclick = () => { const d = $("#act-historial"); d.hidden = false; d.open = true; d.scrollIntoView({ block: "nearest" }); };
}

window.addEventListener("pywebviewready", () => {
  enlazarMenus();
  // Todo lo que lleva data-vista cambia de vista: barra lateral, pestañas, «Más», menús y enlaces.
  document.addEventListener("click", (e) => {
    const b = e.target.closest("[data-vista]");
    if (!b || b.classList.contains("vista") || b.disabled) return;
    if (b.tagName === "A") e.preventDefault();
    cerrarMenus();
    mostrarVista(b.dataset.vista);
  });
  document.querySelectorAll("#tema [data-valor]").forEach((b) => b.onclick = () => { aplicarTema(b.dataset.valor); api().guardar_ajustes({ tema: b.dataset.valor }); });
  enlazarAjustes();
  enlazarMenuChat();
  $("#web-on").onchange = (e) => cambiarBuscarWeb(e.target.checked);
  if ($("#comprobar-on")) $("#comprobar-on").onchange = (e) => api().guardar_ajustes({ comprobar_codigo: e.target.checked === true });
  $("#chat-web").onclick = () => cambiarBuscarWeb($("#chat-web").getAttribute("aria-pressed") !== "true");
  const selectorAgente = $("#chat-agente");
  if (selectorAgente) selectorAgente.onchange = () => { estado.equipoEstado = "listo"; pintarAgenteActivo(); pintarMenuConversacion(); };
  cargarAgentesChat();
  $("#grafica-restablecer").onclick = async () => {
    const r = await api().restablecer_ajuste_grafica();
    pintarGrafica(r.ok ? aviso("ok", esc(r.texto || "Ajuste olvidado.")) : aviso("err", esc(r.error || "No he podido restablecer el ajuste.")));
  };
  // «Para qué» ya no se ve: #chat-tarea queda oculto en Automático. Si algo lo cambia, se suelta el modelo.
  $("#chat-tarea").onchange = async () => { await api().chat_detener(); estado.modeloChat = null; estado.modeloManualCargado = ""; $("#aviso-chat").innerHTML = ""; pintarEleccionChat(); };
  // Otro .gguf: vale para esta conversación, como cualquier modelo elegido a mano.
  const abrirGguf = async () => { const r = await api().elegir_gguf(); if (r.ruta) { estado.eleccionDeEstaPagina = true; estado.trasRecarga = false; fijarModeloConv(estado.conversacion, r.ruta); if (!$("#vista-chat").classList.contains("visible")) mostrarVista("chat"); cargarChat(r.ruta); } };
  $("#chat-gguf").onclick = abrirGguf;
  if ($("#modelos-gguf")) $("#modelos-gguf").onclick = abrirGguf;
  $("#chat-docs-abrir").onclick = adjuntar;
  if ($("#chat-imagen")) $("#chat-imagen").onclick = adjuntarImagen;
  if ($("#imagen-quitar")) $("#imagen-quitar").onclick = () => { estado.imagenAdjunta = null; pintarImagenAdjunta(""); };
  $("#chat-nueva").onclick = () => { estado.mensajes = []; estado.conversacion = null; estado.docs = []; pintarDocs(); pintarMensajes(); document.querySelectorAll("[data-conv]").forEach((e) => e.classList.remove("activa")); pintarMenuModelo(); };
  $("#chat-form").onsubmit = enviar;
  const aprenderBtn = $("#chat-aprender");
  if (aprenderBtn) aprenderBtn.onclick = () => marcarAprenderDespues();
  pulsarAprender();
  const formComparar = $("#comparar-form");
  if (formComparar) formComparar.onsubmit = comparar;
  const selComparar = $("#comparar-modelo");
  if (selComparar) selComparar.onchange = pintarPareja;
  $("#chat-texto").onkeydown = (e) => { if (e.key === "Enter" && !e.shiftKey) enviar(e); };
  const parar = $("#chat-parar");
  if (parar) parar.onclick = () => api().chat_parar();
  $("#p-datos").onclick = elegirDatos;
  const origenEjemplos = $("#p-origen");
  if (origenEjemplos) origenEjemplos.onclick = elegirOrigenEjemplos;
  const crearEj = $("#p-crear");
  if (crearEj) crearEj.onclick = crearEjemplos;
  $("#p-empezar").onclick = empezar;
  $("#p-intensidad").onchange = estimar;
  $("#act-buscar").onclick = async () => {
    $("#act-buscar").disabled = true;
    const r = await api().buscar_actualizaciones(true);
    $("#act-buscar").disabled = false;
    const m = { al_dia: aviso("ok", "Tienes la última versión."), sin_conexion: aviso("warn", "Sin conexión con GitHub. Sopa sigue funcionando igual; prueba más tarde.", "", "sinred"),
      invalido: aviso("err", "La información de actualización no es válida (firma incorrecta). Se ha ignorado."),
      fuera_de_plan: aviso("info", `Hay una versión nueva${r.version ? " (" + esc(r.version) + ")" : ""}.`),
      requiere_manual: aviso("warn", `La versión ${esc(r.version)} necesita tener antes la ${esc(r.min_version)}. Descárgala e instálala a mano.`) }[r.estado] || "";
    await pintarActualizaciones(m);
  };
  $("#importar-modelo").onclick = importarModelo;
  enlazarDocumentos();
  enlazarMemoria();
  enlazarCarpetas();
  enlazarAutomatizaciones();
  $("#act-auto").onchange = (ev) => api().cambiar_auto(ev.target.checked);
  $("#act-archivo").onclick = async () => { const r = await api().actualizar_desde_archivo(); if (r.cancelado) return; pintarActualizaciones(r.ok ? "" : aviso("err", esc(r.error))); };
  $("#ver-licencia").onclick = () => mostrarTextoLegal("licencia");
  $("#ver-avisos").onclick = () => mostrarTextoLegal("avisos");
  $("#copiar-probador").onclick = async () => {
    const codigo = $("#codigo-probador").textContent;
    try { await navigator.clipboard.writeText(codigo); toast("Código copiado."); }
    catch (e) { toast("Selecciona el código y cópialo."); }
  };
  $("#movil-on").onchange = async (ev) => {
    const queria = ev.target.checked;
    let r;
    try { r = await api().movil_activar(queria); }
    catch (e) { r = { ok: false, error: "No he podido abrir el acceso desde el móvil." }; }
    if (r && r.permitido === false) { pintarMovil(r); return; }
    if (!r || r.ok === false || (queria && !r.activo)) {
      ev.target.checked = false;
      $("#movil-panel").innerHTML = aviso("err", esc((r && r.error) || "No he podido abrir el acceso desde el móvil."));
      return;
    }
    pintarMovil(r);
  };
  $("#fuera-on").onchange = async (ev) => {
    const queria = ev.target.checked;
    if (!queria) qrFuera = null;
    let r;
    try { r = await api().fuera_activar(queria); }
    catch (e) { r = { ok: false, error: "No he podido cambiar el acceso fuera de casa." }; }
    if (!r || r.ok === false) {
      ev.target.checked = false;
      toast((r && r.error) || "No he podido cambiar el acceso fuera de casa.");
      pintarMovil();
      return;
    }
    pintarMovil(r);
  };
  $("#informar-fallo").onclick = async () => {
    const r = await api().informar_fallo();
    if (!r.ok) return;
    $("#codigo-probador").textContent = r.codigo;
    let copiado = false;
    try { await navigator.clipboard.writeText(r.codigo); copiado = true; } catch (e) { /* el código sigue a la vista */ }
    toast(r.abierto
      ? (copiado ? "Código copiado. Se abre el formulario para pegarlo." : "Se abre el formulario. Copia el código y pégalo allí.")
      : "Copia el código y abre " + r.url);
  };
  window.addEventListener("online", () => { if ($("#vista-modelos").classList.contains("visible")) cargarCatalogo(); });
  window.addEventListener("offline", () => { if ($("#vista-modelos").classList.contains("visible")) cargarCatalogo(); });
  $("#p-detener").onclick = () => api().detener();
  cargarInicio().then(() => api().arranque_ok && api().arranque_ok());
  setTimeout(avisoGlobal, 1500); setTimeout(avisoGlobal, 12000);
  setInterval(sondear, 1000);
});


// ---- Tus documentos -----------------------------------------------------------------
const docsSel = new Set();
const FASES = { pendiente: "Preparando…", buscando: "Buscando archivos…", leyendo: "Leyendo documentos", descargando_buscador: "Descargando el buscador por significado", preparando_busqueda: "Preparando la búsqueda por significado…", vectores: "Preparando la búsqueda por significado", terminado: "Listo", cancelado: "Cancelado", error: "Error" };

function markdown(texto) {
  const lineas = esc(texto).split("\n");
  let html = "", lista = false, tabla = [];
  const inline = (t) => t.replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/\[(\d+(?:\s*[,-]\s*\d+)*)\]/g, '<sup class="cita">[$1]</sup>');
  const cerrarTabla = () => {
    if (!tabla.length) return;
    const filas = tabla.filter((f) => !/^\|?\s*:?-{2,}/.test(f)).map((f) => f.replace(/^\||\|$/g, "").split("|").map((c) => inline(c.trim())));
    html += `<table class="tabla md"><thead><tr>${filas[0].map((c) => `<th>${c}</th>`).join("")}</tr></thead><tbody>${filas.slice(1).map((r) => `<tr>${r.map((c) => `<td>${c}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
    tabla = [];
  };
  for (const l of lineas) {
    if (/^\s*\|.*\|\s*$/.test(l)) { tabla.push(l.trim()); continue; }
    cerrarTabla();
    const m = l.match(/^\s*[-*•]\s+(.*)/);
    if (m) { if (!lista) { html += "<ul>"; lista = true; } html += `<li>${inline(m[1])}</li>`; continue; }
    if (lista) { html += "</ul>"; lista = false; }
    const h = l.match(/^#{1,4}\s+(.*)/);
    html += h ? `<h4>${inline(h[1])}</h4>` : l.trim() ? `<p>${inline(l)}</p>` : "";
  }
  cerrarTabla();
  if (lista) html += "</ul>";
  return html;
}

function pintarCitas(r) {
  const citas = (r.citas || []).map((c) => `<details class="cita-fuente"><summary>[${c.n}] ${esc(c.archivo)}${c.pagina ? " · página " + c.pagina : ""}</summary><blockquote>${esc(c.texto)}</blockquote></details>`).join("");
  const avisos = (r.invalidas && r.invalidas.length ? aviso("warn", `La respuesta cita ${r.invalidas.map((n) => "[" + n + "]").join(", ")}, que no existe${r.invalidas.length > 1 ? "n" : ""} entre los extractos: no te fíes de esos datos.`) : "")
    + (r.sin_citas ? aviso("warn", "La respuesta no cita extractos concretos: compruébala en los documentos.") : "")
    + (r.parcial ? aviso("info", "Documento largo: el resumen se ha hecho con extractos repartidos por todo el texto.") : "");
  const leidas = (r.fuentes || []).filter((f) => f.archivo).map((f) => esc(f.archivo) + (f.paginas && f.paginas.length ? ` (p. ${f.paginas.join(", ")})` : "")).join(" · ");
  return avisos + (citas ? `<div class="citas"><small>Fuentes (pulsa para ver el texto exacto):</small>${citas}</div>` : "")
    + (leidas ? `<small class="meta">Leído de: ${leidas}</small>` : "");
}

async function cargarDocumentos() {
  const r = await api().documentos();
  if (!r.ok) return fallo("#doc-aviso", r.error);
  const s = r.resumen;
  $("#doc-resumen").textContent = s.documentos ? `${s.documentos} documentos · ${s.paginas} páginas${s.paginas_ocr ? ` (${s.paginas_ocr} leídas con OCR)` : ""}` : "";
  $("#doc-capacidades").innerHTML = (r.significado.instalado ? "Búsqueda por significado activada. " : `La primera vez que añadas una carpeta se descargará el buscador por significado (${r.significado.mb} MB, licencia ${esc(r.significado.licencia)}). `)
    + (r.significado.aviso ? `${esc(r.significado.aviso)} ` : "")
    + (r.ocr ? "Los PDF escaneados se leen con el OCR de Windows." : "En este sistema no hay OCR para PDF escaneados.");
  $("#doc-carpetas").innerHTML = r.carpetas.map((c) => `<div class="fila-modelo"><div><b>${esc(c.ruta.split(/[\\/]/).pop())}</b><small>${c.documentos} documentos · ${c.paginas} páginas</small></div>
      <div class="acciones"><button class="fantasma" data-carpeta-usar="${esc(c.ruta)}">Preguntar en el chat</button><button class="fantasma" data-carpeta-revisar="${esc(c.ruta)}">Volver a revisar</button><button class="fantasma peligro" data-carpeta-quitar="${esc(c.ruta)}">Quitar</button></div></div>`).join("");
  $("#doc-lista").innerHTML = r.documentos.length ? r.documentos.map((d) => `<label class="doc-fila"><input type="checkbox" data-doc="${d.id}" ${docsSel.has(d.id) ? "checked" : ""}>
      ${svg("doc")}<span>${esc(d.nombre)}</span><small>${d.paginas ? d.paginas + " p." : ""}${d.ocr ? " · OCR" : ""}</small><button type="button" class="fantasma borrar" data-doc-quitar="${d.id}" aria-label="Quitar ${esc(d.nombre)} de Sopa, sin borrar el archivo">${svgS("cerrar")}</button></label>`).join("")
    : vacio("doc", "Aún no hay documentos", "Añade una carpeta (apuntes, contratos, manuales…) y Sopa la indexará en segundo plano.");
  document.querySelectorAll("[data-doc]").forEach((c) => c.onchange = () => { c.checked ? docsSel.add(c.dataset.doc) : docsSel.delete(c.dataset.doc); botonesSeleccion(); });
  document.querySelectorAll("[data-doc-quitar]").forEach((b) => b.onclick = async (ev) => { ev.preventDefault(); await api().quitar_documento(b.dataset.docQuitar); docsSel.delete(b.dataset.docQuitar); cargarDocumentos(); });
  document.querySelectorAll("[data-carpeta-quitar]").forEach((b) => b.onclick = () => {
    $("#doc-aviso").innerHTML = aviso("warn", "¿Quitar esta carpeta de Sopa? Tus archivos no se tocan; solo se borra el índice.", `<button class="peligro" id="cq-si">Quitar</button><button class="fantasma" id="cq-no">Cancelar</button>`);
    $("#cq-no").onclick = () => $("#doc-aviso").innerHTML = "";
    $("#cq-si").onclick = async () => { await api().quitar_carpeta(b.dataset.carpetaQuitar); $("#doc-aviso").innerHTML = ""; cargarDocumentos(); };
  });
  document.querySelectorAll("[data-carpeta-revisar]").forEach((b) => b.onclick = () => indexarCarpeta(b.dataset.carpetaRevisar));
  document.querySelectorAll("[data-carpeta-usar]").forEach((b) => b.onclick = () => {
    const c = r.carpetas.find((x) => x.ruta === b.dataset.carpetaUsar);
    estado.docs = [{ id: "carpeta:" + c.ruta, nombre: "Carpeta " + c.ruta.split(/[\\/]/).pop() + ` (${c.documentos})` }];
    mostrarVista("chat"); pintarDocs();
  });
  botonesSeleccion();
  if (r.indexando) sondearIndexado();
}

function botonesSeleccion() {
  const n = docsSel.size;
  $("#doc-resumir").disabled = n < 1; $("#doc-preguntar").disabled = n < 1; $("#doc-comparar").disabled = n < 2;
  $("#doc-resumir").textContent = n > 1 ? `Resumir (${n})` : "Resumir";
}

async function indexarCarpeta(ruta) {
  const r = ruta ? await api().añadir_carpeta_ruta(ruta) : await api().elegir_carpeta_documentos();
  if (r.cancelado) return;
  if (!r.ok) return fallo("#doc-aviso", r.error);
  sondearIndexado();
}

let sondeoIndexado = null;
async function sondearIndexado() {
  clearTimeout(sondeoIndexado);
  const r = await api().estado_indexado();
  const e = r.estado, caja = $("#doc-indexado");
  if (!e) { caja.classList.add("oculto"); return; }
  caja.classList.remove("oculto");
  $("#punto-indexado").parentElement.classList.toggle("ocupado", !!r.activo);
  let pct = 0, detalle = "";
  if (e.fase === "leyendo") { pct = e.total ? e.hechos / e.total : 0; detalle = `${e.hechos} de ${e.total} · ${esc(e.actual)}`; }
  else if (e.fase === "vectores") { pct = e.vectores_total ? e.vectores_hechos / e.vectores_total : 1; detalle = `${e.vectores_hechos} de ${e.vectores_total} fragmentos`; }
  else if (e.fase === "descargando_buscador" && e.descarga) { pct = e.descarga[0] / e.descarga[1]; detalle = `${mb(e.descarga[0])} de ${mb(e.descarga[1])}`; }
  else if (["terminado", "cancelado"].includes(e.fase)) { pct = 1; detalle = `${e.nuevos} nuevos, ${e.saltados} sin cambios${e.paginas_ocr ? `, ${e.paginas_ocr} páginas con OCR` : ""}${e.fin && e.inicio ? " · " + duracion(e.fin - e.inicio) : ""}`; }
  const errores = e.n_errores ? `<details><summary>${e.n_errores} archivo${e.n_errores > 1 ? "s" : ""} sin leer</summary>${e.errores.map((x) => `<div><small>${esc(x.archivo)}: ${esc(x.error)}</small></div>`).join("")}</details>` : "";
  caja.innerHTML = `<div class="cabecera-tarjeta"><h3>${FASES[e.fase] || esc(e.fase)}</h3>${r.activo ? '<button class="fantasma" id="doc-cancelar">Cancelar</button>' : ""}</div>
    <progress class="barra-progreso" max="100" value="${Math.round(pct * 100)}"></progress><small>${detalle}</small>${e.aviso ? aviso("warn", esc(e.aviso)) : ""}${errores}
    ${r.activo ? "<small>Puedes seguir usando Sopa mientras tanto.</small>" : ""}`;
  if ($("#doc-cancelar")) $("#doc-cancelar").onclick = () => api().cancelar_indexado();
  if (r.activo) sondeoIndexado = setTimeout(sondearIndexado, 1000);
  else if (document.querySelector("#vista-documentos.visible")) cargarDocumentos();
}

async function buscarDocs(ev) {
  ev.preventDefault();
  const q = $("#doc-consulta").value.trim(); if (!q) return;
  const r = await api().buscar_documentos(q, docsSel.size ? [...docsSel] : null, 8);
  if (!r.ok) return fallo("#doc-resultados", r.error);
  $("#doc-resultados").innerHTML = r.resultados.length
    ? `<small>${r.modo === "hibrida" ? "Por palabras y por significado" : "Por palabras"} · ${r.resultados.length} resultados</small>` + r.resultados.map((x) => `<div class="resultado"><b>${esc(x.archivo)}</b>${x.pagina ? ` <small>página ${x.pagina}</small>` : ""}<p>${esc(x.texto.slice(0, 320))}${x.texto.length > 320 ? "…" : ""}</p></div>`).join("")
    : aviso("info", "No he encontrado nada parecido.");
}

async function consultaDocs(tipo) {
  const enfoque = $("#doc-enfoque").value.trim();
  $("#doc-resultado").innerHTML = aviso("info", tipo === "resumir" ? "Leyendo y resumiendo… (con documentos largos puede tardar un minuto)" : "Leyendo y comparando…");
  const r = tipo === "resumir" ? await api().resumir_documentos([...docsSel], enfoque) : await api().comparar_documentos([...docsSel], enfoque);
  if (!r.ok) return fallo("#doc-resultado", r.error);
  const auto = r.modelo_auto ? aviso("ok", `Sopa ha cargado <b>${esc(r.modelo_auto.nombre)}</b> porque ${esc(minus(r.modelo_auto.motivo.replace(/^[^:]*:\s*/, "")))}`) : "";
  if (r.modelo_auto) { estado.modeloChat = r.modelo_auto.id; if (r.modelo_auto.ruta) $("#chat-modelo").value = r.modelo_auto.ruta; }
  $("#doc-resultado").innerHTML = auto + `<div class="resultado-docs"><div class="md">${markdown(r.texto)}</div>${pintarCitas(r)}<small class="meta">${r.extractos} extractos · ${r.segundos} s</small></div>`;
}

function enlazarDocumentos() {
  $("#doc-carpeta").onclick = () => indexarCarpeta();
  $("#doc-archivos").onclick = async () => {
    const r = await api().elegir_documentos();
    const lineas = (r.errores || []).map((e) => esc(e.nombre + ": " + e.error))
      .concat((r.avisos || []).map((e) => esc(e.nombre + ": " + e.aviso)));
    if (lineas.length) $("#doc-aviso").innerHTML = aviso("warn", lineas.join("<br>"));
    cargarDocumentos();
  };
  $("#doc-busqueda").onsubmit = buscarDocs;
  $("#doc-resumir").onclick = () => consultaDocs("resumir");
  $("#doc-comparar").onclick = () => consultaDocs("comparar");
  $("#doc-preguntar").onclick = async () => {
    const r = await api().documentos();
    estado.docs = r.documentos.filter((d) => docsSel.has(d.id)).map((d) => ({ id: d.id, nombre: d.nombre }));
    mostrarVista("chat"); pintarDocs();
  };
}


// ---- Memoria ------------------------------------------------------------------------
async function cargarMemoria(mensaje) {
  const r = await api().memoria();
  $("#mem-activa").checked = r.activa;
  $("#mem-resumen").textContent = r.entradas.length ? `${r.entradas.length} recuerdo${r.entradas.length > 1 ? "s" : ""}` : "";
  $("#mem-aviso").innerHTML = mensaje || (r.activa ? "" : aviso("info", "La memoria está apagada: Sopa no la usa en el chat, pero se conserva."));
  $("#mem-borrar-todo").disabled = !r.entradas.length;
  $("#mem-lista").innerHTML = r.entradas.length ? r.entradas.slice().reverse().map((e, n) => `<div class="fila"><div class="txt"><b data-mem-texto="${esc(e.id)}">${esc(e.texto)}</b><span>${esc(e.fecha)}${e.origen === "chat" ? " · desde el chat" : ""}</span></div>
      <div class="ancla"><button type="button" class="icono-btn" data-menu="menu-mem-${n}" aria-haspopup="menu" aria-expanded="false" aria-label="Opciones del recuerdo" title="Opciones">${svg("mas")}</button>
        <div class="menu abajo derecha" id="menu-mem-${n}" role="menu"><button type="button" class="menu-item" role="menuitem" data-mem-editar="${esc(e.id)}">${svg("editar")}Cambiar</button>
          <div class="menu-sep"></div><button type="button" class="menu-item peligro" role="menuitem" data-mem-borrar="${esc(e.id)}">${svg("borrar")}Borrar</button></div></div></div>`).join("")
    : vacio("memoria", "Aún no recuerda nada", "Añade aquí lo que quieras que Sopa tenga en cuenta siempre, o díselo en el chat con «Recuerda que…».");
  const tras = (x, ok) => cargarMemoria(x.ok ? (ok ? aviso("ok", ok) : "") : aviso("err", esc(x.error)));
  document.querySelectorAll("[data-mem-editar]").forEach((b) => b.onclick = async () => {
    const e = r.entradas.find((x) => x.id === b.dataset.memEditar);
    const fila = document.querySelector(`[data-mem-texto="${CSS.escape(e.id)}"]`);
    const nuevo = await editarEnLinea(fila && fila.closest(".txt"), { valor: e.texto, etiqueta: "Cambiar el recuerdo", boton: "Guardar", multilinea: true });
    if (nuevo === null || nuevo === e.texto) return;
    tras(await api().memoria_editar(e.id, nuevo), "Cambiado.");
  });
  document.querySelectorAll("[data-mem-borrar]").forEach((b) => b.onclick = async () => tras(await api().memoria_borrar(b.dataset.memBorrar), "Borrado."));
}

// ---- Registro único (Ajustes › Avanzado) -------------------------------------
// Junta lo que hizo Sopa en tus carpetas, lo que pasó por Seguridad y las automatizaciones.
// El registro del motor va aparte (Ver) y «Borrar el registro» no lo toca.
function cuandoRegistro(texto) {
  const t = String(texto || "").replace(" ", "T");
  const d = new Date(t);
  if (isNaN(d)) return { orden: 0, texto: String(texto || "") };
  const hoy = new Date(); const ayer = new Date(); ayer.setDate(hoy.getDate() - 1);
  const hora = d.toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
  const mismo = (x) => x.toDateString() === d.toDateString();
  const dia = mismo(hoy) ? "Hoy" : mismo(ayer) ? "Ayer" : d.toLocaleDateString("es-ES", { day: "numeric", month: "short" });
  return { orden: d.getTime(), texto: `${dia}, ${hora}` };
}
function entradasRegistro() {
  const todas = [];
  (estado.registroCarpetas || []).forEach((e, n) => {
    const c = cuandoRegistro(e.fecha);
    todas.push({ tipo: "carpetas", icono: "carpeta", orden: c.orden, n, cuando: c.texto, titulo: e.accion, det: `Carpetas · ${e.resultado || ""}` });
  });
  (estado.registroSeguridad || []).forEach((e, n) => {
    const c = cuandoRegistro(e.cuando);
    todas.push({ tipo: "seguridad", icono: "escudo", orden: c.orden, n, cuando: c.texto, titulo: `${e.resultado || ""} · ${e.herramienta || ""}`,
      det: `Seguridad${e.origen === "movil" ? " · desde el móvil" : ""}${e.vista ? " · " + String(e.vista).slice(0, 140) : ""}` });
  });
  (estado.registroAutomatizaciones || []).forEach((e, n) => {
    const c = cuandoRegistro(e.cuando);
    todas.push({ tipo: "automatizaciones", icono: "rayo", orden: c.orden, n, cuando: c.texto, titulo: `${e.nombre || ""}: ${e.texto || ""}`, det: "Automatización", deshacer: e.puede_deshacer ? e.id : "" });
  });
  return todas.sort((x, y) => (y.orden - x.orden) || (y.n - x.n));
}
function pintarRegistroUnico() {
  const caja = $("#registro-entradas");
  if (!caja) return;
  const filtro = ($("#reg-filtro") && $("#reg-filtro").value) || "";
  const lista = entradasRegistro().filter((e) => !filtro || e.tipo === filtro);
  caja.innerHTML = lista.length
    ? lista.map((e) => `<div class="entrada-reg" data-tipo="${e.tipo}"><span class="cuando">${esc(e.cuando)}</span><span class="tipo">${svgS(e.icono)}</span>
        <div class="txt">${esc(e.titulo)}<span>${esc(e.det)}</span></div>
        ${e.deshacer ? `<button type="button" class="btn texto" data-auto-deshacer="${esc(e.deshacer)}">${svgS("deshacer")}Deshacer</button>` : "<span></span>"}</div>`).join("")
    : `<div class="entrada-reg vacia"><span class="secundario-texto">${filtro ? "No hay nada de este tipo." : "Aún no hay nada anotado."}</span></div>`;
  caja.querySelectorAll("[data-auto-deshacer]").forEach((b) => b.onclick = async () => {
    const x = await api().automatizaciones_deshacer(b.dataset.autoDeshacer);
    pintarAutomatizaciones();
    mostrarAvisoRegistro(x.ok ? aviso("ok", esc(x.texto || "He deshecho esta ejecución.")) : aviso("err", esc(x.error)));
  });
}
function mostrarAvisoRegistro(html) {
  const caja = $("#registro-entradas");
  if (!caja) return;
  let a = $("#registro-aviso");
  if (!a) { caja.insertAdjacentHTML("beforebegin", '<div id="registro-aviso" class="fila-panel"></div>'); a = $("#registro-aviso"); }
  a.innerHTML = html || "";
}
function abrirBorrarRegistro() {
  const velo = $("#dialogo-borrar-registro");
  velo.hidden = false;
  document.body.classList.add("con-dialogo");
  $("#borrar-registro-no").focus();
}
function cerrarBorrarRegistro() {
  $("#dialogo-borrar-registro").hidden = true;
  document.body.classList.remove("con-dialogo");
  $("#borrar-registro").focus();
}

function enlazarCarpetas() {
  $("#carp-anadir").onclick = async () => {
    const r = await api().elegir_carpeta_autorizada();
    if (!r || r.cancelado) return;
    pintarCarpetas(r.ok ? aviso("ok", "Carpeta añadida. Sopa puede proponer acciones aquí, siempre con tu confirmación.") : aviso("err", esc(r.error)));
  };
  $("#carp-deshacer").onclick = async () => {
    const r = await api().acciones_deshacer();
    mostrarAvisoRegistro(r.ok ? aviso("ok", esc(r.texto || "He deshecho la última acción.")) : aviso("err", esc(r.error)));
    pintarCarpetas();
  };
  $("#reg-filtro").onchange = pintarRegistroUnico;
  // Un solo «Borrar el registro»: borra a la vez las acciones en carpetas y la auditoría de Seguridad.
  $("#borrar-registro").onclick = abrirBorrarRegistro;
  $("#borrar-registro-no").onclick = cerrarBorrarRegistro;
  $("#dialogo-borrar-registro").addEventListener("keydown", (e) => { if (e.key === "Escape") { e.stopPropagation(); cerrarBorrarRegistro(); } });
  $("#dialogo-borrar-registro").addEventListener("click", (e) => { if (e.target.id === "dialogo-borrar-registro") cerrarBorrarRegistro(); });
  $("#borrar-registro-si").onclick = async () => {
    const [a, b] = await Promise.all([api().acciones_borrar_registro(), api().borrar_registro_seguridad()]);
    cerrarBorrarRegistro();
    const ok = a && a.ok !== false && b && b.ok !== false;
    mostrarAvisoRegistro(ok ? aviso("ok", "Registro borrado. El registro del motor no se ha tocado.") : aviso("err", esc((a && a.error) || (b && b.error) || "No he podido borrarlo entero.")));
    pintarCarpetas();
    if (typeof pintarSeguridad === "function") pintarSeguridad();
  };
}

function disparadorAuto(prefijo) {
  const tipo = $(prefijo + "cuando").value;
  if (tipo === "diario") return { tipo, hora: $(prefijo + "hora").value.trim() };
  if (tipo === "semanal") return { tipo, hora: $(prefijo + "hora").value.trim(), dia: Number($(prefijo + "dia").value) };
  if (tipo === "una_vez") return { tipo, cuando: $(prefijo + "momento").value.trim() };
  if (tipo === "carpeta") {
    const carpeta = $(prefijo + "carpeta");
    return carpeta ? { tipo, carpeta: carpeta.value } : { tipo };
  }
  return { tipo: "manual" };
}

function pasosAuto() {
  const carpeta = $("#auto-carpeta").value;
  if ($("#auto-que").value === "organizar") {
    return [{ accion: "organizar", carpeta, modo: $("#auto-modo").value }];
  }
  return [{ herramienta: "leer", carpeta, ruta: $("#auto-ruta").value }];
}

function mostrarCamposAuto() {
  const tipo = $("#auto-cuando").value;
  const que = $("#auto-que").value;
  $("#auto-hora-caja").classList.toggle("oculto", tipo !== "diario" && tipo !== "semanal");
  $("#auto-dia-caja").classList.toggle("oculto", tipo !== "semanal");
  $("#auto-momento-caja").classList.toggle("oculto", tipo !== "una_vez");
  $("#auto-ruta-caja").classList.toggle("oculto", que !== "leer");
  $("#auto-modo-caja").classList.toggle("oculto", que !== "organizar");
}

async function pintarAutomatizaciones(mensaje) {
  const caja = $("#auto-aviso");
  if (!caja) return;
  const [r, carpetas] = await Promise.all([api().automatizaciones_estado(), api().acciones_estado()]);
  if (!r || r.ok === false) {
    caja.innerHTML = aviso("err", esc((r && r.error) || "No he podido leer las automatizaciones."));
    return;
  }
  const sel = $("#auto-carpeta");
  const elegido = sel.value;
  sel.innerHTML = (carpetas.carpetas || []).map((c) => `<option value="${esc(c.id)}">${esc(c.nombre)}</option>`).join("");
  if (elegido) sel.value = elegido;
  const cabe = r.permitido !== false;
  $("#auto-guardar").disabled = !cabe;
  const avisoPlan = !cabe ? aviso("warn", "Ahora no se pueden usar las automatizaciones.") : "";
  caja.innerHTML = avisoPlan || mensaje || "";
  $("#auto-lista").innerHTML = (r.automatizaciones || []).length
    ? r.automatizaciones.map((a, n) => {
      const lineas = (a.lineas || []).map((l) => esc(l)).join(" · ");
      const pausa = a.pausada ? "Reanudar" : "Pausar";
      return `<div class="fila"><span class="monograma">${svgS("rayo")}</span><div class="txt"><b>${esc(a.nombre)}</b><span>${a.pausada ? "En pausa · " : ""}${lineas}</span></div>
        <button class="btn" type="button" data-auto-run="${esc(a.id)}">Ejecutar</button>
        <div class="ancla"><button type="button" class="icono-btn" data-menu="menu-auto-${n}" aria-haspopup="menu" aria-expanded="false" aria-label="Opciones de ${esc(a.nombre)}" title="Opciones">${svg("mas")}</button>
          <div class="menu abajo derecha" id="menu-auto-${n}" role="menu">
            <button class="menu-item" role="menuitem" type="button" data-auto-pausa="${esc(a.id)}" data-pausada="${a.pausada ? "1" : ""}">${svg("pausa")}${pausa}</button>
            <div class="menu-sep"></div>
            <button class="menu-item peligro" role="menuitem" type="button" data-auto-quitar="${esc(a.id)}">${svg("borrar")}Quitar</button></div></div></div>`;
    }).join("")
    : `<div class="fila"><span class="secundario-texto">Aún no hay automatizaciones. Solo funcionan con Sopa abierta.</span></div>`;
  estado.registroAutomatizaciones = r.registro || [];
  pintarRegistroUnico();
  document.querySelectorAll("[data-auto-run]").forEach((b) => b.onclick = async () => {
    b.disabled = true;
    const x = await api().automatizaciones_ejecutar(b.dataset.autoRun);
    pintarAutomatizaciones(x.ok ? aviso("ok", esc(x.texto || "Hecho.")) : aviso("err", esc(x.error)));
  });
  document.querySelectorAll("[data-auto-pausa]").forEach((b) => b.onclick = async () => {
    const x = await api().automatizaciones_pausar(b.dataset.autoPausa, b.dataset.pausada !== "1");
    pintarAutomatizaciones(x.ok ? aviso("ok", esc(x.texto || "")) : aviso("err", esc(x.error)));
  });
  document.querySelectorAll("[data-auto-quitar]").forEach((b) => b.onclick = async () => {
    const x = await api().automatizaciones_quitar(b.dataset.autoQuitar);
    pintarAutomatizaciones(x.ok ? aviso("ok", esc(x.texto || "Quitada.")) : aviso("err", esc(x.error)));
  });
}

function enlazarAutomatizaciones() {
  const form = $("#auto-form");
  if (!form) return;
  $("#auto-que").onchange = mostrarCamposAuto;
  $("#auto-cuando").onchange = mostrarCamposAuto;
  mostrarCamposAuto();
  const abrirForm = (abrir) => {
    form.hidden = !abrir;
    $("#auto-nueva").setAttribute("aria-expanded", abrir ? "true" : "false");
    if (abrir) $("#auto-nombre").focus();
  };
  $("#auto-nueva").onclick = () => abrirForm(form.hidden);
  $("#auto-cancelar").onclick = () => { abrirForm(false); $("#auto-lineas").innerHTML = ""; };
  form.onsubmit = async (ev) => {
    ev.preventDefault();
    const r = await api().automatizaciones_crear({
      nombre: $("#auto-nombre").value,
      pasos: pasosAuto(),
      disparador: disparadorAuto("#auto-"),
      confirmada: $("#auto-confirma").checked,
    });
    if (r && r.necesita_confirmacion) {
      $("#auto-lineas").innerHTML = aviso("warn", esc((r.lineas || []).join(" ") + " " + (r.que || "")));
      return;
    }
    $("#auto-lineas").innerHTML = "";
    if (r && r.ok) { form.hidden = true; $("#auto-nueva").setAttribute("aria-expanded", "false"); }
    pintarAutomatizaciones(r && r.ok ? aviso("ok", esc(r.texto || "Guardada.")) : aviso("err", esc((r && r.error) || "No he podido guardarla.")));
  };
}

function enlazarMemoria() {
  $("#mem-form").onsubmit = async (ev) => {
    ev.preventDefault();
    const x = await api().memoria_añadir($("#mem-texto").value, "a mano");
    if (x.ok) $("#mem-texto").value = "";
    cargarMemoria(x.ok ? aviso("ok", "Guardado.") : aviso("err", esc(x.error)));
  };
  $("#mem-activa").onchange = async (ev) => { await api().memoria_activar(ev.target.checked); cargarMemoria(); };
  $("#mem-borrar-todo").onclick = () => {
    $("#mem-aviso").innerHTML = aviso("warn", "¿Borrar todo lo que Sopa recuerda de ti? No se puede deshacer.", `<button class="peligro" id="mem-todo-si">Borrar todo</button><button class="fantasma" id="mem-todo-no">Cancelar</button>`);
    $("#mem-todo-no").onclick = () => $("#mem-aviso").innerHTML = "";
    $("#mem-todo-si").onclick = async () => { const x = await api().memoria_borrar_todo(); cargarMemoria(x.ok ? aviso("ok", "Memoria borrada.") : aviso("err", esc(x.error))); };
  };
}
